import { assertEquals, assertStrictEquals } from "https://deno.land/std@0.208.0/assert/mod.ts";
import { makeSourceKey, validateProviderInput } from "./index.ts";

Deno.test("makeSourceKey normaliza acentos e espaços", () => {
  assertEquals(makeSourceKey("IBS", "Petrolina", "PE"), "ibs__petrolina__pe");
  assertEquals(makeSourceKey("FI'CAR", "Fortaleza", "CE"), "fi car__fortaleza__ce");
  assertEquals(makeSourceKey("JS Rastreamento", "Ilhéus", "BA"), "js rastreamento__ilheus__ba");
  assertEquals(makeSourceKey("Mundial Radar", "Feira de Santana", "BA"), "mundial radar__feira de santana__ba");
});

Deno.test("validateProviderInput aceita payload mínimo", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE" });
  assertStrictEquals(r.ok, true);
});

Deno.test("validateProviderInput rejeita nome vazio", () => {
  const r = validateProviderInput({ nome: "", cidade: "Y", uf: "PE" });
  assertStrictEquals(r.ok, false);
});

Deno.test("validateProviderInput rejeita uf inválida", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PERNAMBUCO" });
  assertStrictEquals(r.ok, false);
});

Deno.test("validateProviderInput rejeita tipo não permitido", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", tipos_atendidos: ["carro", "avião"] });
  assertStrictEquals(r.ok, false);
});

Deno.test("validateProviderInput aceita tipos válidos", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", tipos_atendidos: ["carro", "moto"] });
  assertStrictEquals(r.ok, true);
});

Deno.test("validateProviderInput rejeita status inválido", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", status: "banido" });
  assertStrictEquals(r.ok, false);
});

Deno.test("validateProviderInput rejeita raio zero/negativo", () => {
  const r1 = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", raio_atendimento_km: 0 });
  const r2 = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", raio_atendimento_km: -5 });
  assertStrictEquals(r1.ok, false);
  assertStrictEquals(r2.ok, false);
});

Deno.test("validateProviderInput rejeita capacidade negativa", () => {
  const r = validateProviderInput({ nome: "X", cidade: "Y", uf: "PE", capacidade_mensal: -1 });
  assertStrictEquals(r.ok, false);
});
