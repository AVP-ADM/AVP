// deno-lint-ignore-file no-explicit-any
// Edge Function pública (sem login) que centraliza a escrita na tabela
// tracking_service_providers. Protege as operações com um código
// administrativo cujo hash SHA-256 é armazenado como secret.
//
// Ações suportadas:
//   { action: "create",      admin_code, provider }
//   { action: "update",      admin_code, id, patch }
//   { action: "activate",    admin_code, id }
//   { action: "deactivate",  admin_code, id }
//   { action: "delete",      admin_code, id }
//   { action: "migrate_missing", admin_code, providers: [...] }
//
// Segurança:
// - admin_code jamais é logado nem retornado.
// - Rate limit por IP (SHA-256) — bloqueio temporário após tentativas
//   inválidas seguidas.
// - Escrita usa a service role, mas apenas após validar o código.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const ADMIN_HASH = (Deno.env.get("TRACKING_PROVIDER_ADMIN_CODE_HASH") ?? "").toLowerCase();

const ALLOWED_STATUS = new Set(["ativo", "pendente", "inativo"]);
const ALLOWED_TIPOS = new Set(["carro", "moto", "caminhao"]);

// -------------------- helpers --------------------

async function sha256Hex(input: string): Promise<string> {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

const normalize = (s: string) =>
  (s ?? "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

export function makeSourceKey(nome: string, cidade: string, uf: string): string {
  return `${normalize(nome)}__${normalize(cidade)}__${(uf ?? "").toLowerCase()}`;
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

function err(code: string, message: string, status: number, extra?: Record<string, unknown>): Response {
  return json({ ok: false, error: { code, message, ...extra } }, status);
}

// -------------------- rate limit --------------------

interface Bucket {
  fails: number;
  blockedUntil: number;
}
const rateBuckets = new Map<string, Bucket>();
const MAX_FAILS = 5;
const BLOCK_MS = 5 * 60 * 1000;

function rlKey(ipHash: string) { return ipHash; }

function isBlocked(ipHash: string): number {
  const b = rateBuckets.get(rlKey(ipHash));
  if (!b) return 0;
  if (b.blockedUntil > Date.now()) return b.blockedUntil;
  return 0;
}

function registerFail(ipHash: string): number {
  const now = Date.now();
  const b = rateBuckets.get(rlKey(ipHash)) ?? { fails: 0, blockedUntil: 0 };
  b.fails += 1;
  if (b.fails >= MAX_FAILS) {
    b.blockedUntil = now + BLOCK_MS;
    b.fails = 0;
  }
  rateBuckets.set(rlKey(ipHash), b);
  return b.blockedUntil;
}

function clearFails(ipHash: string) {
  rateBuckets.delete(rlKey(ipHash));
}

// -------------------- input validation --------------------

export interface ProviderInput {
  nome: string;
  cidade: string;
  uf: string;
  latitude?: number | null;
  longitude?: number | null;
  raio_atendimento_km?: number;
  status?: "ativo" | "pendente" | "inativo";
  capacidade_mensal?: number | null;
  tipos_atendidos?: string[] | null;
  fonte?: string | null;
  source_key?: string | null;
  localizacao_aproximada?: boolean | null;
}

export interface ProviderPatch {
  nome?: string;
  cidade?: string;
  uf?: string;
  latitude?: number | null;
  longitude?: number | null;
  raio_atendimento_km?: number;
  status?: "ativo" | "pendente" | "inativo";
  capacidade_mensal?: number | null;
  tipos_atendidos?: string[] | null;
  fonte?: string | null;
  localizacao_aproximada?: boolean | null;
}

export function validateProviderInput(p: any): { ok: true; value: ProviderInput } | { ok: false; error: string } {
  if (!p || typeof p !== "object") return { ok: false, error: "provider ausente" };
  if (typeof p.nome !== "string" || !p.nome.trim()) return { ok: false, error: "nome obrigatório" };
  if (typeof p.cidade !== "string" || !p.cidade.trim()) return { ok: false, error: "cidade obrigatória" };
  if (typeof p.uf !== "string" || !/^[A-Za-z]{2}$/.test(p.uf.trim())) return { ok: false, error: "uf inválida" };
  if (p.status && !ALLOWED_STATUS.has(p.status)) return { ok: false, error: "status inválido" };
  if (p.tipos_atendidos != null) {
    if (!Array.isArray(p.tipos_atendidos)) return { ok: false, error: "tipos_atendidos deve ser array" };
    for (const t of p.tipos_atendidos) {
      if (!ALLOWED_TIPOS.has(t)) return { ok: false, error: `tipo inválido: ${t}` };
    }
  }
  if (p.raio_atendimento_km != null && (typeof p.raio_atendimento_km !== "number" || p.raio_atendimento_km <= 0)) {
    return { ok: false, error: "raio_atendimento_km inválido" };
  }
  if (p.capacidade_mensal != null && (typeof p.capacidade_mensal !== "number" || p.capacidade_mensal < 0)) {
    return { ok: false, error: "capacidade_mensal inválida" };
  }
  if (p.latitude != null && typeof p.latitude !== "number") return { ok: false, error: "latitude inválida" };
  if (p.longitude != null && typeof p.longitude !== "number") return { ok: false, error: "longitude inválida" };
  return { ok: true, value: p as ProviderInput };
}

// -------------------- handler --------------------

async function handle(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return err("method_not_allowed", "Use POST", 405);

  if (!ADMIN_HASH) return err("admin_hash_missing", "Configure a secret TRACKING_PROVIDER_ADMIN_CODE_HASH", 500);
  if (!SUPABASE_URL || !SERVICE_ROLE) return err("server_misconfigured", "SUPABASE_URL/SERVICE_ROLE ausentes", 500);

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  const ipHash = await sha256Hex(ip);

  const blockedUntil = isBlocked(ipHash);
  if (blockedUntil) {
    return err("rate_limited", "Muitas tentativas — tente novamente em alguns minutos", 429, {
      retry_after_ms: blockedUntil - Date.now(),
    });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return err("invalid_json", "Corpo inválido", 400);
  }

  const action = String(body?.action ?? "");
  const adminCode = String(body?.admin_code ?? "");
  if (!adminCode) return err("admin_code_required", "admin_code obrigatório", 401);

  const suppliedHash = (await sha256Hex(adminCode)).toLowerCase();
  if (suppliedHash !== ADMIN_HASH) {
    const until = registerFail(ipHash);
    return err("admin_code_invalid", "Código administrativo inválido", 401, until ? { blocked_until_ms: until } : {});
  }
  clearFails(ipHash);

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  try {
    switch (action) {
      case "create": {
        const v = validateProviderInput(body.provider);
        if (!v.ok) return err("validation_failed", v.error, 400);
        const p = v.value;
        const source_key = p.source_key || makeSourceKey(p.nome, p.cidade, p.uf);
        const row = {
          nome: p.nome.trim(),
          cidade: p.cidade.trim(),
          uf: p.uf.trim().toUpperCase(),
          latitude: p.latitude ?? null,
          longitude: p.longitude ?? null,
          raio_atendimento_km: p.raio_atendimento_km ?? 30,
          status: p.status ?? "ativo",
          capacidade_mensal: p.capacidade_mensal ?? null,
          tipos_atendidos: p.tipos_atendidos ?? null,
          fonte: p.fonte ?? null,
          source_key,
          localizacao_aproximada: p.localizacao_aproximada ?? true,
        };
        const { data, error } = await supabase
          .from("tracking_service_providers")
          .insert(row)
          .select()
          .single();
        if (error) {
          if ((error as any).code === "23505") return err("duplicate", "Prestador já existe (source_key duplicado)", 409);
          return err("insert_failed", error.message, 400);
        }
        return json({ ok: true, provider: data });
      }
      case "update": {
        const id = String(body.id ?? "");
        if (!id) return err("id_required", "id obrigatório", 400);
        const patch = (body.patch ?? {}) as ProviderPatch;
        // valida campos parciais
        if (patch.status && !ALLOWED_STATUS.has(patch.status)) return err("validation_failed", "status inválido", 400);
        if (patch.tipos_atendidos != null) {
          if (!Array.isArray(patch.tipos_atendidos)) return err("validation_failed", "tipos_atendidos deve ser array", 400);
          for (const t of patch.tipos_atendidos) {
            if (!ALLOWED_TIPOS.has(t)) return err("validation_failed", `tipo inválido: ${t}`, 400);
          }
        }
        if (patch.uf != null && !/^[A-Za-z]{2}$/.test(patch.uf.trim())) return err("validation_failed", "uf inválida", 400);
        const clean: Record<string, unknown> = {};
        for (const k of ["nome","cidade","uf","latitude","longitude","raio_atendimento_km","status","capacidade_mensal","tipos_atendidos","fonte","localizacao_aproximada"] as const) {
          if (k in patch) clean[k] = (patch as any)[k];
        }
        if (typeof clean.uf === "string") clean.uf = (clean.uf as string).toUpperCase();
        const { data, error } = await supabase
          .from("tracking_service_providers")
          .update(clean)
          .eq("id", id)
          .select()
          .single();
        if (error) return err("update_failed", error.message, 400);
        if (!data) return err("not_found", "Prestador não encontrado", 404);
        return json({ ok: true, provider: data });
      }
      case "activate":
      case "deactivate": {
        const id = String(body.id ?? "");
        if (!id) return err("id_required", "id obrigatório", 400);
        const status = action === "activate" ? "ativo" : "inativo";
        const { data, error } = await supabase
          .from("tracking_service_providers")
          .update({ status })
          .eq("id", id)
          .select()
          .single();
        if (error) return err("update_failed", error.message, 400);
        if (!data) return err("not_found", "Prestador não encontrado", 404);
        return json({ ok: true, provider: data });
      }
      case "delete": {
        const id = String(body.id ?? "");
        if (!id) return err("id_required", "id obrigatório", 400);
        const { error } = await supabase.from("tracking_service_providers").delete().eq("id", id);
        if (error) return err("delete_failed", error.message, 400);
        return json({ ok: true });
      }
      case "migrate_missing": {
        const providers = Array.isArray(body.providers) ? body.providers : [];
        const rows: any[] = [];
        for (const p of providers) {
          const v = validateProviderInput(p);
          if (!v.ok) continue;
          const source_key = p.source_key || makeSourceKey(p.nome, p.cidade, p.uf);
          rows.push({
            nome: p.nome.trim(),
            cidade: p.cidade.trim(),
            uf: p.uf.trim().toUpperCase(),
            latitude: p.latitude ?? null,
            longitude: p.longitude ?? null,
            raio_atendimento_km: p.raio_atendimento_km ?? 30,
            status: p.status ?? "ativo",
            capacidade_mensal: p.capacidade_mensal ?? null,
            tipos_atendidos: p.tipos_atendidos ?? null,
            fonte: p.fonte ?? "migracao_local",
            source_key,
            localizacao_aproximada: p.localizacao_aproximada ?? true,
          });
        }
        if (!rows.length) return json({ ok: true, inserted: 0, skipped: 0 });
        const { data, error } = await supabase
          .from("tracking_service_providers")
          .upsert(rows, { onConflict: "source_key", ignoreDuplicates: true })
          .select("id, source_key");
        if (error) return err("migrate_failed", error.message, 400);
        return json({
          ok: true,
          inserted: (data ?? []).length,
          skipped: rows.length - (data ?? []).length,
        });
      }
      default:
        return err("invalid_action", `Ação desconhecida: ${action}`, 400);
    }
  } catch (e) {
    return err("internal_error", (e as Error).message ?? "erro interno", 500);
  }
}

if ((globalThis as any).Deno?.serve) {
  (globalThis as any).Deno.serve(handle);
}

export { handle };
