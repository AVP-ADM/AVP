// Deno tests for the AEasy sync normalization module.
// Run:  deno test --allow-none supabase/functions/sync-aeasy/normalize_test.ts
import { assert, assertEquals } from "https://deno.land/std@0.224.0/assert/mod.ts";
import {
  classifyTipoVeiculo, hasValidTracker, normalizeCidade, normalizeSituacao,
  normalizeText, normalizeUF, parseFipe, sha256,
} from "./normalize.ts";

Deno.test("classifyTipoVeiculo - categorias oficiais carro", () => {
  const carro = [
    "Automóvel Premium", "Automóvel Start", "Passeio - Importado",
    "Passeio - Nacional", "Elétrico | Híbrido", "SUV | Caminhonete | Utilitário",
    "Atividade Remunerada (veículo leve)", "Categoria teste (não usar)",
  ];
  for (const c of carro) assertEquals(classifyTipoVeiculo(c), "carro", c);
});

Deno.test("classifyTipoVeiculo - categorias oficiais moto", () => {
  const moto = [
    "Motocicletas - Honda", "Motocicletas - Yamaha", "Motocicletas Especiais",
    "ELITE 125 | FLUO 125 | NEO", "PCX 150 | NMAX 160 | ADV 150",
    "Atividade Remunerada (motocicleta - Honda)",
  ];
  for (const c of moto) assertEquals(classifyTipoVeiculo(c), "moto", c);
});

Deno.test("classifyTipoVeiculo - categorias oficiais caminhao", () => {
  for (const c of ["Truck Leve (até 14t)", "Truck Pesado (a partir de 14t)", "Agregado Carreta"]) {
    assertEquals(classifyTipoVeiculo(c), "caminhao", c);
  }
});

Deno.test("classifyTipoVeiculo - aliases aprovados", () => {
  assertEquals(classifyTipoVeiculo("Motocicleta"), "moto");
  assertEquals(classifyTipoVeiculo("shineray | avelloz"), "moto");
  assertEquals(classifyTipoVeiculo("Automóvel Elétrico"), "carro");
  assertEquals(classifyTipoVeiculo("Frota Publica (Leve até 14t)"), "caminhao");
});

Deno.test("classifyTipoVeiculo - fora do mapa vira nao_classificado", () => {
  for (const c of ["", "SUV", "truck", "auto", "Reboque", "Passeio"]) {
    assertEquals(classifyTipoVeiculo(c), "nao_classificado", c);
  }
  assertEquals(classifyTipoVeiculo("Rastreamento | Monitoramento - Comodato"), "nao_classificado");
  assertEquals(classifyTipoVeiculo("Inativado"), "nao_classificado");
});

Deno.test("hasValidTracker - aceita imei/id reais, rejeita placeholders", () => {
  assert(hasValidTracker("865080043871157"));
  assert(hasValidTracker("Terceirizado"));
  assert(!hasValidTracker(""));
  assert(!hasValidTracker("0"));
  assert(!hasValidTracker("000000000000000"));
  assert(!hasValidTracker("N/A"));
  assert(!hasValidTracker("nao possui"));
  assert(!hasValidTracker("-"));
});

Deno.test("normalizeUF - siglas e nomes por extenso", () => {
  assertEquals(normalizeUF("Pernambuco"), "PE");
  assertEquals(normalizeUF("São Paulo"), "SP");
  assertEquals(normalizeUF("Rio Grande do Norte"), "RN");
  assertEquals(normalizeUF("PE"), "PE");
  assertEquals(normalizeUF(" ba "), "BA");
});

Deno.test("normalizeSituacao - somente ativo/suspenso/cancelado/outro", () => {
  assertEquals(normalizeSituacao("Ativo"), "ativo");
  assertEquals(normalizeSituacao("SUSPENSO"), "suspenso");
  assertEquals(normalizeSituacao("Cancelado"), "cancelado");
  assertEquals(normalizeSituacao("Pendente"), "outro");
  assertEquals(normalizeSituacao(""), "outro");
});

Deno.test("normalizeCidade - titlecase estável", () => {
  assertEquals(normalizeCidade("PETROLINA"), "Petrolina");
  assertEquals(normalizeCidade("  são paulo  "), "São Paulo");
});

Deno.test("parseFipe - número e string BR", () => {
  assertEquals(parseFipe(83366), 83366);
  assertEquals(parseFipe("R$ 246.715,00"), 246715);
  assertEquals(parseFipe(""), null);
  assertEquals(parseFipe(null), null);
  assertEquals(parseFipe("abc"), null);
});

Deno.test("normalizeText - trim + colapsa espaços", () => {
  assertEquals(normalizeText("  João   da  Silva  "), "João da Silva");
  assertEquals(normalizeText(null), "");
});

Deno.test("sha256 - determinístico e formato hex de 64 chars", async () => {
  const a = await sha256("teste");
  const b = await sha256("teste");
  const c = await sha256("teste2");
  assertEquals(a, b);
  assert(a !== c);
  assertEquals(a.length, 64);
  assert(/^[0-9a-f]{64}$/.test(a));
});
