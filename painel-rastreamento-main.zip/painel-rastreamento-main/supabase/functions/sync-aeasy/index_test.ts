// Deno tests for pure helpers in the sync-aeasy Edge Function.
// Importing index.ts is safe because Deno.serve is guarded by import.meta.main.
import { assert, assertEquals, assertThrows } from "https://deno.land/std@0.224.0/assert/mod.ts";
import {
  buildReportQuery, discoverSituacaoIds, hasXlsxMagic, parseBody, periodForYear,
} from "./index.ts";

Deno.test("buildReportQuery - envia campos obrigatórios e VendasSituacao[] repetido", () => {
  const q = buildReportQuery("2024-01-01", "2024-12-31", ["1", "2", "3"]);
  assertEquals(q.get("DepartNivel"), "1");
  assertEquals(q.get("TipoData"), "VendasDataCadastro");
  assertEquals(q.get("DataInicial"), "2024-01-01");
  assertEquals(q.get("DataFinal"), "2024-12-31");
  assertEquals(q.get("LinkRelatorioCompletoAssociados"), "/vendas/exportar-relatorio-completo-associados");
  const situacoes = q.getAll("VendasSituacao[]");
  assertEquals(situacoes, ["1", "2", "3"]);
  // Campos vazios obrigatórios presentes
  assertEquals(q.get("VeiculoZero"), "");
  assertEquals(q.get("ValorFipeInicio"), "");
});

Deno.test("hasXlsxMagic - detecta assinatura PK\\x03\\x04", () => {
  const good = new Uint8Array([0x50, 0x4b, 0x03, 0x04, 0x14, 0x00]).buffer;
  const bad = new Uint8Array([0x3c, 0x21, 0x44, 0x4f]).buffer; // '<!DO'
  const short = new Uint8Array([0x50, 0x4b]).buffer;
  assert(hasXlsxMagic(good));
  assert(!hasXlsxMagic(bad));
  assert(!hasXlsxMagic(short));
});

Deno.test("periodForYear - clampa ano corrente para hoje", () => {
  const today = new Date().toISOString().slice(0, 10);
  const currentYear = new Date().getUTCFullYear();
  const p = periodForYear(currentYear, currentYear);
  assertEquals(p.date_start, `${currentYear}-01-01`);
  assertEquals(p.date_end, today);
  assertEquals(p.granularity, "year");
  const past = periodForYear(2023, currentYear);
  assertEquals(past.date_end, "2023-12-31");
});

Deno.test("discoverSituacaoIds - extrai Ativo/Suspenso/Cancelado", () => {
  const html = `
    <select name="VendasSituacao[]" multiple>
      <option value="10">Aguardando</option>
      <option value="20">Ativo</option>
      <option value="30">Suspenso</option>
      <option value="40">Cancelado</option>
      <option value="50">Encerrado</option>
    </select>`;
  const { descobertas, todas } = discoverSituacaoIds(html);
  assertEquals(descobertas.length, 3);
  const map = Object.fromEntries(descobertas.map((d) => [d.nome, d.id]));
  assertEquals(map.ativo, "20");
  assertEquals(map.suspenso, "30");
  assertEquals(map.cancelado, "40");
  assertEquals(todas.length, 5);
});

Deno.test("discoverSituacaoIds - falha explícita se select ausente", () => {
  assertThrows(() => discoverSituacaoIds("<html><body>sem select</body></html>"));
});

Deno.test("discoverSituacaoIds - falha se faltar uma das 3 situações", () => {
  const html = `<select name="VendasSituacao[]">
    <option value="1">Ativo</option>
    <option value="2">Suspenso</option>
  </select>`;
  assertThrows(() => discoverSituacaoIds(html));
});

Deno.test("parseBody - aceita ações permitidas e rejeita campos extras", () => {
  const ok = parseBody({ action: "start", mode: "dry_run" });
  assertEquals(ok.action, "start");
  // Campo não permitido em `start` deve falhar
  assertThrows(() => parseBody({ action: "start", mode: "dry_run", period_key: "2024" }));
});

Deno.test("parseBody - rejeita ação inválida", () => {
  assertThrows(() => parseBody({ action: "delete_everything" }));
  assertThrows(() => parseBody({}));
  assertThrows(() => parseBody(null));
});

Deno.test("parseBody - process_period aceita campos permitidos", () => {
  const body = parseBody({ action: "process_period", sync_id: "abc", period_key: "2024" });
  assertEquals(body.period_key, "2024");
  assertThrows(() => parseBody({ action: "process_period", sync_id: "a", period_key: "b", extra: 1 }));
});
