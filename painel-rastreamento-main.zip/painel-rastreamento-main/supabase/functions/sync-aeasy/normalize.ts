// Regras oficiais de normalização e classificação. Mantidas equivalentes ao
// frontend (src/lib/classify.ts) para não duplicar lógica de negócio.

const stripAccents = (s: string) =>
  (s ?? "").toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

const catKey = (s: string) =>
  stripAccents(s).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

const normalize = (s: string) => stripAccents(s ?? "").toLowerCase().trim();

const OFFICIAL_CATEGORIES: Record<string, string[]> = {
  carro: [
    "Atividade Remunerada (SUV | Caminhonete | Utilitário)",
    "Atividade Remunerada (veículo leve)",
    "Automóvel Premium",
    "Automóvel Start",
    "Categoria teste (não usar)",
    "Elétrico | Híbrido",
    "Passeio - Importado",
    "Passeio - Nacional",
    "SUV | Caminhonete | Utilitário",
    "SUV | Caminhonete | Utilitário - Importado",
  ],
  moto: [
    "Atividade Remunerada (motocicleta - Avelloz | Shineray | Bajaj)",
    "Atividade Remunerada (motocicleta - Honda)",
    "Atividade Remunerada (motocicleta - Yamaha)",
    "ELITE 125 | FLUO 125 | NEO",
    "Motocicletas - Avelloz | Shineray | Bajaj",
    "Motocicletas - Honda",
    "Motocicletas - Yamaha",
    "Motocicletas Especiais",
    "PCX 150 | NMAX 160 | ADV 150",
    "PCX 160 | XMAX 250 | ADV 160",
  ],
  caminhao: [
    "Truck Leve (até 14t)",
    "Truck Pesado (a partir de 14t)",
    "Agregado Carreta",
  ],
};

const OFFICIAL_ALIASES: Record<string, string[]> = {
  moto: [
    "Motocicleta",
    "Atividade Remunerada (motocicleta)",
    "SHINERAY | AVELLOZ",
  ],
  carro: [
    "Automóvel Elétrico",
    "Automóvel Híbrido",
  ],
  caminhao: [
    "Frota Publica (Leve até 14t)",
    "Frota Publica (Pesado a partir de 14t)",
    "Rastreamento | Monitoramento - Comodato (Truck)",
  ],
};

const CATEGORY_MAP = new Map<string, string>();
for (const [tipo, list] of Object.entries(OFFICIAL_CATEGORIES)) {
  for (const c of list) CATEGORY_MAP.set(catKey(c), tipo);
}
for (const [tipo, list] of Object.entries(OFFICIAL_ALIASES)) {
  for (const c of list) CATEGORY_MAP.set(catKey(c), tipo);
}
for (const c of ["Rastreamento | Monitoramento - Comodato", "Inativado", "Teste"]) {
  CATEGORY_MAP.set(catKey(c), "nao_classificado");
}

export type TipoVeiculo = "carro" | "moto" | "caminhao" | "nao_classificado";

export function classifyTipoVeiculo(categoria: string): TipoVeiculo {
  const key = catKey(categoria);
  if (!key) return "nao_classificado";
  return (CATEGORY_MAP.get(key) as TipoVeiculo) ?? "nao_classificado";
}

const INVALID_TRACKERS = new Set([
  "", "0", "n/a", "na", "sem", "naopossui", "nao", "null", "undefined", "-",
]);

export function hasValidTracker(raw: string): boolean {
  const n = normalize(raw).replace(/\s+/g, "");
  if (!n) return false;
  if (INVALID_TRACKERS.has(n)) return false;
  if (/^0+$/.test(n)) return false;
  if (n.length < 3) return false;
  return true;
}

export function parseFipe(v: unknown): number | null {
  if (v == null) return null;
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  const s = String(v).replace(/R\$\s*/gi, "").replace(/\./g, "").replace(",", ".").trim();
  if (!s) return null;
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : null;
}

const UF_CODES = new Set([
  "AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG",
  "PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO",
]);
const STATE_NAME_TO_UF: Record<string, string> = {
  "acre":"AC","alagoas":"AL","amapa":"AP","amazonas":"AM","bahia":"BA",
  "ceara":"CE","distrito federal":"DF","espirito santo":"ES","goias":"GO",
  "maranhao":"MA","mato grosso":"MT","mato grosso do sul":"MS",
  "minas gerais":"MG","para":"PA","paraiba":"PB","parana":"PR",
  "pernambuco":"PE","piaui":"PI","rio de janeiro":"RJ",
  "rio grande do norte":"RN","rio grande do sul":"RS","rondonia":"RO",
  "roraima":"RR","santa catarina":"SC","sao paulo":"SP","sergipe":"SE",
  "tocantins":"TO",
};

export function normalizeUF(uf: string): string {
  const raw = (uf ?? "").toString().trim();
  if (!raw) return "";
  const up = raw.toUpperCase();
  if (up.length === 2 && UF_CODES.has(up)) return up;
  const nk = stripAccents(raw).toLowerCase().replace(/\s+/g, " ").trim();
  if (STATE_NAME_TO_UF[nk]) return STATE_NAME_TO_UF[nk];
  return up.slice(0, 2);
}

export function normalizeCidade(c: string): string {
  return (c ?? "").toString().trim().replace(/\s+/g, " ")
    .split(" ")
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
    .join(" ");
}

export function normalizeSituacao(s: string): string {
  const n = normalize(s);
  if (!n) return "outro";
  if (n.includes("ativo")) return "ativo";
  if (n.includes("suspens")) return "suspenso";
  if (n.includes("cancel")) return "cancelado";
  return "outro";
}

export function normalizeText(s: unknown): string {
  return (s ?? "").toString().trim().replace(/\s+/g, " ");
}

export async function sha256(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
