// deno-lint-ignore-file no-explicit-any
// AEasy → Supabase sync — segmentada por período (uma invocação por período).
//
// API pública baseada em ações:
//   { action: "start", mode: "dry_run" | "apply" }
//   { action: "process_period", sync_id, period_key }
//   { action: "status", sync_id }
//   { action: "finalize", sync_id }
//   { action: "split_period", sync_id, period_key }
//   { action: "cancel", sync_id }
//
// Regras de memória:
// - Uma invocação NUNCA carrega mais de um período.
// - Nenhuma invocação carrega o snapshot consolidado; a consolidação e a
//   comparação com a base oficial ocorrem em SQL (RPCs no banco).
// - As linhas normalizadas de um período são inseridas em lotes pequenos
//   (500) para o staging e imediatamente liberadas.
//
// Segurança:
// - Endpoint público, aceita apenas anon key. Não retorna cookies/PII.
// - Cooldown apenas em `start`. Continuações não são bloqueadas.
// - Trava global por índice único parcial (status ativo).
// - service role permanece exclusivamente no servidor.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";
import {
  classifyTipoVeiculo,
  hasValidTracker,
  normalizeCidade,
  normalizeSituacao,
  normalizeText,
  normalizeUF,
  parseFipe,
  sha256,
} from "./normalize.ts";

// ============================================================================
// Constants / env
// ============================================================================

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const AEASY_BASE_URL = Deno.env.get("AEASY_BASE_URL") ?? "";
const AEASY_LOGIN = Deno.env.get("AEASY_LOGIN") ?? "";
const AEASY_PASSWORD = Deno.env.get("AEASY_PASSWORD") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

const SYNC_START_YEAR = (() => {
  const v = parseInt(Deno.env.get("AEASY_SYNC_START_YEAR") ?? "2022", 10);
  return Number.isFinite(v) && v >= 2000 && v <= 2100 ? v : 2022;
})();

const COOLDOWN_DRY_MS = 10 * 60 * 1000;
const COOLDOWN_APPLY_MS = 60 * 60 * 1000;
const HARD_TIMEOUT_MS = 3 * 60 * 1000;  // per invocation
const STAGING_BATCH = 500;
const MAX_BACKWARD_YEARS = 15;

const REPORT_PATH = "/vendas/exportar-relatorio-completo-associados";
const SITUACOES_ACEITAS = ["ativo", "suspenso", "cancelado"] as const;
type SituacaoAceita = typeof SITUACOES_ACEITAS[number];

const EMPTY_FORM_FIELDS = [
  "Fidelidade","IndividuosEnderecosLogradouro","IndividuosEnderecosBairro",
  "VendasCarrosPlaca","VendasCarrosPlacaImplemento","VendasCarrosModelosId",
  "PossuiEvento","DataNascimento","VendasDiasAtraso","TipoVendasFaturasPagas",
  "FaturasPagas","VeiculoZero","ValorFipeInicio","ValorFipeFinal","FormaPagamento",
  "VendasClassificacao","VendasCarrosRastreadorObrigatorio","CarneEmitido","PossuiCarne",
  "ConsultoresIndicadoresConsultoresNome","VendasTipoSuspensao",
  "VendasCarrosValorDescontoConsultor","VendasCarrosOrigemMigracao",
  "VendasFuncionariosConsultoresId","VendasCarrosPortabilidade","AssociadosMaisPlacas",
  "VendasCarrosAssociacaoOrigem","CarrosChassi","VendasCarrosPlotagem",
  "FaturaNaoGeradaMesAno","FaturaNaoGeradaTipo","ParcelasDisponiveis","DadosExtra",
  "TermoAdesaoAssinado","AuxilioProfissional","VendasCarrosChassiRemarcado",
  "VendasCarrosLeilao","VendasCarrosMediaMonta","VendasCarrosMotivosDeprecacaoId",
  "RetornarLiderComEquipe","ProdutosId","ContabilizaParaMeta",
];

const HEADER_HINTS: Record<string, string[]> = {
  associado: ["associado", "nome", "cliente"],
  placa: ["placa"],
  numeroRastreador: ["rastreador", "chip", "imei", "equipamento"],
  consultor: ["consultor", "vendedor"],
  cidade: ["cidade", "municipio"],
  estado: ["estado", "uf"],
  plano: ["plano", "produto"],
  situacao: ["situacao", "status"],
  valorFipe: ["fipe", "valor"],
  categoria: ["categoria", "tipo"],
  vendaId: ["vendaid", "venda id", "id venda", "id_da_venda", "contrato", "id contrato"],
  individuoId: ["individuoid", "individuo id", "id individuo", "id_individuo", "id do individuo"],
};

// ============================================================================
// Errors
// ============================================================================

type SyncStage =
  | "request_validation" | "cooldown" | "lock" | "login" | "session_validation"
  | "status_discovery" | "official_total" | "generate_report" | "download_report"
  | "parse_xlsx" | "normalize" | "staging_insert" | "compare_supabase"
  | "apply_snapshot" | "resource_limit" | "not_found" | "unknown";

class SyncError extends Error {
  code: string; stage: SyncStage; httpStatus: number;
  period_key: string | null; retryable: boolean; details: unknown;
  constructor(init: {
    code: string; message: string; stage: SyncStage; httpStatus?: number;
    period_key?: string | null; retryable?: boolean; details?: unknown;
  }) {
    super(init.message);
    this.code = init.code;
    this.stage = init.stage;
    this.httpStatus = init.httpStatus ?? 500;
    this.period_key = init.period_key ?? null;
    this.retryable = init.retryable ?? true;
    this.details = init.details ?? null;
  }
}
function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}
function errorResponse(e: SyncError, extra: Record<string, unknown> = {}) {
  return jsonResponse({
    ok: false, error: e.message,
    code: e.code, message: e.message, stage: e.stage,
    period_key: e.period_key, retryable: e.retryable, details: e.details,
    timestamp: new Date().toISOString(), ...extra,
  }, e.httpStatus);
}
function toSyncError(err: unknown, defaults: Partial<ConstructorParameters<typeof SyncError>[0]> = {}): SyncError {
  if (err instanceof SyncError) return err;
  const msg = err instanceof Error ? err.message : String(err);
  if (/Timeout|wall clock|worker terminated|CPU|Memory limit/i.test(msg)) {
    return new SyncError({
      code: "EDGE_FUNCTION_RESOURCE_LIMIT", stage: "resource_limit",
      message: msg, retryable: true,
      details: "Recursos da Edge Function excedidos. Considere `split_period` para dividir o período.",
      ...defaults,
    } as any);
  }
  if (/AEASY_SESSION_INVALID/i.test(msg)) {
    return new SyncError({ code: "AEASY_SESSION_INVALID", stage: "session_validation", message: msg, ...defaults } as any);
  }
  if (/Falha ao autenticar/i.test(msg)) {
    return new SyncError({ code: "AEASY_LOGIN_FAILED", stage: "login", message: msg, ...defaults } as any);
  }
  return new SyncError({ code: "UNKNOWN_ERROR", stage: "unknown", message: msg, ...defaults } as any);
}

// ============================================================================
// AEasy client — one login per invocation
// ============================================================================

interface AeasyClient {
  cookie: string; cookieNames: string[];
  loginAccepted: boolean; vendasAuthed: boolean; loginRedirectDetected: boolean;
  vendasHtml: string;
  fetch: (path: string, init?: RequestInit) => Promise<Response>;
}
function looksLikeLoginPage(text: string): boolean {
  const t = text.toLowerCase();
  return t.includes("<form") && (t.includes("login") || t.includes("senha"));
}
async function aeasyLogin(): Promise<AeasyClient> {
  if (!AEASY_BASE_URL || !AEASY_LOGIN || !AEASY_PASSWORD) {
    throw new SyncError({ code: "AEASY_CREDENTIALS_MISSING", stage: "login", message: "Credenciais AEasy ausentes nos secrets.", retryable: false });
  }
  const BASE = AEASY_BASE_URL.replace(/\/$/, "");
  const jar = new Map<string, string>();
  const setJarFrom = (setCookie: string | null) => {
    if (!setCookie) return;
    const parts = setCookie.split(/,(?=\s*[A-Za-z0-9_-]+=)/);
    for (const p of parts) {
      const kv = p.trim().split(";")[0];
      const eq = kv.indexOf("=");
      if (eq > 0) jar.set(kv.slice(0, eq).trim(), kv.slice(eq + 1).trim());
    }
  };
  const jarHeader = () => Array.from(jar.entries()).map(([k, v]) => `${k}=${v}`).join("; ");

  const pre = await fetch(`${BASE}/conta/login`, { redirect: "manual" });
  setJarFrom(pre.headers.get("set-cookie"));

  const body = new URLSearchParams({ UsuariosLogin: AEASY_LOGIN, UsuariosSenha: AEASY_PASSWORD });
  const res = await fetch(`${BASE}/conta/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "Accept": "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
      Referer: `${BASE}/conta/login`,
      Cookie: jarHeader(),
    },
    body: body.toString(),
    redirect: "manual",
  });
  setJarFrom(res.headers.get("set-cookie"));
  const loginAccepted = jar.has("PHPSESSID") && (res.status === 200 || res.status === 302);
  if (!loginAccepted) {
    throw new SyncError({ code: "AEASY_LOGIN_FAILED", stage: "login", message: `Falha ao autenticar no AEasy (status ${res.status})` });
  }
  const cookie = jarHeader();
  const cookieNames = Array.from(jar.keys());

  const doFetch = (path: string, init: RequestInit = {}) =>
    fetch(`${BASE}${path}`, {
      ...init,
      headers: {
        ...(init.headers ?? {}),
        Cookie: cookie,
        Accept: "application/json, text/javascript, */*; q=0.01",
        Referer: `${BASE}/vendas`,
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
      },
      redirect: "follow",
    });

  const vendasRes = await fetch(`${BASE}/vendas`, {
    headers: {
      Cookie: cookie,
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
    },
    redirect: "follow",
  });
  const vendasFinalUrl = vendasRes.url || "";
  const vendasText = await vendasRes.text().catch(() => "");
  const loginRedirectDetected = /\/conta\/login/i.test(vendasFinalUrl) ||
    (vendasText.length > 0 && vendasText.length < 20000 && looksLikeLoginPage(vendasText));
  const vendasAuthed = vendasRes.ok && !loginRedirectDetected;
  if (!vendasAuthed) {
    throw new SyncError({
      code: "AEASY_SESSION_INVALID", stage: "session_validation",
      message: `Sessão AEasy inválida após login (status=${vendasRes.status}).`,
    });
  }
  return { cookie, cookieNames, loginAccepted, vendasAuthed, loginRedirectDetected, vendasHtml: vendasText, fetch: doFetch };
}

// ============================================================================
// Status discovery + official total
// ============================================================================

interface SituacaoDescoberta { nome: SituacaoAceita; label: string; id: string; }

function normalizeLabel(s: string): string {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
}
export function discoverSituacaoIds(html: string): { descobertas: SituacaoDescoberta[]; todas: Array<{ id: string; label: string }> } {
  const selRe = /<select[^>]*name=["']VendasSituacao\[\]["'][^>]*>([\s\S]*?)<\/select>/i;
  const m = html.match(selRe);
  if (!m) throw new SyncError({ code: "AEASY_SITUACAO_SELECT_NOT_FOUND", stage: "status_discovery", message: "Campo VendasSituacao[] não encontrado em /vendas.", retryable: false });
  const inner = m[1];
  const optRe = /<option[^>]*value=["']([^"']+)["'][^>]*>([\s\S]*?)<\/option>/gi;
  const todas: Array<{ id: string; label: string }> = [];
  let om: RegExpExecArray | null;
  while ((om = optRe.exec(inner)) !== null) {
    const id = om[1].trim();
    const label = om[2].replace(/<[^>]+>/g, "").trim();
    if (id && label) todas.push({ id, label });
  }
  const findBy = (needle: string) => todas.find((o) => {
    const n = normalizeLabel(o.label);
    return n === needle || n.startsWith(needle);
  });
  const map: Record<SituacaoAceita, string> = { ativo: "", suspenso: "", cancelado: "" };
  const patterns: Record<SituacaoAceita, string> = { ativo: "ativo", suspenso: "suspens", cancelado: "cancel" };
  for (const key of SITUACOES_ACEITAS) {
    const found = findBy(patterns[key]);
    if (!found) throw new SyncError({
      code: "AEASY_SITUACAO_NOT_FOUND", stage: "status_discovery",
      message: `Opção "${key}" não encontrada em VendasSituacao[].`,
      details: { disponiveis: todas.map((o) => `${o.id}=${o.label}`) },
      retryable: false,
    });
    map[key] = found.id;
  }
  const descobertas: SituacaoDescoberta[] = SITUACOES_ACEITAS.map((nome) => ({
    nome, id: map[nome], label: todas.find((o) => o.id === map[nome])!.label,
  }));
  return { descobertas, todas };
}

async function fetchAeasyReportedTotal(client: AeasyClient, situacaoIds: string[]): Promise<{
  total: number | null; captured_at: string; status: number; matched_pattern: string | null; snippet: string | null;
}> {
  const q = new URLSearchParams();
  q.append("TipoData", "VendasDataCadastro");
  for (const s of situacaoIds) q.append("VendasSituacao[]", s);
  const captured_at = new Date().toISOString();
  const res = await client.fetch(`/vendas?${q.toString()}`, {
    method: "GET", headers: { Accept: "text/html,application/xhtml+xml" },
  });
  const html = await res.text().catch(() => "");
  const patterns: Array<{ name: string; re: RegExp }> = [
    { name: "total_geral", re: /Total\s+Geral\s*[:=]?\s*([\d.,]+)/i },
    { name: "total_registros", re: /Total\s+de\s+Registros\s*[:=]?\s*([\d.,]+)/i },
    { name: "total_dois_pontos", re: /Total\s*[:=]\s*([\d.,]+)/i },
    { name: "registros_encontrados", re: /([\d.,]+)\s+registros\s+encontrados/i },
    { name: "associados_encontrados", re: /([\d.,]+)\s+associados/i },
    { name: "de_x_registros", re: /de\s+([\d.]{2,})\s*(?:registros|associados|itens)/i },
    { name: "paginacao_de_x", re: /\d+\s*[-–]\s*\d+\s+de\s+([\d.,]+)/i },
    { name: "json_total", re: /"total"\s*:\s*(\d+)/i },
  ];
  let total: number | null = null;
  let matched: string | null = null;
  for (const p of patterns) {
    const m = html.match(p.re);
    if (m) {
      const n = parseInt(m[1].replace(/\./g, "").replace(/,/g, ""), 10);
      if (Number.isFinite(n) && n > 0) { total = n; matched = p.name; break; }
    }
  }
  return {
    total, captured_at, status: res.status, matched_pattern: matched,
    snippet: total == null ? html.slice(0, 4000).replace(/\s+/g, " ").trim().slice(0, 800) : null,
  };
}

// ============================================================================
// Report fetch + XLSX parse + normalize (single period)
// ============================================================================

export function buildReportQuery(dataInicial: string, dataFinal: string, situacaoIds: string[]): URLSearchParams {
  const q = new URLSearchParams();
  q.append("DepartNivel", "1");
  q.append("LinkRelatorioPDF", "/vendas/exportar-relatorio-pdf");
  q.append("LinkRelatorioCompletoAssociados", "/vendas/exportar-relatorio-completo-associados");
  q.append("LinkRelatorioSimplificadoAssociados", "/vendas/exportar-relatorio-simplificado-associados");
  q.append("TipoData", "VendasDataCadastro");
  q.append("DataInicial", dataInicial);
  q.append("DataFinal", dataFinal);
  for (const s of situacaoIds) q.append("VendasSituacao[]", s);
  for (const f of EMPTY_FORM_FIELDS) q.append(f, "");
  return q;
}
export function hasXlsxMagic(buf: ArrayBuffer): boolean {
  if (buf.byteLength < 4) return false;
  const b = new Uint8Array(buf, 0, 4);
  return b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
}
async function fetchReportBuffer(client: AeasyClient, period_key: string, start: string, end: string, situacaoIds: string[]):
  Promise<{ buffer: ArrayBuffer; file_name: string }> {
  const qs = buildReportQuery(start, end, situacaoIds).toString();
  const res = await client.fetch(`${REPORT_PATH}?${qs}`, { method: "GET" });
  const ct = res.headers.get("content-type") ?? "";
  const finalUrl = res.url || "";
  if (/\/conta\/login/i.test(finalUrl)) {
    throw new SyncError({ code: "AEASY_SESSION_INVALID", stage: "session_validation", message: "Sessão expirada durante a geração do relatório.", period_key });
  }
  if (!res.ok) throw new SyncError({ code: "GENERATE_REPORT_FAILED", stage: "generate_report", message: `HTTP ${res.status}`, period_key });

  if (ct.includes("application/json")) {
    const json = await res.json().catch(() => null) as any;
    let filePath: string | null = null;
    for (const k of ["redirect", "download", "arquivo", "url", "file", "path"]) {
      const v = json?.[k] ?? json?.data?.[k];
      if (typeof v === "string" && v.length > 0) { filePath = v; break; }
    }
    if (!filePath) throw new SyncError({ code: "GENERATE_REPORT_NO_REDIRECT", stage: "generate_report", message: "JSON sem redirect.", period_key });
    const dl = filePath.startsWith("http") ? filePath : (filePath.startsWith("/") ? filePath : `/${filePath}`);
    const fileRes = await (dl.startsWith("http")
      ? fetch(dl, { headers: { Cookie: client.cookie } })
      : client.fetch(dl));
    if (!fileRes.ok) throw new SyncError({ code: "DOWNLOAD_REPORT_FAILED", stage: "download_report", message: `HTTP ${fileRes.status}`, period_key });
    const buf = await fileRes.arrayBuffer();
    if (!hasXlsxMagic(buf)) throw new SyncError({ code: "DOWNLOAD_REPORT_NOT_XLSX", stage: "download_report", message: `Arquivo não é XLSX (${buf.byteLength}b).`, period_key });
    return { buffer: buf, file_name: filePath.split("/").pop()?.split("?")[0] ?? `aeasy-${period_key}.xlsx` };
  }
  if (ct.includes("spreadsheet") || ct.includes("excel") || ct.includes("octet-stream") || ct.includes("zip")) {
    const buf = await res.arrayBuffer();
    if (hasXlsxMagic(buf)) return { buffer: buf, file_name: `aeasy-${period_key}.xlsx` };
  }
  throw new SyncError({ code: "GENERATE_REPORT_UNEXPECTED", stage: "generate_report", message: `Resposta inesperada (${ct}).`, period_key });
}

function normHeader(h: string): string {
  return (h ?? "").toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
}
function detectColumns(headers: string[]): { map: Record<string, number>; mapping: Record<string, string | null>; missing: string[] } {
  const norm = headers.map(normHeader);
  const map: Record<string, number> = {};
  const mapping: Record<string, string | null> = {};
  for (const [field, hints] of Object.entries(HEADER_HINTS)) {
    const idx = norm.findIndex((h) => hints.some((k) => h.includes(k)));
    mapping[field] = idx >= 0 ? headers[idx] : null;
    if (idx >= 0) map[field] = idx;
  }
  const missing = ["associado", "placa", "situacao", "categoria"].filter((k) => map[k] == null);
  return { map, mapping, missing };
}

function buildSourceId(vendaId: string, individuoId: string, placa: string, associado: string):
  { id: string; strategy: "venda" | "individuo_placa" | "hash_contingencia" } {
  if (vendaId) return { id: `V:${vendaId}`, strategy: "venda" };
  if (individuoId && placa) return { id: `I:${individuoId}|P:${placa}`, strategy: "individuo_placa" };
  return { id: `H:${associado}|${placa}|${individuoId}`, strategy: "hash_contingencia" };
}

async function normalizeOneRow(row: any[], cols: Record<string, number>) {
  const get = (field: string) => (cols[field] != null ? row[cols[field]] : "");
  const associado = normalizeText(get("associado"));
  const placa = normalizeText(get("placa")).toUpperCase();
  const numero_rastreador = normalizeText(get("numeroRastreador"));
  const consultor = normalizeText(get("consultor"));
  const cidade = normalizeCidade(String(get("cidade") ?? ""));
  const estado = normalizeUF(String(get("estado") ?? ""));
  const plano = normalizeText(get("plano"));
  const situacao = normalizeSituacao(String(get("situacao") ?? ""));
  const valor_fipe = parseFipe(get("valorFipe"));
  const categoria_original = normalizeText(get("categoria"));
  const tipo_veiculo = classifyTipoVeiculo(categoria_original);
  const rastreador_valido = hasValidTracker(numero_rastreador);
  const operacional = situacao === "ativo" || situacao === "suspenso";
  const vendaId = normalizeText(get("vendaId"));
  const individuoId = normalizeText(get("individuoId"));
  if (!associado && !placa && !vendaId && !individuoId) return null;
  const { id } = buildSourceId(vendaId, individuoId, placa, associado);
  const hashInput = [
    associado, placa, numero_rastreador, consultor, cidade, estado,
    plano, situacao, valor_fipe ?? "", categoria_original, tipo_veiculo,
    rastreador_valido ? 1 : 0, operacional ? 1 : 0,
  ].join("|");
  const row_hash = await sha256(hashInput);
  return {
    aeasy_source_id: id,
    aeasy_venda_id: vendaId || null,
    aeasy_individuo_id: individuoId || null,
    associado, placa, numero_rastreador, consultor, cidade, estado, plano, situacao,
    valor_fipe, categoria_original, tipo_veiculo, rastreador_valido, operacional,
    row_hash,
  };
}

// ============================================================================
// Supabase helpers
// ============================================================================

const admin = createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });

async function heartbeat(sync_id: string, patch: Record<string, unknown> = {}) {
  await admin.from("aeasy_sync_runs").update({ heartbeat_at: new Date().toISOString(), ...patch }).eq("id", sync_id);
}
async function updateRun(sync_id: string, patch: Record<string, unknown>) {
  await admin.from("aeasy_sync_runs").update(patch).eq("id", sync_id);
}
async function updatePart(sync_id: string, period_key: string, patch: Record<string, unknown>) {
  await admin.from("aeasy_sync_parts").update(patch).eq("sync_id", sync_id).eq("period_key", period_key);
}
async function loadRun(sync_id: string) {
  const { data, error } = await admin.from("aeasy_sync_runs").select("*").eq("id", sync_id).maybeSingle();
  if (error) throw new SyncError({ code: "RUN_LOAD_FAILED", stage: "unknown", message: error.message });
  if (!data) throw new SyncError({ code: "RUN_NOT_FOUND", stage: "not_found", message: `Sincronização ${sync_id} não encontrada.`, httpStatus: 404, retryable: false });
  return data;
}
async function loadParts(sync_id: string) {
  const { data, error } = await admin
    .from("aeasy_sync_parts").select("*")
    .eq("sync_id", sync_id).order("date_start", { ascending: true });
  if (error) throw new SyncError({ code: "PARTS_LOAD_FAILED", stage: "unknown", message: error.message });
  return data ?? [];
}
async function loadPart(sync_id: string, period_key: string) {
  const { data, error } = await admin
    .from("aeasy_sync_parts").select("*")
    .eq("sync_id", sync_id).eq("period_key", period_key).maybeSingle();
  if (error) throw new SyncError({ code: "PART_LOAD_FAILED", stage: "unknown", message: error.message });
  if (!data) throw new SyncError({ code: "PART_NOT_FOUND", stage: "not_found", message: `Período ${period_key} não encontrado.`, httpStatus: 404, retryable: false });
  return data;
}

// Release stale runs (best-effort) before any lock check.
async function releaseStaleRuns() {
  try { await admin.rpc("fn_release_stale_aeasy_runs"); } catch { /* noop */ }
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
export function periodForYear(y: number, currentYear: number) {
  return {
    period_key: String(y),
    period_year: y,
    granularity: "year",
    date_start: `${y}-01-01`,
    date_end: y === currentYear ? todayISO() : `${y}-12-31`,
  };
}

// ============================================================================
// Actions
// ============================================================================

async function handleStart(body: any): Promise<Response> {
  const mode = body.mode;
  if (mode !== "dry_run" && mode !== "apply") {
    throw new SyncError({ code: "INVALID_MODE", stage: "request_validation", message: "`mode` deve ser 'dry_run' ou 'apply'.", httpStatus: 400, retryable: false });
  }

  await releaseStaleRuns();

  // Cooldown only on start.
  const cooldownMs = mode === "dry_run" ? COOLDOWN_DRY_MS : COOLDOWN_APPLY_MS;
  const { data: lastRun } = await admin
    .from("aeasy_sync_runs")
    .select("started_at")
    .eq("run_mode", mode)
    .order("started_at", { ascending: false })
    .limit(1).maybeSingle();
  if (lastRun?.started_at) {
    const elapsed = Date.now() - new Date(lastRun.started_at).getTime();
    if (elapsed < cooldownMs) {
      const remaining_min = Math.ceil((cooldownMs - elapsed) / 60000);
      return errorResponse(new SyncError({
        code: "COOLDOWN_ACTIVE", stage: "cooldown",
        message: `Aguarde ${remaining_min} min antes de iniciar nova sincronização (${mode}).`,
        httpStatus: 429,
      }), { remaining_min, last_started_at: lastRun.started_at });
    }
  }

  // Create run row (respects single-active-lock via unique index).
  const { data: runRow, error: runErr } = await admin
    .from("aeasy_sync_runs")
    .insert({
      status: "initializing",
      run_mode: mode,
      trigger_type: "public_dashboard",
      heartbeat_at: new Date().toISOString(),
    })
    .select("id").single();
  if (runErr) {
    const dup = /aeasy_runs_single|duplicate key/i.test(runErr.message);
    throw new SyncError({
      code: dup ? "SYNC_ALREADY_RUNNING" : "SYNC_RUN_INSERT_FAILED",
      stage: "lock",
      message: dup ? "Já existe uma sincronização em andamento. Aguarde a conclusão ou cancele-a." : runErr.message,
      httpStatus: dup ? 409 : 500,
    });
  }
  const sync_id = runRow.id as string;

  try {
    const client = await aeasyLogin();
    const { descobertas, todas } = discoverSituacaoIds(client.vendasHtml);
    const situacaoIds = descobertas.map((s) => s.id);
    const reported = await fetchAeasyReportedTotal(client, situacaoIds);

    const currentYear = new Date().getUTCFullYear();
    const periods = [];
    for (let y = SYNC_START_YEAR; y <= currentYear; y++) periods.push(periodForYear(y, currentYear));

    const partsRows = periods.map((p) => ({ sync_id, ...p, status: "pending" }));
    const { error: partsErr } = await admin.from("aeasy_sync_parts").insert(partsRows);
    if (partsErr) throw new SyncError({ code: "PARTS_INSERT_FAILED", stage: "lock", message: partsErr.message });

    await updateRun(sync_id, {
      status: "collecting",
      official_total: reported.total,
      official_total_captured_at: reported.captured_at,
      statuses_detected: {
        aceitas: descobertas,
        todas,
        reported_total_meta: { matched_pattern: reported.matched_pattern, status: reported.status },
      },
      periods_total: periods.length,
      heartbeat_at: new Date().toISOString(),
    });

    return jsonResponse({
      ok: true, sync_id, status: "collecting", mode,
      official_total: reported.total,
      official_total_matched_pattern: reported.matched_pattern,
      official_total_debug_snippet: reported.snippet,
      situacoes: descobertas,
      periods: periods.map((p) => ({ ...p, status: "pending" })),
    });
  } catch (e) {
    const err = toSyncError(e);
    await updateRun(sync_id, {
      status: "failed", finished_at: new Date().toISOString(),
      error_code: err.code, error_stage: err.stage, error_message: err.message,
    });
    return errorResponse(err, { sync_id });
  }
}

const IN_PROGRESS_STATUSES = new Set(["generating", "downloading", "processing", "persisting"]);
const STALE_MS = 20 * 60 * 1000;

async function cleanStagingForPeriod(sync_id: string, period_key: string) {
  const { error } = await admin.from("aeasy_tracking_staging").delete()
    .eq("sync_id", sync_id).eq("period_key", period_key);
  if (error) throw new SyncError({
    code: "STAGING_CLEANUP_FAILED", stage: "staging_insert", period_key, message: error.message,
  });
}

async function handleProcessPeriod(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  const period_key = String(body.period_key ?? "");
  if (!sync_id || !period_key) {
    throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` e `period_key` são obrigatórios.", httpStatus: 400, retryable: false });
  }

  const run = await loadRun(sync_id);
  if (!["collecting", "consolidating", "ready"].includes(run.status)) {
    throw new SyncError({ code: "RUN_NOT_ACTIVE", stage: "lock", message: `Sincronização está com status ${run.status}. Não é possível processar períodos.`, httpStatus: 409, retryable: false });
  }
  const part = await loadPart(sync_id, period_key);

  // Idempotência: já concluído.
  if (part.status === "success") {
    return jsonResponse({
      ok: true, sync_id, period_key, status: "success", already_processed: true,
      source_rows: part.source_rows, valid_rows: part.valid_rows,
      invalid_rows: part.invalid_rows, discarded_status_rows: part.discarded_status_rows,
      file_name: part.file_name, file_size_bytes: part.file_size_bytes, duration_ms: part.duration_ms,
    });
  }
  if (part.status === "split") {
    throw new SyncError({
      code: "PART_REPLACED_BY_SPLIT", stage: "lock", period_key,
      message: `Período ${period_key} foi dividido; processe os sub-períodos.`,
      httpStatus: 409, retryable: false, details: { split_into: part.split_into },
    });
  }

  // Idempotência: já em execução por outra invocação/aba.
  if (IN_PROGRESS_STATUSES.has(part.status)) {
    const hb = part.started_at ? new Date(part.started_at).getTime() : 0;
    const age = Date.now() - hb;
    if (age < STALE_MS) {
      throw new SyncError({
        code: "PART_IN_PROGRESS", stage: "lock", period_key,
        message: `Período ${period_key} já está em execução (${part.status}, ${Math.round(age/1000)}s).`,
        httpStatus: 409, retryable: true,
      });
    }
    // Stale: limpa staging incompleto e retoma.
    await cleanStagingForPeriod(sync_id, period_key);
  }

  // Retry após falha: apagar somente o staging daquele período antes de recomeçar.
  if (part.status === "failed" || IN_PROGRESS_STATUSES.has(part.status)) {
    await cleanStagingForPeriod(sync_id, period_key);
  }

  const startedAt = Date.now();
  await updatePart(sync_id, period_key, {
    status: "generating", attempt: (part.attempt ?? 0) + 1,
    started_at: new Date().toISOString(), error_code: null, error_message: null,
    finished_at: null, duration_ms: null,
  });
  await heartbeat(sync_id);

  try {
    const client = await aeasyLogin();

    // Reuse statuses persisted in run, but validate they still exist in HTML.
    const persisted = (run.statuses_detected as any)?.aceitas as SituacaoDescoberta[] | undefined;
    let situacaoIds: string[] = persisted?.map((s) => s.id) ?? [];
    if (!situacaoIds.length || situacaoIds.some((id) => !id)) {
      const { descobertas } = discoverSituacaoIds(client.vendasHtml);
      situacaoIds = descobertas.map((s) => s.id);
    }

    await updatePart(sync_id, period_key, { status: "downloading" });
    await heartbeat(sync_id);

    const { buffer, file_name } = await fetchReportBuffer(client, period_key, part.date_start, part.date_end, situacaoIds);
    const file_checksum = await sha256(`${file_name}|${buffer.byteLength}|${period_key}`);

    await updatePart(sync_id, period_key, {
      status: "processing", file_name, file_size_bytes: buffer.byteLength, file_checksum,
    });
    await heartbeat(sync_id);

    // Parse XLSX
    const wb = XLSX.read(new Uint8Array(buffer), { type: "array" });
    let bestSheet = wb.SheetNames[0], bestAoa: any[][] = [];
    for (const sn of wb.SheetNames) {
      const a = XLSX.utils.sheet_to_json<any[]>(wb.Sheets[sn], { header: 1, defval: "", raw: true }) as any[][];
      const nonEmpty = a.filter((r) => r && r.some((c) => c != null && c !== "")).length;
      if (nonEmpty > bestAoa.length) { bestAoa = a; bestSheet = sn; }
    }
    let headerIdx = 0;
    for (let i = 0; i < Math.min(15, bestAoa.length); i++) {
      const joined = (bestAoa[i] ?? []).map((c) => String(c ?? "").toLowerCase()).join("|");
      if (/associad/.test(joined) && /plac/.test(joined) && /situa/.test(joined)) { headerIdx = i; break; }
    }
    const headers = (bestAoa[headerIdx] as any[] ?? []).map((h) => (h ?? "").toString());
    const rows = bestAoa.slice(headerIdx + 1);
    const { map: cols, missing } = detectColumns(headers);
    if (missing.length) {
      throw new SyncError({
        code: "AEASY_COLUMNS_MISSING", stage: "parse_xlsx", period_key,
        message: `Colunas obrigatórias ausentes: ${missing.join(", ")}.`,
        details: { sheet: bestSheet, headers }, retryable: false,
      });
    }

    // Normalize + stream into staging in small batches. Never keep the full array around
    // longer than needed; we insert as soon as a batch fills.
    await updatePart(sync_id, period_key, { status: "persisting" });
    await heartbeat(sync_id);

    let source_rows = rows.length, empty_rows = 0, invalid_rows = 0;
    let valid_rows = 0, discarded_status_rows = 0;
    let batch: any[] = [];
    const flush = async () => {
      if (!batch.length) return;
      const chunk = batch.map((r) => ({
        ...r,
        sync_id, period_key,
        source_file_name: file_name, source_file_checksum: file_checksum,
      }));
      batch = [];
      const { error: insErr } = await admin.from("aeasy_tracking_staging").insert(chunk);
      if (insErr) throw new SyncError({
        code: "STAGING_INSERT_FAILED", stage: "staging_insert", period_key,
        message: insErr.message,
      });
    };

    for (const row of rows) {
      if (!row || row.every((c) => c == null || c === "")) { empty_rows++; continue; }
      const n = await normalizeOneRow(row, cols);
      if (!n) { invalid_rows++; continue; }
      // Keep only the accepted statuses in staging (space + memory saver).
      if (n.situacao !== "ativo" && n.situacao !== "suspenso" && n.situacao !== "cancelado") {
        discarded_status_rows++; continue;
      }
      batch.push(n);
      valid_rows++;
      if (batch.length >= STAGING_BATCH) {
        await flush();
        // Heartbeat between batches so long periods don't look stale.
        if (valid_rows % (STAGING_BATCH * 4) === 0) await heartbeat(sync_id);
      }
    }
    await flush();

    const finishedAt = new Date().toISOString();
    const duration_ms = Date.now() - startedAt;
    await updatePart(sync_id, period_key, {
      status: "success", finished_at: finishedAt, duration_ms,
      source_rows, valid_rows, invalid_rows, discarded_status_rows,
    });

    // Update run aggregate counters (best-effort).
    const parts = await loadParts(sync_id);
    const completed = parts.filter((p) => p.status === "success").length;
    const failed = parts.filter((p) => p.status === "failed").length;
    const validTotal = parts.reduce((s, p) => s + (p.valid_rows ?? 0), 0);
    await heartbeat(sync_id, {
      periods_completed: completed, periods_failed: failed, valid_rows_total: validTotal,
    });

    return jsonResponse({
      ok: true, sync_id, period_key, status: "success",
      source_rows, valid_rows, invalid_rows, discarded_status_rows,
      file_name, file_size_bytes: buffer.byteLength, duration_ms,
    });
  } catch (e) {
    const err = toSyncError(e, { period_key });
    await updatePart(sync_id, period_key, {
      status: "failed", finished_at: new Date().toISOString(),
      duration_ms: Date.now() - startedAt,
      error_code: err.code, error_message: err.message,
    });
    // Increment run.periods_failed
    const parts = await loadParts(sync_id).catch(() => []);
    const failed = parts.filter((p) => p.status === "failed").length;
    await heartbeat(sync_id, { periods_failed: failed });
    return errorResponse(err, { sync_id });
  }
}

async function handleStatus(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  if (!sync_id) throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` obrigatório.", httpStatus: 400, retryable: false });
  const run = await loadRun(sync_id);
  const parts = await loadParts(sync_id);
  return jsonResponse({
    ok: true,
    run: {
      sync_id, status: run.status, run_mode: run.run_mode,
      official_total: run.official_total,
      official_total_captured_at: run.official_total_captured_at,
      periods_total: run.periods_total, periods_completed: run.periods_completed,
      periods_failed: run.periods_failed, valid_rows_total: run.valid_rows_total,
      consolidated_total: run.consolidated_total, ready_to_apply: run.ready_to_apply,
      started_at: run.started_at, finished_at: run.finished_at, heartbeat_at: run.heartbeat_at,
      error_code: run.error_code, error_stage: run.error_stage, error_message: run.error_message,
      statuses_detected: run.statuses_detected, analysis: run.analysis,
    },
    parts: parts.map((p) => ({
      period_key: p.period_key, period_year: p.period_year, granularity: p.granularity,
      date_start: p.date_start, date_end: p.date_end,
      status: p.status, attempt: p.attempt,
      source_rows: p.source_rows, valid_rows: p.valid_rows,
      invalid_rows: p.invalid_rows, discarded_status_rows: p.discarded_status_rows,
      file_name: p.file_name, file_size_bytes: p.file_size_bytes,
      duration_ms: p.duration_ms, error_code: p.error_code, error_message: p.error_message,
      split_into: p.split_into, parent_period_key: p.parent_period_key,
    })),
  });
}

async function handleFinalize(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  if (!sync_id) throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` obrigatório.", httpStatus: 400, retryable: false });
  const run = await loadRun(sync_id);
  const parts = await loadParts(sync_id);
  const activeParts = parts.filter((p) => !p.parent_period_key || p.split_into == null || p.split_into.length === 0);
  const pending = activeParts.filter((p) => !["success", "failed"].includes(p.status));
  const failed = activeParts.filter((p) => p.status === "failed");
  if (pending.length) {
    throw new SyncError({
      code: "PERIODS_PENDING", stage: "compare_supabase",
      message: `${pending.length} período(s) ainda pendentes.`,
      details: { pending: pending.map((p) => p.period_key) },
      httpStatus: 409, retryable: true,
    });
  }
  if (failed.length) {
    throw new SyncError({
      code: "PERIODS_FAILED", stage: "compare_supabase",
      message: `${failed.length} período(s) com falha. Retente ou use split_period.`,
      details: { failed: failed.map((p) => ({ period_key: p.period_key, error_code: p.error_code })) },
      httpStatus: 409, retryable: true,
    });
  }

  await updateRun(sync_id, { status: "consolidating", heartbeat_at: new Date().toISOString() });

  const { data: analysis, error: rpcErr } = await admin.rpc("fn_analyze_aeasy_tracking_snapshot", { p_sync_id: sync_id });
  if (rpcErr) throw new SyncError({ code: "ANALYZE_RPC_FAILED", stage: "compare_supabase", message: rpcErr.message });

  const consolidated_total = (analysis as any)?.consolidated_total ?? 0;
  const official_total = run.official_total as number | null;
  const tolerance = official_total ? Math.max(25, Math.round(official_total * 0.001)) : 0;
  const total_difference = official_total != null ? consolidated_total - official_total : null;
  const aeasy_total_match = official_total != null && Math.abs(total_difference as number) <= tolerance;

  // Backward year expansion: if consolidated < official, add previous year and go back to collecting.
  const earliestYear = Math.min(...activeParts.map((p) => p.period_year ?? 9999));
  const backward_used = activeParts.filter((p) => (p.period_year ?? 0) < SYNC_START_YEAR).length;
  const missingCount = official_total != null ? official_total - consolidated_total : 0;
  const canExpand = official_total != null && missingCount > tolerance
    && earliestYear > 2000 && backward_used < MAX_BACKWARD_YEARS;

  if (canExpand) {
    const y = earliestYear - 1;
    const currentYear = new Date().getUTCFullYear();
    const newPeriod = periodForYear(y, currentYear);
    const { error: partErr } = await admin.from("aeasy_sync_parts").insert({ sync_id, ...newPeriod, status: "pending" });
    if (partErr && !/duplicate key/i.test(partErr.message)) {
      throw new SyncError({ code: "BACKWARD_PART_INSERT_FAILED", stage: "compare_supabase", message: partErr.message });
    }
    await updateRun(sync_id, {
      status: "collecting", periods_total: (run.periods_total ?? 0) + 1,
      analysis, consolidated_total, heartbeat_at: new Date().toISOString(),
    });
    return jsonResponse({
      ok: true, sync_id, status: "collecting", reason: "backward_expansion",
      new_period: newPeriod, official_total, consolidated_total, missing: missingCount,
    });
  }

  // Compute readiness checks.
  const dup_conflict = (analysis as any)?.duplicates_conflict ?? 0;
  const stat = run.statuses_detected as any;
  const statuses_ok = Array.isArray(stat?.aceitas) && stat.aceitas.length === 3 && stat.aceitas.every((s: any) => s?.id);
  const identity_ok = true; // strategy percentage no longer tracked at run level (kept for compat)
  const duplicates_ok = dup_conflict === 0;
  const xlsx_ok = activeParts.every((p) => (p.file_size_bytes ?? 0) > 0);
  const columns_ok = activeParts.every((p) => p.status === "success");
  const ready_to_apply = statuses_ok && duplicates_ok && xlsx_ok && columns_ok && aeasy_total_match;

  const finalAnalysis = {
    ...(analysis as any),
    official_total, consolidated_total, total_difference, aeasy_total_match,
    tolerance_absoluta: tolerance,
    checks: { session_ok: true, statuses_ok, columns_ok, xlsx_ok, all_periods_ok: columns_ok,
      identity_ok, duplicates_ok, aeasy_total_match },
  };

  // Finalize NEVER applies. It parks the run in a terminal-for-analysis state.
  // For apply mode, we transition to `ready` and require an explicit `apply` action.
  const finalizedStatus = run.run_mode === "apply" && ready_to_apply ? "ready" : "success";
  await updateRun(sync_id, {
    status: finalizedStatus,
    finished_at: finalizedStatus === "success" ? new Date().toISOString() : null,
    analysis: finalAnalysis, consolidated_total, ready_to_apply,
  });
  return jsonResponse({
    ok: true, sync_id, status: finalizedStatus,
    mode: run.run_mode, ready_to_apply, analysis: finalAnalysis,
    apply_required: run.run_mode === "apply" && ready_to_apply,
  });
}

// APPLY — separate, idempotent, requires ready_to_apply from finalize.
async function handleApply(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  if (!sync_id) throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` obrigatório.", httpStatus: 400, retryable: false });
  const run = await loadRun(sync_id);

  if (run.run_mode !== "apply") {
    throw new SyncError({ code: "APPLY_MODE_REQUIRED", stage: "apply_snapshot", message: "Apply exige run_mode='apply'.", httpStatus: 409, retryable: false });
  }
  // Idempotência: já aplicado.
  if (run.status === "success" && run.ready_to_apply === true && run.inserted_count != null) {
    return jsonResponse({
      ok: true, sync_id, status: "success", already_applied: true,
      apply_summary: {
        inserted_count: run.inserted_count, updated_count: run.updated_count,
        unchanged_count: run.unchanged_count, missing_count: run.missing_count,
      },
      analysis: run.analysis,
    });
  }
  if (run.status !== "ready") {
    throw new SyncError({
      code: "APPLY_NOT_READY", stage: "apply_snapshot",
      message: `Apply exige status='ready' (atual='${run.status}'). Rode finalize primeiro.`,
      httpStatus: 409, retryable: false,
    });
  }
  if (run.ready_to_apply !== true) {
    throw new SyncError({ code: "APPLY_NOT_READY", stage: "apply_snapshot", message: "Checks de apply não passaram.", httpStatus: 409, retryable: false, details: (run.analysis as any)?.checks });
  }

  await updateRun(sync_id, { status: "applying", heartbeat_at: new Date().toISOString() });
  const { data: applyRes, error: applyErr } = await admin.rpc("fn_apply_aeasy_tracking_snapshot", { p_sync_id: sync_id });
  if (applyErr) {
    await updateRun(sync_id, {
      status: "failed", finished_at: new Date().toISOString(),
      error_code: "APPLY_RPC_FAILED", error_stage: "apply_snapshot", error_message: applyErr.message,
    });
    throw new SyncError({ code: "APPLY_RPC_FAILED", stage: "apply_snapshot", message: applyErr.message });
  }
  const summary = Array.isArray(applyRes) ? applyRes[0] : applyRes;
  await updateRun(sync_id, {
    status: "success", finished_at: new Date().toISOString(),
    inserted_count: summary?.inserted_count ?? 0,
    updated_count: summary?.updated_count ?? 0,
    unchanged_count: summary?.unchanged_count ?? 0,
    missing_count: summary?.missing_count ?? 0,
  });
  return jsonResponse({ ok: true, sync_id, status: "success", mode: "apply", apply_summary: summary });
}

// RETRY_PERIOD — limpa staging do período específico e volta para pending.
async function handleRetryPeriod(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  const period_key = String(body.period_key ?? "");
  if (!sync_id || !period_key) throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` e `period_key` obrigatórios.", httpStatus: 400, retryable: false });
  const run = await loadRun(sync_id);
  if (!["collecting", "consolidating", "ready"].includes(run.status)) {
    throw new SyncError({ code: "RUN_NOT_ACTIVE", stage: "lock", message: `Sincronização com status ${run.status} não permite retry.`, httpStatus: 409, retryable: false });
  }
  const part = await loadPart(sync_id, period_key);
  if (part.status === "success") {
    throw new SyncError({ code: "PART_ALREADY_SUCCESS", stage: "lock", message: `Período ${period_key} já concluído.`, httpStatus: 409, retryable: false });
  }
  if (part.status === "split") {
    throw new SyncError({ code: "PART_REPLACED_BY_SPLIT", stage: "lock", message: `Período ${period_key} foi dividido; use os filhos.`, httpStatus: 409, retryable: false });
  }
  if (IN_PROGRESS_STATUSES.has(part.status)) {
    const hb = part.started_at ? new Date(part.started_at).getTime() : 0;
    if (Date.now() - hb < STALE_MS) {
      throw new SyncError({ code: "PART_IN_PROGRESS", stage: "lock", message: "Período ainda em execução.", httpStatus: 409, retryable: true });
    }
  }
  await cleanStagingForPeriod(sync_id, period_key);
  await updatePart(sync_id, period_key, {
    status: "pending", started_at: null, finished_at: null, duration_ms: null,
    error_code: null, error_message: null,
    source_rows: 0, valid_rows: 0, invalid_rows: 0, discarded_status_rows: 0,
    file_name: null, file_size_bytes: null, file_checksum: null,
  });
  return jsonResponse({ ok: true, sync_id, period_key, status: "pending" });
}

// FIND_ACTIVE — fonte da verdade para retomada; localStorage é apenas ponteiro.
async function handleFindActive(_body: any): Promise<Response> {
  await releaseStaleRuns();
  const { data, error } = await admin
    .from("aeasy_sync_runs")
    .select("id, status, run_mode, started_at, heartbeat_at, official_total")
    .in("status", ["initializing", "collecting", "consolidating", "ready", "applying"])
    .order("started_at", { ascending: false })
    .limit(1).maybeSingle();
  if (error) throw new SyncError({ code: "FIND_ACTIVE_FAILED", stage: "unknown", message: error.message });
  return jsonResponse({ ok: true, active: data ?? null });
}

async function handleSplitPeriod(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  const period_key = String(body.period_key ?? "");
  if (!sync_id || !period_key) {
    throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` e `period_key` são obrigatórios.", httpStatus: 400, retryable: false });
  }
  const run = await loadRun(sync_id);
  if (!["collecting", "consolidating"].includes(run.status)) {
    throw new SyncError({ code: "RUN_NOT_ACTIVE", stage: "lock", message: `Sincronização com status ${run.status} não permite divisão.`, httpStatus: 409, retryable: false });
  }
  const part = await loadPart(sync_id, period_key);
  if (part.status === "success") {
    throw new SyncError({ code: "PART_ALREADY_SUCCESS", stage: "lock", message: `Período ${period_key} já foi processado com sucesso.`, httpStatus: 409, retryable: false });
  }
  if (part.granularity === "month") {
    throw new SyncError({ code: "PART_ALREADY_MONTHLY", stage: "lock", message: `Período ${period_key} já é mensal; não é possível dividir mais.`, httpStatus: 409, retryable: false });
  }

  const y = part.period_year as number;
  const currentYear = new Date().getUTCFullYear();
  const todayIso = todayISO();
  const clampEnd = (iso: string) => (iso > todayIso ? todayIso : iso);

  let subs: Array<{ period_key: string; period_year: number; granularity: string; date_start: string; date_end: string }> = [];
  if (part.granularity === "year") {
    subs = [
      { period_key: `${y}-Q1`, period_year: y, granularity: "quarter", date_start: `${y}-01-01`, date_end: clampEnd(`${y}-03-31`) },
      { period_key: `${y}-Q2`, period_year: y, granularity: "quarter", date_start: `${y}-04-01`, date_end: clampEnd(`${y}-06-30`) },
      { period_key: `${y}-Q3`, period_year: y, granularity: "quarter", date_start: `${y}-07-01`, date_end: clampEnd(`${y}-09-30`) },
      { period_key: `${y}-Q4`, period_year: y, granularity: "quarter", date_start: `${y}-10-01`, date_end: clampEnd(y === currentYear ? todayIso : `${y}-12-31`) },
    ].filter((s) => s.date_start <= s.date_end);
  } else {
    // quarter → months
    const qm: Record<string, [number, number]> = { Q1: [1, 3], Q2: [4, 6], Q3: [7, 9], Q4: [10, 12] };
    const q = period_key.split("-")[1] as keyof typeof qm;
    const [mFrom, mTo] = qm[q];
    for (let m = mFrom; m <= mTo; m++) {
      const mm = String(m).padStart(2, "0");
      const start = `${y}-${mm}-01`;
      const endDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
      const end = clampEnd(`${y}-${mm}-${String(endDay).padStart(2, "0")}`);
      if (start <= end) subs.push({ period_key: `${y}-${mm}`, period_year: y, granularity: "month", date_start: start, date_end: end });
    }
  }

  const inserts = subs.map((s) => ({ sync_id, ...s, status: "pending", parent_period_key: period_key }));
  const { error: insErr } = await admin.from("aeasy_sync_parts").insert(inserts);
  if (insErr && !/duplicate key/i.test(insErr.message)) {
    throw new SyncError({ code: "SPLIT_INSERT_FAILED", stage: "lock", message: insErr.message });
  }
  await updatePart(sync_id, period_key, {
    status: "split", split_into: subs.map((s) => s.period_key), error_code: "SPLIT_REQUIRED",
  });
  await updateRun(sync_id, {
    periods_total: (run.periods_total ?? 0) + subs.length,
    heartbeat_at: new Date().toISOString(),
  });
  return jsonResponse({ ok: true, sync_id, period_key, split_into: subs });
}

async function handleCancel(body: any): Promise<Response> {
  const sync_id = String(body.sync_id ?? "");
  if (!sync_id) throw new SyncError({ code: "INVALID_ARGS", stage: "request_validation", message: "`sync_id` obrigatório.", httpStatus: 400, retryable: false });
  const run = await loadRun(sync_id);
  if (["success", "failed", "cancelled"].includes(run.status)) {
    return jsonResponse({ ok: true, sync_id, status: run.status, already_terminal: true });
  }
  await updateRun(sync_id, {
    status: "cancelled", finished_at: new Date().toISOString(),
    error_code: "USER_CANCELLED", error_message: "Sincronização cancelada pelo usuário.",
  });
  return jsonResponse({ ok: true, sync_id, status: "cancelled" });
}

// ============================================================================
// Dispatcher
// ============================================================================

const ALLOWED_ACTIONS = new Set([
  "start", "process_period", "retry_period", "status", "finalize",
  "apply", "split_period", "cancel", "find_active",
]);

export function parseBody(raw: unknown): any {
  if (raw == null || typeof raw !== "object") throw new SyncError({ code: "INVALID_REQUEST_BODY", stage: "request_validation", message: "Corpo deve ser JSON objeto.", httpStatus: 400, retryable: false });
  const body = raw as Record<string, unknown>;
  const action = String(body.action ?? "");
  if (!ALLOWED_ACTIONS.has(action)) {
    throw new SyncError({ code: "INVALID_ACTION", stage: "request_validation", message: `Ação inválida. Aceitos: ${Array.from(ALLOWED_ACTIONS).join(", ")}.`, httpStatus: 400, retryable: false });
  }
  const allowedFields: Record<string, Set<string>> = {
    start: new Set(["action", "mode"]),
    process_period: new Set(["action", "sync_id", "period_key"]),
    retry_period: new Set(["action", "sync_id", "period_key"]),
    status: new Set(["action", "sync_id"]),
    finalize: new Set(["action", "sync_id"]),
    apply: new Set(["action", "sync_id"]),
    split_period: new Set(["action", "sync_id", "period_key"]),
    cancel: new Set(["action", "sync_id"]),
    find_active: new Set(["action"]),
  };
  const extra = Object.keys(body).filter((k) => !allowedFields[action].has(k));
  if (extra.length) throw new SyncError({ code: "INVALID_FIELDS", stage: "request_validation", message: `Campos não permitidos: ${extra.join(", ")}.`, httpStatus: 400, retryable: false });
  return body;
}

if (import.meta.main) Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS_HEADERS });
  if (req.method !== "POST") {
    return errorResponse(new SyncError({ code: "METHOD_NOT_ALLOWED", stage: "request_validation", message: "Method not allowed.", httpStatus: 405, retryable: false }));
  }

  let raw: unknown = {};
  try { raw = await req.json(); } catch { raw = {}; }

  const timeoutPromise = new Promise<Response>((resolve) => setTimeout(() =>
    resolve(errorResponse(new SyncError({
      code: "EDGE_FUNCTION_TIMEOUT", stage: "resource_limit",
      message: `Timeout: invocação excedeu ${Math.round(HARD_TIMEOUT_MS / 1000)}s.`,
      httpStatus: 504, retryable: true,
      details: "Considere `split_period` para dividir o período.",
    }))),
    HARD_TIMEOUT_MS));

  try {
    const body = parseBody(raw);
    const runOne = async () => {
      switch (body.action) {
        case "start": return await handleStart(body);
        case "process_period": return await handleProcessPeriod(body);
        case "retry_period": return await handleRetryPeriod(body);
        case "status": return await handleStatus(body);
        case "finalize": return await handleFinalize(body);
        case "apply": return await handleApply(body);
        case "split_period": return await handleSplitPeriod(body);
        case "cancel": return await handleCancel(body);
        case "find_active": return await handleFindActive(body);
        default: throw new SyncError({ code: "INVALID_ACTION", stage: "request_validation", message: "Ação inválida.", httpStatus: 400, retryable: false });
      }
    };
    return await Promise.race([timeoutPromise, runOne()]);
  } catch (e) {
    return errorResponse(toSyncError(e));
  }
});
