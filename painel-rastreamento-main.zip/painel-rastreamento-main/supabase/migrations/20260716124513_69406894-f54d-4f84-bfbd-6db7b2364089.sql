
-- 1) Restrict audit_logs INSERT so users can only log their own actions
DROP POLICY IF EXISTS "audit_logs insert" ON public.audit_logs;
CREATE POLICY "audit_logs insert"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- 2) Restrict role_permissions SELECT to admins only
DROP POLICY IF EXISTS "role_permissions select" ON public.role_permissions;
CREATE POLICY "role_permissions admin select"
ON public.role_permissions
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));
