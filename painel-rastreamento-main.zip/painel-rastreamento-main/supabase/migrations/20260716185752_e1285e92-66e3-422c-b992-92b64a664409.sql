-- Allow multiple staging rows for the same aeasy_source_id across different periods.
-- The dedup + conflict analysis happens later in fn_analyze_aeasy_tracking_snapshot.
ALTER TABLE public.aeasy_tracking_staging
  DROP CONSTRAINT IF EXISTS aeasy_tracking_staging_sync_id_aeasy_source_id_key;

-- Helpful lookup by (sync_id, period_key) already exists; add one on aeasy_source_id
-- restricted to a sync_id for the cross-period dedup step.
CREATE INDEX IF NOT EXISTS idx_aeasy_staging_source
  ON public.aeasy_tracking_staging (aeasy_source_id);