ALTER TABLE public.aeasy_sync_runs DROP CONSTRAINT IF EXISTS aeasy_sync_runs_status_check;
ALTER TABLE public.aeasy_sync_runs ADD CONSTRAINT aeasy_sync_runs_status_check
  CHECK (status = ANY (ARRAY['initializing','collecting','consolidating','ready','applying','success','failed','cancelled']));