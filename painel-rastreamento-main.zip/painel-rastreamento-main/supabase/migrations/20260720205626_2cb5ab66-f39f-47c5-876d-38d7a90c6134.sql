
-- =====================================================================
-- HARDENING DE PRIVILÉGIOS E RLS (auditoria completa)
-- Princípio: menor privilégio. RLS + GRANTs mínimos = defesa em profundidade.
-- =====================================================================

-- 1) Zerar todos os privilégios excessivos concedidos automaticamente
--    a anon/authenticated em todas as tabelas do schema public.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM authenticated;

-- Alterar defaults para que novas tabelas não recebam grants amplos.
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM anon, authenticated;

-- 2) Reconceder GRANTs mínimos a authenticated (SELECT/INSERT/UPDATE/DELETE).
--    RLS continua fazendo o filtro linha-a-linha; sem TRUNCATE/REFERENCES/TRIGGER/MAINTAIN.
GRANT SELECT, INSERT, UPDATE, DELETE ON public.associates            TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.audit_logs            TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chip_bindings         TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.device_bindings       TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.installations         TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.occurrence_notes      TO authenticated;
GRANT SELECT                          ON public.profiles             TO authenticated;
GRANT UPDATE                          ON public.profiles             TO authenticated;
GRANT SELECT                          ON public.role_permissions     TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.route_history         TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.route_points          TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_movements       TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_alerts       TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_api_errors   TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_chips        TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_devices      TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_events       TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_occurrences  TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_positions    TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_provider_settings TO authenticated;
GRANT SELECT                          ON public.tracking_service_providers TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_sync_logs    TO authenticated;
GRANT SELECT                          ON public.user_roles           TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles              TO authenticated;
-- AEasy: só leitura por admin via RLS; nada de escrita pelo cliente.
GRANT SELECT ON public.aeasy_sync_changes         TO authenticated;
GRANT SELECT ON public.aeasy_sync_parts           TO authenticated;
GRANT SELECT ON public.aeasy_sync_runs            TO authenticated;
GRANT SELECT ON public.aeasy_tracking_associados  TO authenticated;
GRANT SELECT ON public.aeasy_tracking_staging     TO authenticated;
-- integration_settings: nenhum acesso via API (apenas service_role).

-- 3) Anon: acesso público apenas à view sanitizada de prestadores.
--    A view usa security_invoker=true; anon precisa SELECT na base para
--    a view resolver, mas a policy da base já filtra colunas via view.
GRANT SELECT ON public.tracking_service_providers        TO anon;
GRANT SELECT ON public.public_tracking_service_providers TO anon;
GRANT SELECT ON public.public_tracking_service_providers TO authenticated;

-- 4) service_role continua com acesso total (bypass RLS por role).
GRANT ALL ON ALL TABLES    IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;

-- 5) integration_settings: adicionar policy admin-only explícita
--    (antes só existia RLS ativa sem policies — flag do linter).
DROP POLICY IF EXISTS "integration_settings admin all" ON public.integration_settings;
CREATE POLICY "integration_settings admin all"
  ON public.integration_settings
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));
-- Nenhum GRANT ao authenticated: só service_role escreve nesta tabela.
-- A policy fica documentada caso um admin precise ler via Data API no futuro.

-- 6) Revogar EXECUTE de anon em qualquer função pública (defesa em profundidade).
--    Mantém EXECUTE para authenticated apenas nos helpers de autorização
--    (has_role, has_permission, is_associate, current_associate_id) — sem eles
--    as próprias RLS policies deixam de funcionar.
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC;
-- Reafirmar os helpers necessários para RLS:
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role)          TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_permission(uuid, public.app_permission) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_associate(uuid)                       TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_associate_id()                   TO authenticated;
-- Funções internas de sync AEasy permanecem restritas a service_role (já estavam).
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO service_role;

-- 7) Índices de performance para consultas frequentes do painel.
CREATE INDEX IF NOT EXISTS idx_aeasy_assoc_situacao        ON public.aeasy_tracking_associados (situacao);
CREATE INDEX IF NOT EXISTS idx_aeasy_assoc_tipo_veiculo    ON public.aeasy_tracking_associados (tipo_veiculo);
CREATE INDEX IF NOT EXISTS idx_aeasy_assoc_cidade_uf       ON public.aeasy_tracking_associados (estado, cidade);
CREATE INDEX IF NOT EXISTS idx_aeasy_assoc_operacional     ON public.aeasy_tracking_associados (operacional) WHERE operacional = true;
CREATE INDEX IF NOT EXISTS idx_tsp_status                  ON public.tracking_service_providers (status);
CREATE INDEX IF NOT EXISTS idx_tsp_uf_cidade               ON public.tracking_service_providers (uf, cidade);
CREATE INDEX IF NOT EXISTS idx_user_roles_user             ON public.user_roles (user_id);
CREATE INDEX IF NOT EXISTS idx_aeasy_sync_parts_sync       ON public.aeasy_sync_parts (sync_id);
CREATE INDEX IF NOT EXISTS idx_aeasy_sync_changes_sync     ON public.aeasy_sync_changes (sync_id);
