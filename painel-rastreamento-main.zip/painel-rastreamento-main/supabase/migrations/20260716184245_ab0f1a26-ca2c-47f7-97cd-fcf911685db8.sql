
-- 1) Extend aeasy_sync_runs with segmented sync fields.
ALTER TABLE public.aeasy_sync_runs
  ADD COLUMN IF NOT EXISTS official_total integer,
  ADD COLUMN IF NOT EXISTS official_total_captured_at timestamptz,
  ADD COLUMN IF NOT EXISTS statuses_detected jsonb,
  ADD COLUMN IF NOT EXISTS periods_total integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS periods_completed integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS periods_failed integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS valid_rows_total integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS consolidated_total integer,
  ADD COLUMN IF NOT EXISTS error_code text,
  ADD COLUMN IF NOT EXISTS error_stage text,
  ADD COLUMN IF NOT EXISTS heartbeat_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS ready_to_apply boolean,
  ADD COLUMN IF NOT EXISTS analysis jsonb;

-- 2) Broaden the single-running lock so any active status blocks new runs.
DROP INDEX IF EXISTS public.idx_aeasy_runs_single_running;
CREATE UNIQUE INDEX idx_aeasy_runs_single_active
  ON public.aeasy_sync_runs ((1))
  WHERE status IN ('initializing','collecting','consolidating','ready','applying');

-- 3) Parts table: one row per period inside a sync run.
CREATE TABLE IF NOT EXISTS public.aeasy_sync_parts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sync_id uuid NOT NULL REFERENCES public.aeasy_sync_runs(id) ON DELETE CASCADE,
  period_key text NOT NULL,
  period_year integer,
  granularity text NOT NULL DEFAULT 'year',
  date_start date NOT NULL,
  date_end date NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempt integer NOT NULL DEFAULT 0,
  source_rows integer NOT NULL DEFAULT 0,
  valid_rows integer NOT NULL DEFAULT 0,
  invalid_rows integer NOT NULL DEFAULT 0,
  discarded_status_rows integer NOT NULL DEFAULT 0,
  duplicate_rows integer NOT NULL DEFAULT 0,
  file_name text,
  file_size_bytes integer,
  file_checksum text,
  started_at timestamptz,
  finished_at timestamptz,
  duration_ms integer,
  error_code text,
  error_message text,
  split_into text[],
  parent_period_key text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sync_id, period_key)
);
CREATE INDEX IF NOT EXISTS idx_aeasy_parts_sync ON public.aeasy_sync_parts(sync_id);
CREATE INDEX IF NOT EXISTS idx_aeasy_parts_status ON public.aeasy_sync_parts(sync_id, status);

GRANT SELECT ON public.aeasy_sync_parts TO anon, authenticated;
GRANT ALL ON public.aeasy_sync_parts TO service_role;

ALTER TABLE public.aeasy_sync_parts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read of sync parts" ON public.aeasy_sync_parts;
CREATE POLICY "Public read of sync parts"
  ON public.aeasy_sync_parts FOR SELECT
  TO anon, authenticated
  USING (true);

DROP TRIGGER IF EXISTS trg_aeasy_parts_updated_at ON public.aeasy_sync_parts;
CREATE TRIGGER trg_aeasy_parts_updated_at
  BEFORE UPDATE ON public.aeasy_sync_parts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4) Staging: add period tracking + source file metadata.
ALTER TABLE public.aeasy_tracking_staging
  ADD COLUMN IF NOT EXISTS period_key text,
  ADD COLUMN IF NOT EXISTS source_file_name text,
  ADD COLUMN IF NOT EXISTS source_file_checksum text;

CREATE INDEX IF NOT EXISTS idx_aeasy_staging_sync_period
  ON public.aeasy_tracking_staging(sync_id, period_key);
CREATE INDEX IF NOT EXISTS idx_aeasy_staging_sync_source
  ON public.aeasy_tracking_staging(sync_id, aeasy_source_id);

-- 5) Analysis RPC: computes all metrics from staging via SQL, no rows returned.
CREATE OR REPLACE FUNCTION public.fn_analyze_aeasy_tracking_snapshot(p_sync_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result jsonb;
BEGIN
  WITH
  -- Deduplicate staging by aeasy_source_id, keep last inserted per id.
  ranked AS (
    SELECT s.*,
      ROW_NUMBER() OVER (PARTITION BY aeasy_source_id ORDER BY created_at DESC, id DESC) AS rn,
      COUNT(*) OVER (PARTITION BY aeasy_source_id) AS occ
    FROM public.aeasy_tracking_staging s
    WHERE s.sync_id = p_sync_id
  ),
  unique_rows AS (
    SELECT * FROM ranked WHERE rn = 1
  ),
  dup_stats AS (
    SELECT
      COALESCE(SUM(GREATEST(occ - 1, 0)), 0)::int AS dup_rows,
      COALESCE(SUM(
        CASE WHEN occ > 1 AND EXISTS (
          SELECT 1 FROM ranked r2
          WHERE r2.aeasy_source_id = ranked.aeasy_source_id
          GROUP BY r2.aeasy_source_id
          HAVING COUNT(DISTINCT r2.row_hash) > 1
        ) THEN 1 ELSE 0 END
      ), 0)::int AS dup_conflict
    FROM ranked
  ),
  agg AS (
    SELECT
      COUNT(*)::int AS total,
      COUNT(*) FILTER (WHERE situacao = 'ativo')::int AS ativos,
      COUNT(*) FILTER (WHERE situacao = 'suspenso')::int AS suspensos,
      COUNT(*) FILTER (WHERE situacao = 'cancelado')::int AS cancelados,
      COUNT(*) FILTER (WHERE situacao NOT IN ('ativo','suspenso','cancelado'))::int AS outros,
      COUNT(*) FILTER (WHERE operacional)::int AS operacionais,
      COUNT(*) FILTER (WHERE rastreador_valido)::int AS com_rastreador,
      COUNT(*) FILTER (WHERE NOT rastreador_valido)::int AS sem_rastreador,
      COUNT(*) FILTER (WHERE situacao = 'cancelado' AND rastreador_valido)::int AS cancelados_com_rastreador,
      COUNT(*) FILTER (WHERE tipo_veiculo = 'carro')::int AS carro,
      COUNT(*) FILTER (WHERE tipo_veiculo = 'moto')::int AS moto,
      COUNT(*) FILTER (WHERE tipo_veiculo = 'caminhao')::int AS caminhao,
      COUNT(*) FILTER (WHERE COALESCE(tipo_veiculo,'nao_classificado') = 'nao_classificado')::int AS nao_classificado
    FROM unique_rows
  ),
  cmp AS (
    SELECT
      COUNT(*) FILTER (WHERE t.aeasy_source_id IS NULL)::int AS inserted_est,
      COUNT(*) FILTER (WHERE t.aeasy_source_id IS NOT NULL
                        AND t.row_hash IS DISTINCT FROM u.row_hash)::int AS updated_est,
      COUNT(*) FILTER (WHERE t.aeasy_source_id IS NOT NULL
                        AND t.row_hash IS NOT DISTINCT FROM u.row_hash)::int AS unchanged_est
    FROM unique_rows u
    LEFT JOIN public.aeasy_tracking_associados t
      ON t.aeasy_source_id = u.aeasy_source_id
  ),
  missing AS (
    SELECT COUNT(*)::int AS missing_est
    FROM public.aeasy_tracking_associados t
    WHERE NOT EXISTS (SELECT 1 FROM unique_rows u WHERE u.aeasy_source_id = t.aeasy_source_id)
  ),
  existing AS (
    SELECT COUNT(*)::int AS total_existing FROM public.aeasy_tracking_associados
  )
  SELECT jsonb_build_object(
    'consolidated_total', agg.total,
    'duplicates_removed', dup_stats.dup_rows,
    'duplicates_conflict', dup_stats.dup_conflict,
    'by_situacao', jsonb_build_object(
      'ativos', agg.ativos, 'suspensos', agg.suspensos,
      'cancelados', agg.cancelados, 'outros', agg.outros
    ),
    'operational', agg.operacionais,
    'by_tracker', jsonb_build_object(
      'valido', agg.com_rastreador, 'invalido', agg.sem_rastreador,
      'cancelados_com_rastreador_valido', agg.cancelados_com_rastreador
    ),
    'by_tipo', jsonb_build_object(
      'carro', agg.carro, 'moto', agg.moto,
      'caminhao', agg.caminhao, 'nao_classificado', agg.nao_classificado
    ),
    'compare_supabase', jsonb_build_object(
      'existing_total', existing.total_existing,
      'inserted_estimate', cmp.inserted_est,
      'updated_estimate', cmp.updated_est,
      'unchanged_estimate', cmp.unchanged_est,
      'missing_estimate', missing.missing_est
    )
  )
  INTO v_result
  FROM agg, dup_stats, cmp, missing, existing;

  RETURN v_result;
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_analyze_aeasy_tracking_snapshot(uuid) TO service_role;

-- 6) Stale-run release helper. Marks any active run without heartbeat in >20 min as failed.
CREATE OR REPLACE FUNCTION public.fn_release_stale_aeasy_runs()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
BEGIN
  WITH stale AS (
    UPDATE public.aeasy_sync_runs
    SET status = 'failed',
        finished_at = now(),
        error_code = COALESCE(error_code, 'RUN_STALE_RELEASED'),
        error_message = COALESCE(error_message,
          'Execução travada sem heartbeat por mais de 20 minutos — liberada automaticamente.')
    WHERE status IN ('initializing','collecting','consolidating','ready','applying')
      AND heartbeat_at < now() - INTERVAL '20 minutes'
    RETURNING id
  )
  SELECT COUNT(*)::int INTO v_count FROM stale;
  RETURN v_count;
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_release_stale_aeasy_runs() TO service_role;
