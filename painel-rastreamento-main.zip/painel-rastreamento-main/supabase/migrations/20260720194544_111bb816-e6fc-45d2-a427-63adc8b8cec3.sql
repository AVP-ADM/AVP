
-- Restrict AEasy internal tables to authenticated/admin users only.
DROP POLICY IF EXISTS "Public can view sync runs" ON public.aeasy_sync_runs;
DROP POLICY IF EXISTS "Public can view tracking data" ON public.aeasy_tracking_associados;
DROP POLICY IF EXISTS "Public read of sync parts" ON public.aeasy_sync_parts;

REVOKE SELECT ON public.aeasy_sync_runs FROM anon;
REVOKE SELECT ON public.aeasy_tracking_associados FROM anon;
REVOKE SELECT ON public.aeasy_sync_parts FROM anon;

-- Admin-only read for sync parts (aligns with sync runs admin policy).
CREATE POLICY "Admin can view sync parts"
  ON public.aeasy_sync_parts
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));

-- Revoke EXECUTE on internal SECURITY DEFINER helpers from anon/authenticated.
-- These are called only by service_role in edge functions.
REVOKE EXECUTE ON FUNCTION public.fn_apply_aeasy_tracking_snapshot(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_analyze_aeasy_tracking_snapshot(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_release_stale_aeasy_runs() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
