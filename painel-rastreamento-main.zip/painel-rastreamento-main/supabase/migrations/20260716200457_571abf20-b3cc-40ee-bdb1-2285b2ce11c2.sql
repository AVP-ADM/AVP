-- Cleanup: mark legacy "running" runs as failed. They predate the segmented refactor
-- and are not in the active-lock enum, so they don't block, but they clutter reports.
UPDATE public.aeasy_sync_runs
SET status = 'failed',
    finished_at = COALESCE(finished_at, now()),
    error_code = COALESCE(error_code, 'LEGACY_STATUS_CLEANED'),
    error_message = COALESCE(error_message, 'Run pré-refactor com status "running" limpo antes da homologação segmentada.')
WHERE status = 'running';