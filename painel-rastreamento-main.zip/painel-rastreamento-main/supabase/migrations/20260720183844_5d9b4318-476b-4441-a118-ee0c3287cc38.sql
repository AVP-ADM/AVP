
-- View com security_invoker: usa as permissões do chamador
ALTER VIEW public.public_tracking_service_providers SET (security_invoker = true);

-- Column-level grants: anon/authenticated só podem ler os campos seguros.
-- 'source_key' e 'created_at' permanecem inacessíveis por leitura pública.
GRANT SELECT (
  id, nome, cidade, uf, latitude, longitude, raio_atendimento_km,
  status, capacidade_mensal, tipos_atendidos, fonte,
  localizacao_aproximada, updated_at
) ON public.tracking_service_providers TO anon, authenticated;

-- Política de leitura pública (necessária para RLS retornar linhas ao anon)
DROP POLICY IF EXISTS "Public can read tracking providers" ON public.tracking_service_providers;
CREATE POLICY "Public can read tracking providers"
  ON public.tracking_service_providers
  FOR SELECT
  TO anon, authenticated
  USING (true);
