
-- 1. TABLE
CREATE TABLE IF NOT EXISTS public.tracking_service_providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  cidade text NOT NULL,
  uf text NOT NULL,
  latitude numeric,
  longitude numeric,
  raio_atendimento_km numeric NOT NULL DEFAULT 30 CHECK (raio_atendimento_km > 0),
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo','pendente','inativo')),
  capacidade_mensal integer CHECK (capacidade_mensal IS NULL OR capacidade_mensal >= 0),
  tipos_atendidos text[] CHECK (
    tipos_atendidos IS NULL
    OR tipos_atendidos <@ ARRAY['carro','moto','caminhao']::text[]
  ),
  fonte text,
  source_key text UNIQUE NOT NULL,
  localizacao_aproximada boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. GRANTS (writes only via service role; anon reads via view below)
GRANT ALL ON public.tracking_service_providers TO service_role;

-- 3. RLS enabled with no policies for anon/authenticated → all direct access blocked
ALTER TABLE public.tracking_service_providers ENABLE ROW LEVEL SECURITY;

-- 4. updated_at trigger
DROP TRIGGER IF EXISTS trg_tracking_service_providers_updated_at
  ON public.tracking_service_providers;
CREATE TRIGGER trg_tracking_service_providers_updated_at
BEFORE UPDATE ON public.tracking_service_providers
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5. Public read view (safe columns only)
CREATE OR REPLACE VIEW public.public_tracking_service_providers AS
SELECT
  id, nome, cidade, uf, latitude, longitude,
  raio_atendimento_km, status, capacidade_mensal, tipos_atendidos,
  fonte, localizacao_aproximada, updated_at
FROM public.tracking_service_providers;

GRANT SELECT ON public.public_tracking_service_providers TO anon, authenticated;

-- 6. Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.tracking_service_providers;

-- 7. Seed 20 providers
INSERT INTO public.tracking_service_providers
  (nome, cidade, uf, latitude, longitude, source_key, fonte, raio_atendimento_km, status, localizacao_aproximada)
VALUES
  ('IBS','Petrolina','PE',-9.3891,-40.5027,'ibs__petrolina__pe','mapa_anterior_avp',30,'ativo',true),
  ('Hiago','Recife','PE',-8.0476,-34.877,'hiago__recife__pe','mapa_anterior_avp',30,'ativo',true),
  ('Joas','Carpina','PE',-7.849,-35.253,'joas__carpina__pe','mapa_anterior_avp',30,'ativo',true),
  ('Nunes','Serra Talhada','PE',-7.9906,-38.2925,'nunes__serra talhada__pe','mapa_anterior_avp',30,'ativo',true),
  ('Laudisvan','Arapiraca','AL',-9.7519,-36.6614,'laudisvan__arapiraca__al','mapa_anterior_avp',30,'ativo',true),
  ('Cleysinho','Batalha','AL',-9.6753,-37.1272,'cleysinho__batalha__al','mapa_anterior_avp',30,'ativo',true),
  ('Mundial Radar','Feira de Santana','BA',-12.2664,-38.9663,'mundial radar__feira de santana__ba','mapa_anterior_avp',30,'ativo',true),
  ('Jean','Salvador','BA',-12.9714,-38.5014,'jean__salvador__ba','mapa_anterior_avp',30,'ativo',true),
  ('Box Car','Itabuna','BA',-14.7856,-39.2803,'box car__itabuna__ba','mapa_anterior_avp',30,'ativo',true),
  ('JS Rastreamento','Ilhéus','BA',-14.7935,-39.0463,'js rastreamento__ilheus__ba','mapa_anterior_avp',30,'ativo',true),
  ('Rafael Soares','Senhor do Bonfim','BA',-10.4614,-40.1897,'rafael soares__senhor do bonfim__ba','mapa_anterior_avp',30,'ativo',true),
  ('Leandro','Remanso','BA',-9.6203,-42.0797,'leandro__remanso__ba','mapa_anterior_avp',30,'ativo',true),
  ('Elite Parts','Mossoró','RN',-5.1875,-37.3441,'elite parts__mossoro__rn','mapa_anterior_avp',30,'ativo',true),
  ('Werick','Vitória','ES',-20.3155,-40.3128,'werick__vitoria__es','mapa_anterior_avp',30,'ativo',true),
  ('Marcelo','Juazeiro do Norte','CE',-7.213,-39.315,'marcelo__juazeiro do norte__ce','mapa_anterior_avp',30,'ativo',true),
  ('David Mendonca','Crato','CE',-7.2342,-39.4092,'david mendonca__crato__ce','mapa_anterior_avp',30,'ativo',true),
  ('Troia','Fortaleza','CE',-3.7319,-38.5267,'troia__fortaleza__ce','mapa_anterior_avp',30,'ativo',true),
  ('FI''CAR','Fortaleza','CE',-3.7319,-38.5267,'fi car__fortaleza__ce','mapa_anterior_avp',30,'ativo',true),
  ('Andre Moroni','Morada Nova','CE',-5.1064,-38.3722,'andre moroni__morada nova__ce','mapa_anterior_avp',30,'ativo',true),
  ('Jarlan','Queimada Nova','PI',-8.5772,-41.4053,'jarlan__queimada nova__pi','mapa_anterior_avp',30,'ativo',true)
ON CONFLICT (source_key) DO NOTHING;
