
-- =========================================================================
-- AEasy integration schema
-- =========================================================================

-- Main table: official base coming from AEasy
CREATE TABLE public.aeasy_tracking_associados (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  aeasy_source_id TEXT NOT NULL UNIQUE,
  aeasy_venda_id TEXT,
  aeasy_individuo_id TEXT,
  associado TEXT,
  placa TEXT,
  numero_rastreador TEXT,
  consultor TEXT,
  cidade TEXT,
  estado TEXT,
  plano TEXT,
  situacao TEXT,
  valor_fipe NUMERIC,
  categoria_original TEXT,
  tipo_veiculo TEXT CHECK (tipo_veiculo IN ('carro','moto','caminhao','nao_classificado')),
  rastreador_valido BOOLEAN NOT NULL DEFAULT false,
  operacional BOOLEAN NOT NULL DEFAULT false,
  row_hash TEXT NOT NULL,
  source_payload JSONB,
  first_synced_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_from_source_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_aeasy_assoc_cidade_uf ON public.aeasy_tracking_associados (estado, cidade);
CREATE INDEX idx_aeasy_assoc_situacao ON public.aeasy_tracking_associados (situacao);
CREATE INDEX idx_aeasy_assoc_tipo ON public.aeasy_tracking_associados (tipo_veiculo);

GRANT SELECT ON public.aeasy_tracking_associados TO authenticated;
GRANT ALL ON public.aeasy_tracking_associados TO service_role;

ALTER TABLE public.aeasy_tracking_associados ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read associados"
  ON public.aeasy_tracking_associados
  FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'monitoring')
    OR public.has_role(auth.uid(), 'installation')
    OR public.has_role(auth.uid(), 'stock')
    OR public.has_role(auth.uid(), 'read_only')
    OR public.has_role(auth.uid(), 'integration_tech')
  );

-- Sync runs (history)
CREATE TABLE public.aeasy_sync_runs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  status TEXT NOT NULL CHECK (status IN ('running','success','failed','cancelled')),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ,
  triggered_by UUID REFERENCES auth.users(id),
  source_total INTEGER,
  staging_total INTEGER,
  inserted_count INTEGER NOT NULL DEFAULT 0,
  updated_count INTEGER NOT NULL DEFAULT 0,
  unchanged_count INTEGER NOT NULL DEFAULT 0,
  missing_count INTEGER NOT NULL DEFAULT 0,
  duplicate_count INTEGER NOT NULL DEFAULT 0,
  invalid_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  error_message TEXT,
  duration_ms INTEGER,
  source_file_name TEXT,
  source_checksum TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_aeasy_runs_started ON public.aeasy_sync_runs (started_at DESC);
CREATE UNIQUE INDEX idx_aeasy_runs_single_running
  ON public.aeasy_sync_runs ((1))
  WHERE status = 'running';

GRANT SELECT ON public.aeasy_sync_runs TO authenticated;
GRANT ALL ON public.aeasy_sync_runs TO service_role;

ALTER TABLE public.aeasy_sync_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin can view sync runs"
  ON public.aeasy_sync_runs
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Staging (persistent per sync)
CREATE TABLE public.aeasy_tracking_staging (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sync_id UUID NOT NULL REFERENCES public.aeasy_sync_runs(id) ON DELETE CASCADE,
  aeasy_source_id TEXT NOT NULL,
  aeasy_venda_id TEXT,
  aeasy_individuo_id TEXT,
  associado TEXT,
  placa TEXT,
  numero_rastreador TEXT,
  consultor TEXT,
  cidade TEXT,
  estado TEXT,
  plano TEXT,
  situacao TEXT,
  valor_fipe NUMERIC,
  categoria_original TEXT,
  tipo_veiculo TEXT,
  rastreador_valido BOOLEAN,
  operacional BOOLEAN,
  row_hash TEXT,
  source_payload JSONB,
  validation_errors JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (sync_id, aeasy_source_id)
);

CREATE INDEX idx_aeasy_staging_sync ON public.aeasy_tracking_staging (sync_id);

GRANT SELECT ON public.aeasy_tracking_staging TO authenticated;
GRANT ALL ON public.aeasy_tracking_staging TO service_role;

ALTER TABLE public.aeasy_tracking_staging ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin can view staging"
  ON public.aeasy_tracking_staging
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Changes log
CREATE TABLE public.aeasy_sync_changes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sync_id UUID NOT NULL REFERENCES public.aeasy_sync_runs(id) ON DELETE CASCADE,
  aeasy_source_id TEXT NOT NULL,
  change_type TEXT NOT NULL CHECK (change_type IN ('inserted','updated')),
  changed_fields JSONB,
  previous_values JSONB,
  new_values JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_aeasy_changes_sync ON public.aeasy_sync_changes (sync_id);
CREATE INDEX idx_aeasy_changes_source ON public.aeasy_sync_changes (aeasy_source_id);

GRANT SELECT ON public.aeasy_sync_changes TO authenticated;
GRANT ALL ON public.aeasy_sync_changes TO service_role;

ALTER TABLE public.aeasy_sync_changes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin can view changes"
  ON public.aeasy_sync_changes
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- updated_at trigger for main table
CREATE TRIGGER trg_aeasy_assoc_updated_at
  BEFORE UPDATE ON public.aeasy_tracking_associados
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================================
-- RPC: apply staged snapshot atomically
-- =========================================================================
CREATE OR REPLACE FUNCTION public.fn_apply_aeasy_tracking_snapshot(p_sync_id UUID)
RETURNS TABLE (
  inserted_count INTEGER,
  updated_count INTEGER,
  unchanged_count INTEGER,
  missing_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted INTEGER := 0;
  v_updated INTEGER := 0;
  v_unchanged INTEGER := 0;
  v_missing INTEGER := 0;
BEGIN
  -- Advisory transactional lock: only one applier at a time
  PERFORM pg_advisory_xact_lock(hashtext('aeasy_apply_snapshot'));

  -- Insert new rows
  WITH ins AS (
    INSERT INTO public.aeasy_tracking_associados AS t (
      aeasy_source_id, aeasy_venda_id, aeasy_individuo_id, associado, placa,
      numero_rastreador, consultor, cidade, estado, plano, situacao,
      valor_fipe, categoria_original, tipo_veiculo, rastreador_valido,
      operacional, row_hash, source_payload, first_synced_at, updated_from_source_at
    )
    SELECT
      s.aeasy_source_id, s.aeasy_venda_id, s.aeasy_individuo_id, s.associado, s.placa,
      s.numero_rastreador, s.consultor, s.cidade, s.estado, s.plano, s.situacao,
      s.valor_fipe, s.categoria_original, s.tipo_veiculo, COALESCE(s.rastreador_valido,false),
      COALESCE(s.operacional,false), s.row_hash, s.source_payload, now(), now()
    FROM public.aeasy_tracking_staging s
    WHERE s.sync_id = p_sync_id
      AND NOT EXISTS (
        SELECT 1 FROM public.aeasy_tracking_associados t2
        WHERE t2.aeasy_source_id = s.aeasy_source_id
      )
    RETURNING aeasy_source_id, row_hash
  ), log_ins AS (
    INSERT INTO public.aeasy_sync_changes (sync_id, aeasy_source_id, change_type, new_values)
    SELECT p_sync_id, ins.aeasy_source_id, 'inserted',
           jsonb_build_object('row_hash', ins.row_hash)
    FROM ins
    RETURNING 1
  )
  SELECT count(*)::int INTO v_inserted FROM log_ins;

  -- Update changed rows (row_hash mismatch)
  WITH upd AS (
    UPDATE public.aeasy_tracking_associados t SET
      aeasy_venda_id = s.aeasy_venda_id,
      aeasy_individuo_id = s.aeasy_individuo_id,
      associado = s.associado,
      placa = s.placa,
      numero_rastreador = s.numero_rastreador,
      consultor = s.consultor,
      cidade = s.cidade,
      estado = s.estado,
      plano = s.plano,
      situacao = s.situacao,
      valor_fipe = s.valor_fipe,
      categoria_original = s.categoria_original,
      tipo_veiculo = s.tipo_veiculo,
      rastreador_valido = COALESCE(s.rastreador_valido,false),
      operacional = COALESCE(s.operacional,false),
      row_hash = s.row_hash,
      source_payload = s.source_payload,
      updated_from_source_at = now()
    FROM public.aeasy_tracking_staging s
    WHERE s.sync_id = p_sync_id
      AND s.aeasy_source_id = t.aeasy_source_id
      AND s.row_hash IS DISTINCT FROM t.row_hash
    RETURNING t.aeasy_source_id,
      jsonb_build_object(
        'situacao', t.situacao,
        'numero_rastreador', t.numero_rastreador,
        'plano', t.plano,
        'consultor', t.consultor,
        'cidade', t.cidade,
        'estado', t.estado,
        'tipo_veiculo', t.tipo_veiculo,
        'operacional', t.operacional,
        'rastreador_valido', t.rastreador_valido
      ) AS new_values
  ), log_upd AS (
    INSERT INTO public.aeasy_sync_changes (sync_id, aeasy_source_id, change_type, new_values)
    SELECT p_sync_id, upd.aeasy_source_id, 'updated', upd.new_values FROM upd
    RETURNING 1
  )
  SELECT count(*)::int INTO v_updated FROM log_upd;

  -- Count unchanged
  SELECT count(*)::int INTO v_unchanged
  FROM public.aeasy_tracking_staging s
  JOIN public.aeasy_tracking_associados t ON t.aeasy_source_id = s.aeasy_source_id
  WHERE s.sync_id = p_sync_id
    AND s.row_hash IS NOT DISTINCT FROM t.row_hash;

  -- Missing = in main but not in this snapshot
  SELECT count(*)::int INTO v_missing
  FROM public.aeasy_tracking_associados t
  WHERE NOT EXISTS (
    SELECT 1 FROM public.aeasy_tracking_staging s
    WHERE s.sync_id = p_sync_id AND s.aeasy_source_id = t.aeasy_source_id
  );

  inserted_count := v_inserted;
  updated_count := v_updated;
  unchanged_count := v_unchanged;
  missing_count := v_missing;
  RETURN NEXT;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_apply_aeasy_tracking_snapshot(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_apply_aeasy_tracking_snapshot(UUID) TO service_role;
