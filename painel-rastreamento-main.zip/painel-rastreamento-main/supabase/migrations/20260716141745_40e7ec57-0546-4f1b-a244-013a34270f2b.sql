-- Allow anonymous read access to the tracking dashboard data and sync history,
-- add run_mode / trigger metadata so the public sync endpoint can enforce
-- cooldowns without an authenticated user.

ALTER TABLE public.aeasy_sync_runs
  ADD COLUMN IF NOT EXISTS run_mode TEXT NOT NULL DEFAULT 'apply'
    CHECK (run_mode IN ('apply','dry_run')),
  ADD COLUMN IF NOT EXISTS trigger_type TEXT,
  ADD COLUMN IF NOT EXISTS trigger_ip_hash TEXT;

CREATE INDEX IF NOT EXISTS idx_aeasy_runs_mode_started
  ON public.aeasy_sync_runs (run_mode, started_at DESC);

-- Public (anonymous) read policies for the dashboard
GRANT SELECT ON public.aeasy_tracking_associados TO anon;
GRANT SELECT ON public.aeasy_sync_runs TO anon;

DROP POLICY IF EXISTS "Public can view tracking data" ON public.aeasy_tracking_associados;
CREATE POLICY "Public can view tracking data"
  ON public.aeasy_tracking_associados
  FOR SELECT TO anon
  USING (true);

DROP POLICY IF EXISTS "Public can view sync runs" ON public.aeasy_sync_runs;
CREATE POLICY "Public can view sync runs"
  ON public.aeasy_sync_runs
  FOR SELECT TO anon
  USING (true);