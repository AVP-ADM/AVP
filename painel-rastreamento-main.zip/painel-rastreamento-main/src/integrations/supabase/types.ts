export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      aeasy_sync_changes: {
        Row: {
          aeasy_source_id: string
          change_type: string
          changed_fields: Json | null
          created_at: string
          id: string
          new_values: Json | null
          previous_values: Json | null
          sync_id: string
        }
        Insert: {
          aeasy_source_id: string
          change_type: string
          changed_fields?: Json | null
          created_at?: string
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          sync_id: string
        }
        Update: {
          aeasy_source_id?: string
          change_type?: string
          changed_fields?: Json | null
          created_at?: string
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          sync_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "aeasy_sync_changes_sync_id_fkey"
            columns: ["sync_id"]
            isOneToOne: false
            referencedRelation: "aeasy_sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      aeasy_sync_parts: {
        Row: {
          attempt: number
          created_at: string
          date_end: string
          date_start: string
          discarded_status_rows: number
          duplicate_rows: number
          duration_ms: number | null
          error_code: string | null
          error_message: string | null
          file_checksum: string | null
          file_name: string | null
          file_size_bytes: number | null
          finished_at: string | null
          granularity: string
          id: string
          invalid_rows: number
          parent_period_key: string | null
          period_key: string
          period_year: number | null
          source_rows: number
          split_into: string[] | null
          started_at: string | null
          status: string
          sync_id: string
          updated_at: string
          valid_rows: number
        }
        Insert: {
          attempt?: number
          created_at?: string
          date_end: string
          date_start: string
          discarded_status_rows?: number
          duplicate_rows?: number
          duration_ms?: number | null
          error_code?: string | null
          error_message?: string | null
          file_checksum?: string | null
          file_name?: string | null
          file_size_bytes?: number | null
          finished_at?: string | null
          granularity?: string
          id?: string
          invalid_rows?: number
          parent_period_key?: string | null
          period_key: string
          period_year?: number | null
          source_rows?: number
          split_into?: string[] | null
          started_at?: string | null
          status?: string
          sync_id: string
          updated_at?: string
          valid_rows?: number
        }
        Update: {
          attempt?: number
          created_at?: string
          date_end?: string
          date_start?: string
          discarded_status_rows?: number
          duplicate_rows?: number
          duration_ms?: number | null
          error_code?: string | null
          error_message?: string | null
          file_checksum?: string | null
          file_name?: string | null
          file_size_bytes?: number | null
          finished_at?: string | null
          granularity?: string
          id?: string
          invalid_rows?: number
          parent_period_key?: string | null
          period_key?: string
          period_year?: number | null
          source_rows?: number
          split_into?: string[] | null
          started_at?: string | null
          status?: string
          sync_id?: string
          updated_at?: string
          valid_rows?: number
        }
        Relationships: [
          {
            foreignKeyName: "aeasy_sync_parts_sync_id_fkey"
            columns: ["sync_id"]
            isOneToOne: false
            referencedRelation: "aeasy_sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      aeasy_sync_runs: {
        Row: {
          analysis: Json | null
          consolidated_total: number | null
          created_at: string
          duplicate_count: number
          duration_ms: number | null
          error_code: string | null
          error_count: number
          error_message: string | null
          error_stage: string | null
          finished_at: string | null
          heartbeat_at: string
          id: string
          inserted_count: number
          invalid_count: number
          missing_count: number
          official_total: number | null
          official_total_captured_at: string | null
          periods_completed: number
          periods_failed: number
          periods_total: number
          ready_to_apply: boolean | null
          run_mode: string
          source_checksum: string | null
          source_file_name: string | null
          source_total: number | null
          staging_total: number | null
          started_at: string
          status: string
          statuses_detected: Json | null
          trigger_ip_hash: string | null
          trigger_type: string | null
          triggered_by: string | null
          unchanged_count: number
          updated_count: number
          valid_rows_total: number
        }
        Insert: {
          analysis?: Json | null
          consolidated_total?: number | null
          created_at?: string
          duplicate_count?: number
          duration_ms?: number | null
          error_code?: string | null
          error_count?: number
          error_message?: string | null
          error_stage?: string | null
          finished_at?: string | null
          heartbeat_at?: string
          id?: string
          inserted_count?: number
          invalid_count?: number
          missing_count?: number
          official_total?: number | null
          official_total_captured_at?: string | null
          periods_completed?: number
          periods_failed?: number
          periods_total?: number
          ready_to_apply?: boolean | null
          run_mode?: string
          source_checksum?: string | null
          source_file_name?: string | null
          source_total?: number | null
          staging_total?: number | null
          started_at?: string
          status: string
          statuses_detected?: Json | null
          trigger_ip_hash?: string | null
          trigger_type?: string | null
          triggered_by?: string | null
          unchanged_count?: number
          updated_count?: number
          valid_rows_total?: number
        }
        Update: {
          analysis?: Json | null
          consolidated_total?: number | null
          created_at?: string
          duplicate_count?: number
          duration_ms?: number | null
          error_code?: string | null
          error_count?: number
          error_message?: string | null
          error_stage?: string | null
          finished_at?: string | null
          heartbeat_at?: string
          id?: string
          inserted_count?: number
          invalid_count?: number
          missing_count?: number
          official_total?: number | null
          official_total_captured_at?: string | null
          periods_completed?: number
          periods_failed?: number
          periods_total?: number
          ready_to_apply?: boolean | null
          run_mode?: string
          source_checksum?: string | null
          source_file_name?: string | null
          source_total?: number | null
          staging_total?: number | null
          started_at?: string
          status?: string
          statuses_detected?: Json | null
          trigger_ip_hash?: string | null
          trigger_type?: string | null
          triggered_by?: string | null
          unchanged_count?: number
          updated_count?: number
          valid_rows_total?: number
        }
        Relationships: []
      }
      aeasy_tracking_associados: {
        Row: {
          aeasy_individuo_id: string | null
          aeasy_source_id: string
          aeasy_venda_id: string | null
          associado: string | null
          categoria_original: string | null
          cidade: string | null
          consultor: string | null
          created_at: string
          estado: string | null
          first_synced_at: string
          id: string
          numero_rastreador: string | null
          operacional: boolean
          placa: string | null
          plano: string | null
          rastreador_valido: boolean
          row_hash: string
          situacao: string | null
          source_payload: Json | null
          tipo_veiculo: string | null
          updated_at: string
          updated_from_source_at: string
          valor_fipe: number | null
        }
        Insert: {
          aeasy_individuo_id?: string | null
          aeasy_source_id: string
          aeasy_venda_id?: string | null
          associado?: string | null
          categoria_original?: string | null
          cidade?: string | null
          consultor?: string | null
          created_at?: string
          estado?: string | null
          first_synced_at?: string
          id?: string
          numero_rastreador?: string | null
          operacional?: boolean
          placa?: string | null
          plano?: string | null
          rastreador_valido?: boolean
          row_hash: string
          situacao?: string | null
          source_payload?: Json | null
          tipo_veiculo?: string | null
          updated_at?: string
          updated_from_source_at?: string
          valor_fipe?: number | null
        }
        Update: {
          aeasy_individuo_id?: string | null
          aeasy_source_id?: string
          aeasy_venda_id?: string | null
          associado?: string | null
          categoria_original?: string | null
          cidade?: string | null
          consultor?: string | null
          created_at?: string
          estado?: string | null
          first_synced_at?: string
          id?: string
          numero_rastreador?: string | null
          operacional?: boolean
          placa?: string | null
          plano?: string | null
          rastreador_valido?: boolean
          row_hash?: string
          situacao?: string | null
          source_payload?: Json | null
          tipo_veiculo?: string | null
          updated_at?: string
          updated_from_source_at?: string
          valor_fipe?: number | null
        }
        Relationships: []
      }
      aeasy_tracking_staging: {
        Row: {
          aeasy_individuo_id: string | null
          aeasy_source_id: string
          aeasy_venda_id: string | null
          associado: string | null
          categoria_original: string | null
          cidade: string | null
          consultor: string | null
          created_at: string
          estado: string | null
          id: string
          numero_rastreador: string | null
          operacional: boolean | null
          period_key: string | null
          placa: string | null
          plano: string | null
          rastreador_valido: boolean | null
          row_hash: string | null
          situacao: string | null
          source_file_checksum: string | null
          source_file_name: string | null
          source_payload: Json | null
          sync_id: string
          tipo_veiculo: string | null
          validation_errors: Json | null
          valor_fipe: number | null
        }
        Insert: {
          aeasy_individuo_id?: string | null
          aeasy_source_id: string
          aeasy_venda_id?: string | null
          associado?: string | null
          categoria_original?: string | null
          cidade?: string | null
          consultor?: string | null
          created_at?: string
          estado?: string | null
          id?: string
          numero_rastreador?: string | null
          operacional?: boolean | null
          period_key?: string | null
          placa?: string | null
          plano?: string | null
          rastreador_valido?: boolean | null
          row_hash?: string | null
          situacao?: string | null
          source_file_checksum?: string | null
          source_file_name?: string | null
          source_payload?: Json | null
          sync_id: string
          tipo_veiculo?: string | null
          validation_errors?: Json | null
          valor_fipe?: number | null
        }
        Update: {
          aeasy_individuo_id?: string | null
          aeasy_source_id?: string
          aeasy_venda_id?: string | null
          associado?: string | null
          categoria_original?: string | null
          cidade?: string | null
          consultor?: string | null
          created_at?: string
          estado?: string | null
          id?: string
          numero_rastreador?: string | null
          operacional?: boolean | null
          period_key?: string | null
          placa?: string | null
          plano?: string | null
          rastreador_valido?: boolean | null
          row_hash?: string | null
          situacao?: string | null
          source_file_checksum?: string | null
          source_file_name?: string | null
          source_payload?: Json | null
          sync_id?: string
          tipo_veiculo?: string | null
          validation_errors?: Json | null
          valor_fipe?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "aeasy_tracking_staging_sync_id_fkey"
            columns: ["sync_id"]
            isOneToOne: false
            referencedRelation: "aeasy_sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      associates: {
        Row: {
          address: string
          city: string
          created_at: string
          document: string
          email: string
          id: string
          name: string
          phone: string
          regional: string
          status: string
          updated_at: string
        }
        Insert: {
          address?: string
          city?: string
          created_at?: string
          document?: string
          email?: string
          id?: string
          name: string
          phone?: string
          regional?: string
          status?: string
          updated_at?: string
        }
        Update: {
          address?: string
          city?: string
          created_at?: string
          document?: string
          email?: string
          id?: string
          name?: string
          phone?: string
          regional?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          detail: string | null
          entity: string
          entity_id: string | null
          id: string
          user: string
          user_id: string | null
        }
        Insert: {
          action?: string
          created_at?: string
          detail?: string | null
          entity?: string
          entity_id?: string | null
          id?: string
          user?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          detail?: string | null
          entity?: string
          entity_id?: string | null
          id?: string
          user?: string
          user_id?: string | null
        }
        Relationships: []
      }
      chip_bindings: {
        Row: {
          chip_id: string
          created_at: string
          device_id: string
          ended_at: string | null
          id: string
          reason: string | null
          started_at: string
        }
        Insert: {
          chip_id: string
          created_at?: string
          device_id: string
          ended_at?: string | null
          id?: string
          reason?: string | null
          started_at?: string
        }
        Update: {
          chip_id?: string
          created_at?: string
          device_id?: string
          ended_at?: string | null
          id?: string
          reason?: string | null
          started_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "chip_bindings_chip_id_fkey"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chip_bindings_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
        ]
      }
      device_bindings: {
        Row: {
          created_at: string
          device_id: string
          ended_at: string | null
          id: string
          reason: string | null
          responsible: string
          started_at: string
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          device_id: string
          ended_at?: string | null
          id?: string
          reason?: string | null
          responsible?: string
          started_at?: string
          vehicle_id: string
        }
        Update: {
          created_at?: string
          device_id?: string
          ended_at?: string | null
          id?: string
          reason?: string | null
          responsible?: string
          started_at?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "device_bindings_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "device_bindings_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      installations: {
        Row: {
          associate_id: string | null
          checklist: Json
          chip_id: string | null
          communication_test_passed: boolean
          created_at: string
          device_id: string | null
          id: string
          installed_at: string | null
          installer: string
          notes: string | null
          provider_vehicle_id: string | null
          removed_at: string | null
          scheduled_at: string | null
          status: string
          updated_at: string
          vehicle_id: string | null
        }
        Insert: {
          associate_id?: string | null
          checklist?: Json
          chip_id?: string | null
          communication_test_passed?: boolean
          created_at?: string
          device_id?: string | null
          id?: string
          installed_at?: string | null
          installer?: string
          notes?: string | null
          provider_vehicle_id?: string | null
          removed_at?: string | null
          scheduled_at?: string | null
          status?: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Update: {
          associate_id?: string | null
          checklist?: Json
          chip_id?: string | null
          communication_test_passed?: boolean
          created_at?: string
          device_id?: string | null
          id?: string
          installed_at?: string | null
          installer?: string
          notes?: string | null
          provider_vehicle_id?: string | null
          removed_at?: string | null
          scheduled_at?: string | null
          status?: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "installations_associate_id_fkey"
            columns: ["associate_id"]
            isOneToOne: false
            referencedRelation: "associates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installations_chip_id_fkey"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installations_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installations_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      integration_settings: {
        Row: {
          base_url: string | null
          created_at: string
          encrypted_token: string | null
          id: string
          last_test_error: string | null
          last_test_status: string | null
          last_tested_at: string | null
          provider: string
          status: string
          token_last_four: string | null
          updated_at: string
          updated_by: string | null
          updated_by_name: string | null
        }
        Insert: {
          base_url?: string | null
          created_at?: string
          encrypted_token?: string | null
          id?: string
          last_test_error?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          provider: string
          status?: string
          token_last_four?: string | null
          updated_at?: string
          updated_by?: string | null
          updated_by_name?: string | null
        }
        Update: {
          base_url?: string | null
          created_at?: string
          encrypted_token?: string | null
          id?: string
          last_test_error?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          provider?: string
          status?: string
          token_last_four?: string | null
          updated_at?: string
          updated_by?: string | null
          updated_by_name?: string | null
        }
        Relationships: []
      }
      occurrence_notes: {
        Row: {
          author: string
          content: string
          created_at: string
          id: string
          occurrence_id: string
        }
        Insert: {
          author?: string
          content?: string
          created_at?: string
          id?: string
          occurrence_id: string
        }
        Update: {
          author?: string
          content?: string
          created_at?: string
          id?: string
          occurrence_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "occurrence_notes_occurrence_id_fkey"
            columns: ["occurrence_id"]
            isOneToOne: false
            referencedRelation: "tracking_occurrences"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          associate_id: string | null
          created_at: string
          email: string
          id: string
          name: string
          status: string
          updated_at: string
        }
        Insert: {
          associate_id?: string | null
          created_at?: string
          email?: string
          id: string
          name?: string
          status?: string
          updated_at?: string
        }
        Update: {
          associate_id?: string | null
          created_at?: string
          email?: string
          id?: string
          name?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_associate_id_fkey"
            columns: ["associate_id"]
            isOneToOne: false
            referencedRelation: "associates"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          id: string
          permission: Database["public"]["Enums"]["app_permission"]
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          id?: string
          permission: Database["public"]["Enums"]["app_permission"]
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          id?: string
          permission?: Database["public"]["Enums"]["app_permission"]
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
      route_history: {
        Row: {
          created_at: string
          distance_km: number
          end_date: string
          id: string
          max_speed: number
          moving_time_min: number
          no_comm_min: number
          provider: string
          start_date: string
          stopped_time_min: number
          stops: number
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          distance_km?: number
          end_date: string
          id?: string
          max_speed?: number
          moving_time_min?: number
          no_comm_min?: number
          provider?: string
          start_date: string
          stopped_time_min?: number
          stops?: number
          vehicle_id: string
        }
        Update: {
          created_at?: string
          distance_km?: number
          end_date?: string
          id?: string
          max_speed?: number
          moving_time_min?: number
          no_comm_min?: number
          provider?: string
          start_date?: string
          stopped_time_min?: number
          stops?: number
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "route_history_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      route_points: {
        Row: {
          gps_time: string
          id: string
          ignition: boolean
          latitude: number
          longitude: number
          route_id: string
          speed: number
        }
        Insert: {
          gps_time?: string
          id?: string
          ignition?: boolean
          latitude: number
          longitude: number
          route_id: string
          speed?: number
        }
        Update: {
          gps_time?: string
          id?: string
          ignition?: boolean
          latitude?: number
          longitude?: number
          route_id?: string
          speed?: number
        }
        Relationships: [
          {
            foreignKeyName: "route_points_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "route_history"
            referencedColumns: ["id"]
          },
        ]
      }
      stock_movements: {
        Row: {
          chip_id: string | null
          created_at: string
          destination: string
          device_id: string | null
          id: string
          notes: string | null
          origin: string
          reason: string
          type: string
          user: string
          vehicle_id: string | null
        }
        Insert: {
          chip_id?: string | null
          created_at?: string
          destination?: string
          device_id?: string | null
          id?: string
          notes?: string | null
          origin?: string
          reason?: string
          type: string
          user?: string
          vehicle_id?: string | null
        }
        Update: {
          chip_id?: string | null
          created_at?: string
          destination?: string
          device_id?: string | null
          id?: string
          notes?: string | null
          origin?: string
          reason?: string
          type?: string
          user?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "stock_movements_chip_id_fkey"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stock_movements_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stock_movements_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_alerts: {
        Row: {
          closed_at: string | null
          created_at: string
          id: string
          opened_at: string
          severity: string
          source: string
          status: string
          type: string
          updated_at: string
          vehicle_id: string
        }
        Insert: {
          closed_at?: string | null
          created_at?: string
          id?: string
          opened_at?: string
          severity?: string
          source?: string
          status?: string
          type: string
          updated_at?: string
          vehicle_id: string
        }
        Update: {
          closed_at?: string | null
          created_at?: string
          id?: string
          opened_at?: string
          severity?: string
          source?: string
          status?: string
          type?: string
          updated_at?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_alerts_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_api_errors: {
        Row: {
          code: string
          created_at: string
          endpoint: string
          id: string
          message: string
          provider: string
        }
        Insert: {
          code?: string
          created_at?: string
          endpoint?: string
          id?: string
          message?: string
          provider?: string
        }
        Update: {
          code?: string
          created_at?: string
          endpoint?: string
          id?: string
          message?: string
          provider?: string
        }
        Relationships: []
      }
      tracking_chips: {
        Row: {
          activation_date: string | null
          apn: string
          carrier: string
          created_at: string
          device_id: string | null
          iccid: string
          id: string
          line_number: string
          notes: string | null
          plan: string | null
          status: string
          updated_at: string
        }
        Insert: {
          activation_date?: string | null
          apn?: string
          carrier?: string
          created_at?: string
          device_id?: string | null
          iccid?: string
          id?: string
          line_number?: string
          notes?: string | null
          plan?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          activation_date?: string | null
          apn?: string
          carrier?: string
          created_at?: string
          device_id?: string | null
          iccid?: string
          id?: string
          line_number?: string
          notes?: string | null
          plan?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_chips_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_devices: {
        Row: {
          chip_id: string | null
          created_at: string
          entry_date: string | null
          id: string
          imei: string
          last_communication_at: string | null
          last_synced_status: string | null
          location: string
          manufacturer: string
          model: string
          notes: string | null
          provider: string
          provider_device_id: string | null
          responsible: string
          serial_number: string
          status: string
          supplier: string
          traccar_device_id: string | null
          traccar_last_lat: number | null
          traccar_last_lng: number | null
          traccar_last_seen_at: string | null
          traccar_last_speed: number | null
          traccar_last_status: string | null
          traccar_last_sync_at: string | null
          traccar_sync_error: string | null
          traccar_sync_status: string
          traccar_synced_at: string | null
          traccar_unique_id: string | null
          updated_at: string
          vehicle_id: string | null
        }
        Insert: {
          chip_id?: string | null
          created_at?: string
          entry_date?: string | null
          id?: string
          imei?: string
          last_communication_at?: string | null
          last_synced_status?: string | null
          location?: string
          manufacturer?: string
          model?: string
          notes?: string | null
          provider?: string
          provider_device_id?: string | null
          responsible?: string
          serial_number?: string
          status?: string
          supplier?: string
          traccar_device_id?: string | null
          traccar_last_lat?: number | null
          traccar_last_lng?: number | null
          traccar_last_seen_at?: string | null
          traccar_last_speed?: number | null
          traccar_last_status?: string | null
          traccar_last_sync_at?: string | null
          traccar_sync_error?: string | null
          traccar_sync_status?: string
          traccar_synced_at?: string | null
          traccar_unique_id?: string | null
          updated_at?: string
          vehicle_id?: string | null
        }
        Update: {
          chip_id?: string | null
          created_at?: string
          entry_date?: string | null
          id?: string
          imei?: string
          last_communication_at?: string | null
          last_synced_status?: string | null
          location?: string
          manufacturer?: string
          model?: string
          notes?: string | null
          provider?: string
          provider_device_id?: string | null
          responsible?: string
          serial_number?: string
          status?: string
          supplier?: string
          traccar_device_id?: string | null
          traccar_last_lat?: number | null
          traccar_last_lng?: number | null
          traccar_last_seen_at?: string | null
          traccar_last_speed?: number | null
          traccar_last_status?: string | null
          traccar_last_sync_at?: string | null
          traccar_sync_error?: string | null
          traccar_sync_status?: string
          traccar_synced_at?: string | null
          traccar_unique_id?: string | null
          updated_at?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tracking_devices_chip_fk"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_devices_vehicle_fk"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_events: {
        Row: {
          created_at: string
          device_id: string | null
          id: string
          occurred_at: string
          provider: string
          provider_event_id: string | null
          raw_payload: Json | null
          severity: string
          type: string
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          device_id?: string | null
          id?: string
          occurred_at?: string
          provider?: string
          provider_event_id?: string | null
          raw_payload?: Json | null
          severity?: string
          type: string
          vehicle_id: string
        }
        Update: {
          created_at?: string
          device_id?: string | null
          id?: string
          occurred_at?: string
          provider?: string
          provider_event_id?: string | null
          raw_payload?: Json | null
          severity?: string
          type?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_events_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_events_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_occurrences: {
        Row: {
          alert_id: string | null
          associate_id: string | null
          chip_id: string | null
          created_at: string
          device_id: string | null
          id: string
          opened_at: string
          provider: string
          provider_event_id: string | null
          raw_payload: Json | null
          responsible: string | null
          severity: string
          silence_reason: string | null
          source: string
          status: string
          type: string
          updated_at: string
          vehicle_id: string | null
        }
        Insert: {
          alert_id?: string | null
          associate_id?: string | null
          chip_id?: string | null
          created_at?: string
          device_id?: string | null
          id?: string
          opened_at?: string
          provider?: string
          provider_event_id?: string | null
          raw_payload?: Json | null
          responsible?: string | null
          severity?: string
          silence_reason?: string | null
          source?: string
          status?: string
          type: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Update: {
          alert_id?: string | null
          associate_id?: string | null
          chip_id?: string | null
          created_at?: string
          device_id?: string | null
          id?: string
          opened_at?: string
          provider?: string
          provider_event_id?: string | null
          raw_payload?: Json | null
          responsible?: string | null
          severity?: string
          silence_reason?: string | null
          source?: string
          status?: string
          type?: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tracking_occurrences_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "tracking_alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_occurrences_associate_id_fkey"
            columns: ["associate_id"]
            isOneToOne: false
            referencedRelation: "associates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_occurrences_chip_id_fkey"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_occurrences_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_occurrences_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_positions: {
        Row: {
          address: string | null
          battery: number
          created_at: string
          device_id: string | null
          gps_signal: number
          gps_time: string
          id: string
          ignition: boolean
          latitude: number
          longitude: number
          provider: string
          provider_position_id: string | null
          raw_payload: Json | null
          received_at: string
          speed: number
          vehicle_id: string
        }
        Insert: {
          address?: string | null
          battery?: number
          created_at?: string
          device_id?: string | null
          gps_signal?: number
          gps_time?: string
          id?: string
          ignition?: boolean
          latitude: number
          longitude: number
          provider?: string
          provider_position_id?: string | null
          raw_payload?: Json | null
          received_at?: string
          speed?: number
          vehicle_id: string
        }
        Update: {
          address?: string | null
          battery?: number
          created_at?: string
          device_id?: string | null
          gps_signal?: number
          gps_time?: string
          id?: string
          ignition?: boolean
          latitude?: number
          longitude?: number
          provider?: string
          provider_position_id?: string | null
          raw_payload?: Json | null
          received_at?: string
          speed?: number
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_positions_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_positions_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_provider_settings: {
        Row: {
          auth_type: string
          base_url: string
          created_at: string
          credentials_reference: string
          enabled: boolean
          field_mappings: Json
          id: string
          is_active: boolean
          last_sync_at: string | null
          mode: string
          name: string
          provider: string
          status: string
          sync_interval: number
          updated_at: string
        }
        Insert: {
          auth_type?: string
          base_url?: string
          created_at?: string
          credentials_reference?: string
          enabled?: boolean
          field_mappings?: Json
          id?: string
          is_active?: boolean
          last_sync_at?: string | null
          mode?: string
          name?: string
          provider: string
          status?: string
          sync_interval?: number
          updated_at?: string
        }
        Update: {
          auth_type?: string
          base_url?: string
          created_at?: string
          credentials_reference?: string
          enabled?: boolean
          field_mappings?: Json
          id?: string
          is_active?: boolean
          last_sync_at?: string | null
          mode?: string
          name?: string
          provider?: string
          status?: string
          sync_interval?: number
          updated_at?: string
        }
        Relationships: []
      }
      tracking_service_providers: {
        Row: {
          capacidade_mensal: number | null
          cidade: string
          created_at: string
          fonte: string | null
          id: string
          latitude: number | null
          localizacao_aproximada: boolean
          longitude: number | null
          nome: string
          raio_atendimento_km: number
          source_key: string
          status: string
          tipos_atendidos: string[] | null
          uf: string
          updated_at: string
        }
        Insert: {
          capacidade_mensal?: number | null
          cidade: string
          created_at?: string
          fonte?: string | null
          id?: string
          latitude?: number | null
          localizacao_aproximada?: boolean
          longitude?: number | null
          nome: string
          raio_atendimento_km?: number
          source_key: string
          status?: string
          tipos_atendidos?: string[] | null
          uf: string
          updated_at?: string
        }
        Update: {
          capacidade_mensal?: number | null
          cidade?: string
          created_at?: string
          fonte?: string | null
          id?: string
          latitude?: number | null
          localizacao_aproximada?: boolean
          longitude?: number | null
          nome?: string
          raio_atendimento_km?: number
          source_key?: string
          status?: string
          tipos_atendidos?: string[] | null
          uf?: string
          updated_at?: string
        }
        Relationships: []
      }
      tracking_sync_logs: {
        Row: {
          created_at: string
          duration_ms: number
          events_received: number
          id: string
          message: string | null
          positions_received: number
          provider: string
          status: string
          type: string
          vehicles_synced: number
        }
        Insert: {
          created_at?: string
          duration_ms?: number
          events_received?: number
          id?: string
          message?: string | null
          positions_received?: number
          provider?: string
          status?: string
          type?: string
          vehicles_synced?: number
        }
        Update: {
          created_at?: string
          duration_ms?: number
          events_received?: number
          id?: string
          message?: string | null
          positions_received?: number
          provider?: string
          status?: string
          type?: string
          vehicles_synced?: number
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          associate_id: string | null
          brand: string
          category: string
          chassis: string | null
          chip_id: string | null
          color: string
          created_at: string
          device_id: string | null
          id: string
          last_communication_at: string | null
          last_position_id: string | null
          last_sync_at: string | null
          model: string
          plate: string
          provider: string
          provider_vehicle_id: string | null
          renavam: string | null
          status: string
          tracking_status: string
          updated_at: string
          year: number
        }
        Insert: {
          associate_id?: string | null
          brand?: string
          category?: string
          chassis?: string | null
          chip_id?: string | null
          color?: string
          created_at?: string
          device_id?: string | null
          id?: string
          last_communication_at?: string | null
          last_position_id?: string | null
          last_sync_at?: string | null
          model?: string
          plate?: string
          provider?: string
          provider_vehicle_id?: string | null
          renavam?: string | null
          status?: string
          tracking_status?: string
          updated_at?: string
          year?: number
        }
        Update: {
          associate_id?: string | null
          brand?: string
          category?: string
          chassis?: string | null
          chip_id?: string | null
          color?: string
          created_at?: string
          device_id?: string | null
          id?: string
          last_communication_at?: string | null
          last_position_id?: string | null
          last_sync_at?: string | null
          model?: string
          plate?: string
          provider?: string
          provider_vehicle_id?: string | null
          renavam?: string | null
          status?: string
          tracking_status?: string
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_associate_id_fkey"
            columns: ["associate_id"]
            isOneToOne: false
            referencedRelation: "associates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicles_chip_id_fkey"
            columns: ["chip_id"]
            isOneToOne: false
            referencedRelation: "tracking_chips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicles_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "tracking_devices"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      public_tracking_service_providers: {
        Row: {
          capacidade_mensal: number | null
          cidade: string | null
          fonte: string | null
          id: string | null
          latitude: number | null
          localizacao_aproximada: boolean | null
          longitude: number | null
          nome: string | null
          raio_atendimento_km: number | null
          status: string | null
          tipos_atendidos: string[] | null
          uf: string | null
          updated_at: string | null
        }
        Insert: {
          capacidade_mensal?: number | null
          cidade?: string | null
          fonte?: string | null
          id?: string | null
          latitude?: number | null
          localizacao_aproximada?: boolean | null
          longitude?: number | null
          nome?: string | null
          raio_atendimento_km?: number | null
          status?: string | null
          tipos_atendidos?: string[] | null
          uf?: string | null
          updated_at?: string | null
        }
        Update: {
          capacidade_mensal?: number | null
          cidade?: string | null
          fonte?: string | null
          id?: string | null
          latitude?: number | null
          localizacao_aproximada?: boolean | null
          longitude?: number | null
          nome?: string | null
          raio_atendimento_km?: number | null
          status?: string | null
          tipos_atendidos?: string[] | null
          uf?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      current_associate_id: { Args: never; Returns: string }
      fn_analyze_aeasy_tracking_snapshot: {
        Args: { p_sync_id: string }
        Returns: Json
      }
      fn_apply_aeasy_tracking_snapshot: {
        Args: { p_sync_id: string }
        Returns: {
          inserted_count: number
          missing_count: number
          unchanged_count: number
          updated_count: number
        }[]
      }
      fn_release_stale_aeasy_runs: { Args: never; Returns: number }
      has_permission: {
        Args: {
          _perm: Database["public"]["Enums"]["app_permission"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_associate: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_permission:
        | "visualizar"
        | "criar"
        | "editar"
        | "excluir"
        | "exportar"
        | "tratar_ocorrencia"
        | "configurar_integracao"
        | "ver_payload_tecnico"
        | "revelar_dados_sensiveis"
      app_role:
        | "admin"
        | "monitoring"
        | "stock"
        | "installation"
        | "read_only"
        | "associate"
        | "integration_tech"
        | "pending"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_permission: [
        "visualizar",
        "criar",
        "editar",
        "excluir",
        "exportar",
        "tratar_ocorrencia",
        "configurar_integracao",
        "ver_payload_tecnico",
        "revelar_dados_sensiveis",
      ],
      app_role: [
        "admin",
        "monitoring",
        "stock",
        "installation",
        "read_only",
        "associate",
        "integration_tech",
        "pending",
      ],
    },
  },
} as const
