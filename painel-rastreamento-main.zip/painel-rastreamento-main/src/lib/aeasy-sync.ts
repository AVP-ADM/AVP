import { supabase } from "@/integrations/supabase/client";
import type { Associado } from "./types";
import { classifyTipoVeiculo, hasValidTracker } from "./classify";

// ============================================================================
// Types
// ============================================================================

export interface SyncPart {
  period_key: string;
  period_year: number | null;
  granularity: "year" | "quarter" | "month";
  date_start: string;
  date_end: string;
  status:
    | "pending" | "generating" | "downloading" | "processing" | "persisting"
    | "success" | "failed" | "split";
  attempt: number;
  source_rows: number;
  valid_rows: number;
  invalid_rows: number;
  discarded_status_rows: number;
  file_name: string | null;
  file_size_bytes: number | null;
  duration_ms: number | null;
  error_code: string | null;
  error_message: string | null;
  split_into: string[] | null;
  parent_period_key: string | null;
}

export interface SyncRun {
  sync_id: string;
  status:
    | "initializing" | "collecting" | "consolidating" | "ready"
    | "applying" | "success" | "failed" | "cancelled";
  run_mode: "dry_run" | "apply";
  official_total: number | null;
  official_total_captured_at: string | null;
  periods_total: number;
  periods_completed: number;
  periods_failed: number;
  valid_rows_total: number;
  consolidated_total: number | null;
  ready_to_apply: boolean | null;
  started_at: string;
  finished_at: string | null;
  heartbeat_at: string | null;
  error_code: string | null;
  error_stage: string | null;
  error_message: string | null;
  statuses_detected: unknown;
  analysis: Record<string, unknown> | null;
}

export interface SyncStatusResponse {
  ok: true;
  run: SyncRun;
  parts: SyncPart[];
}

export interface SyncErrorInfo extends Error {
  code?: string;
  stage?: string;
  period_key?: string | null;
  retryable?: boolean;
  details?: unknown;
  remaining_min?: number;
  status?: number;
  raw_body?: unknown;
}

const STORAGE_KEY = "aeasy_sync_current_id";

// ============================================================================
// Base helpers
// ============================================================================

async function invoke<T>(body: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.functions.invoke<T>("sync-aeasy", { body });
  if (error) {
    const ctx = (error as unknown as { context?: Response }).context;
    let payload: any = null;
    let rawText: string | undefined;
    let status: number | undefined;
    if (ctx && typeof (ctx as any).clone === "function") {
      status = (ctx as unknown as { status?: number }).status;
      try { payload = await (ctx as Response).clone().json(); }
      catch { try { rawText = await (ctx as Response).clone().text(); } catch { /* ignore */ } }
    }
    console.error("sync-aeasy error", { body, status, payload: payload ?? rawText, sdkMessage: error.message });
    const info: SyncErrorInfo = Object.assign(new Error(payload?.message || payload?.error || rawText || error.message), {
      code: payload?.code, stage: payload?.stage, period_key: payload?.period_key,
      retryable: payload?.retryable, details: payload?.details,
      remaining_min: payload?.remaining_min, status, raw_body: payload ?? rawText,
    });
    throw info;
  }
  if (!data) throw new Error("Resposta vazia da função sync-aeasy");
  return data;
}

// ============================================================================
// Persistence helpers
// ============================================================================

export function getStoredSyncId(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(STORAGE_KEY);
}
export function setStoredSyncId(id: string | null) {
  if (typeof window === "undefined") return;
  if (id) window.localStorage.setItem(STORAGE_KEY, id);
  else window.localStorage.removeItem(STORAGE_KEY);
}

// ============================================================================
// Actions
// ============================================================================

export interface StartResponse {
  ok: true;
  sync_id: string;
  status: "collecting";
  mode: "dry_run" | "apply";
  official_total: number | null;
  official_total_matched_pattern: string | null;
  situacoes: Array<{ nome: string; label: string; id: string }>;
  periods: Array<Pick<SyncPart, "period_key" | "period_year" | "granularity" | "date_start" | "date_end" | "status">>;
}

export async function startSync(mode: "dry_run" | "apply"): Promise<StartResponse> {
  const res = await invoke<StartResponse>({ action: "start", mode });
  setStoredSyncId(res.sync_id);
  return res;
}
export async function processPeriod(sync_id: string, period_key: string) {
  return invoke<{ ok: true; period_key: string; status: string; source_rows: number; valid_rows: number; duration_ms: number }>({
    action: "process_period", sync_id, period_key,
  });
}
export async function retryPeriod(sync_id: string, period_key: string) {
  return invoke<{ ok: true; period_key: string; status: "pending" }>({
    action: "retry_period", sync_id, period_key,
  });
}
export async function getSyncStatus(sync_id: string): Promise<SyncStatusResponse> {
  return invoke<SyncStatusResponse>({ action: "status", sync_id });
}
export async function finalizeSync(sync_id: string) {
  return invoke<any>({ action: "finalize", sync_id });
}
export async function applySync(sync_id: string) {
  return invoke<any>({ action: "apply", sync_id });
}
export async function findActiveSync(): Promise<{ ok: true; active: null | { id: string; status: string; run_mode: string; started_at: string; heartbeat_at: string | null; official_total: number | null } }> {
  return invoke({ action: "find_active" });
}
export async function splitPeriod(sync_id: string, period_key: string) {
  return invoke<{ ok: true; split_into: SyncPart[] }>({ action: "split_period", sync_id, period_key });
}
export async function cancelSync(sync_id: string) {
  const res = await invoke<{ ok: true; status: string }>({ action: "cancel", sync_id });
  setStoredSyncId(null);
  return res;
}

// ============================================================================
// Orchestrator — one call per period, sequential.
// ============================================================================

export interface OrchestrateEvents {
  onProgress?: (state: SyncStatusResponse) => void;
  onPartStart?: (part: SyncPart) => void;
  onPartError?: (part: SyncPart, err: SyncErrorInfo) => void;
  onFinalized?: (report: any) => void;
  intervalMs?: number;   // delay between periods
  maxRetries?: number;   // retries per period before split_period
}

/**
 * Drives an existing sync_id to completion, one period per invocation.
 * Handles retry + automatic split_period on resource limits, and calls
 * finalize when all periods are done (possibly re-entering collecting mode
 * for backward-year expansion).
 */
export async function orchestrateSync(
  sync_id: string,
  events: OrchestrateEvents = {},
): Promise<any> {
  const delay = events.intervalMs ?? 2000;
  const maxRetries = events.maxRetries ?? 2;
  const attempts = new Map<string, number>();

  // Emit an initial status so UI can render before any period is processed.
  const initial = await getSyncStatus(sync_id);
  events.onProgress?.(initial);
  if (["success", "failed", "cancelled"].includes(initial.run.status)) {
    return initial;
  }

  while (true) {
    const status = await getSyncStatus(sync_id);
    events.onProgress?.(status);

    if (["success", "failed", "cancelled"].includes(status.run.status)) return status;

    // Only process leaf pending parts — skip those that were replaced by splits.
    const splitParents = new Set(status.parts.filter((p) => p.status === "split").map((p) => p.period_key));
    const pending = status.parts.find((p) =>
      p.status === "pending"
      && !splitParents.has(p.period_key)
    );

    if (pending) {
      events.onPartStart?.(pending);
      const attempt = (attempts.get(pending.period_key) ?? 0) + 1;
      attempts.set(pending.period_key, attempt);
      try {
        await processPeriod(sync_id, pending.period_key);
      } catch (e) {
        const err = e as SyncErrorInfo;
        events.onPartError?.(pending, err);
        // Auto-split on resource limits after retries exhausted.
        if (err.code === "EDGE_FUNCTION_RESOURCE_LIMIT" || err.code === "EDGE_FUNCTION_TIMEOUT") {
          if (pending.granularity !== "month") {
            try { await splitPeriod(sync_id, pending.period_key); }
            catch (splitErr) { console.warn("split_period failed", splitErr); throw err; }
          } else {
            throw err;
          }
        } else if (attempt >= maxRetries) {
          throw err;
        }
      }
      await sleep(delay);
      continue;
    }

    // No pending leaves → try finalize. May bring us back to `collecting` for
    // backward-year expansion, which loops around naturally.
    const anyFailed = status.parts.some((p) => p.status === "failed");
    if (anyFailed) {
      const failed = status.parts.filter((p) => p.status === "failed");
      throw Object.assign(new Error(`${failed.length} período(s) falharam.`), {
        code: "PERIODS_FAILED",
        details: failed.map((p) => ({ period_key: p.period_key, error_code: p.error_code })),
      } as SyncErrorInfo);
    }
    const report = await finalizeSync(sync_id);
    events.onFinalized?.(report);
    // If finalize expanded backwards, keep looping.
    if (report?.status === "collecting") { await sleep(delay); continue; }
    return report;
  }
}

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }

// ============================================================================
// Legacy data-fetch helpers (unchanged, used by dashboard).
// ============================================================================

export async function fetchAssociadosFromSupabase(): Promise<Associado[]> {
  const rows: Associado[] = [];
  const PAGE = 1000;
  let from = 0;
  while (true) {
    const { data, error } = await supabase
      .from("aeasy_tracking_associados")
      .select(
        "associado,placa,numero_rastreador,consultor,cidade,estado,plano,situacao,valor_fipe,categoria_original,tipo_veiculo,rastreador_valido,operacional",
      )
      .range(from, from + PAGE - 1);
    if (error) throw error;
    if (!data || data.length === 0) break;
    for (const r of data) {
      const situacao = (r.situacao as string) || "outro";
      rows.push({
        associado: r.associado ?? "",
        placa: r.placa ?? "",
        numeroRastreador: r.numero_rastreador ?? "",
        consultor: r.consultor ?? "",
        cidade: r.cidade ?? "",
        estado: r.estado ?? "",
        plano: r.plano ?? "",
        situacao: (situacao === "ativo" || situacao === "suspenso" || situacao === "cancelado" ? situacao : "outro") as Associado["situacao"],
        situacaoOriginal: situacao,
        valorFipe: r.valor_fipe != null ? Number(r.valor_fipe) : null,
        categoria: r.categoria_original ?? "",
        categoriaOriginal: r.categoria_original ?? "",
        tipo: (r.tipo_veiculo ?? classifyTipoVeiculo(r.categoria_original ?? "")) as Associado["tipo"],
        temRastreador: r.rastreador_valido ?? hasValidTracker(r.numero_rastreador ?? ""),
        operacional: r.operacional ?? (situacao === "ativo" || situacao === "suspenso"),
      });
    }
    if (data.length < PAGE) break;
    from += PAGE;
  }
  return rows;
}

export interface SyncRunSummary {
  id: string;
  status: string;
  run_mode: string | null;
  started_at: string;
  finished_at: string | null;
  duration_ms: number | null;
  source_total: number | null;
  inserted_count: number;
  updated_count: number;
  unchanged_count: number;
  missing_count: number;
  duplicate_count: number;
  error_message: string | null;
}
export async function fetchLatestSyncRun(mode?: "apply" | "dry_run"): Promise<SyncRunSummary | null> {
  let q = supabase
    .from("aeasy_sync_runs")
    .select("id,status,run_mode,started_at,finished_at,duration_ms,source_total,inserted_count,updated_count,unchanged_count,missing_count,duplicate_count,error_message")
    .order("started_at", { ascending: false })
    .limit(1);
  if (mode) q = q.eq("run_mode", mode);
  const { data, error } = await q.maybeSingle();
  if (error) return null;
  return (data as SyncRunSummary) ?? null;
}
export async function fetchAssociadosTotal(): Promise<number> {
  const { count } = await supabase
    .from("aeasy_tracking_associados")
    .select("*", { count: "exact", head: true });
  return count ?? 0;
}
