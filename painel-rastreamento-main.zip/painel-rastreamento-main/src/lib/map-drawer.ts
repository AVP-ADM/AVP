// Helpers do drawer lateral do Mapa de Decisão.
// Extraem "região" (cidade, raio do prestador, raio da regra) e produzem
// resumos independentes usando aggregateCities. Isolados para testes.

import * as XLSX from "xlsx";
import { haversineKm } from "./calc";
import { lookupCoords } from "./city-coords";
import { normalizeUF } from "./classify";
import {
  aggregateCities,
  computeDuplicateTrackers,
  providersServingCity,
  type CityAgg,
  type MapFilter,
  type ProviderReach,
} from "./map-filter";
import { nivelRiscoManual } from "./map-filter";
import type { Associado, Prestador, RegraRisco, TipoVeiculo } from "./types";

export type DrawerMode = "cidade" | "prestador" | "regra";

export interface DrawerSelection {
  mode: DrawerMode;
  cidade?: string; // "Cidade|UF"
  prestadorId?: string;
  regraId?: string;
}

export function assocsInCity(assocs: Associado[], cidade: string, uf: string): Associado[] {
  const c = cidade.trim().toLowerCase();
  const u = normalizeUF(uf);
  return assocs.filter(
    (a) => (a.cidade ?? "").toLowerCase() === c && normalizeUF(a.estado) === u,
  );
}

export function assocsWithinRadius(
  assocs: Associado[],
  lat: number,
  lng: number,
  raioKm: number,
  tipoRestriction?: TipoVeiculo | "todos",
): Associado[] {
  const cache = new Map<string, [number, number] | null>();
  return assocs.filter((a) => {
    if (tipoRestriction && tipoRestriction !== "todos" && a.tipo !== tipoRestriction) return false;
    const key = `${a.cidade}|${a.estado}`;
    let c = cache.get(key);
    if (c === undefined) {
      c = lookupCoords(a.cidade, a.estado);
      cache.set(key, c);
    }
    if (!c) return false;
    return haversineKm(c[0], c[1], lat, lng) <= raioKm;
  });
}

export function citiesWithinRadius(
  assocs: Associado[],
  lat: number,
  lng: number,
  raioKm: number,
): Array<{ cidade: string; uf: string }> {
  const seen = new Set<string>();
  const out: Array<{ cidade: string; uf: string }> = [];
  const cache = new Map<string, [number, number] | null>();
  for (const a of assocs) {
    const key = `${a.cidade}|${a.estado}`;
    if (seen.has(key)) continue;
    let c = cache.get(key);
    if (c === undefined) {
      c = lookupCoords(a.cidade, a.estado);
      cache.set(key, c);
    }
    if (!c) continue;
    if (haversineKm(c[0], c[1], lat, lng) <= raioKm) {
      seen.add(key);
      out.push({ cidade: a.cidade, uf: a.estado });
    }
  }
  return out;
}

export interface DrawerSummary {
  total: number;
  ativos: number;
  suspensos: number;
  cancelados: number;
  operacionais: number;
  comRastreador: number;
  semRastreador: number;
  rastreadorInvalido: number;
  rastreadorDuplicado: number;
  canceladosComRastreador: number;
  carros: number;
  motos: number;
  caminhoes: number;
  naoClassificados: number;
  categorias: Array<{ categoria: string; total: number }>;
  cidades: Array<{ cidade: string; uf: string; total: number }>;
  coberturaPct: number;
  motivosInvalidos: Array<{ motivo: string; total: number }>;
}

export function computeDrawerSummary(assocs: Associado[]): DrawerSummary {
  const s: DrawerSummary = {
    total: assocs.length,
    ativos: 0, suspensos: 0, cancelados: 0, operacionais: 0,
    comRastreador: 0, semRastreador: 0, rastreadorInvalido: 0,
    rastreadorDuplicado: 0, canceladosComRastreador: 0,
    carros: 0, motos: 0, caminhoes: 0, naoClassificados: 0,
    categorias: [], cidades: [],
    coberturaPct: 0, motivosInvalidos: [],
  };
  const dupSet = computeDuplicateTrackers(assocs);
  const cats = new Map<string, number>();
  const cid = new Map<string, { cidade: string; uf: string; total: number }>();
  const motivos = new Map<string, number>();
  for (const a of assocs) {
    if (a.situacao === "ativo") s.ativos++;
    else if (a.situacao === "suspenso") s.suspensos++;
    else if (a.situacao === "cancelado") s.cancelados++;
    if (a.operacional) s.operacionais++;
    if (a.temRastreador) s.comRastreador++;
    else {
      s.semRastreador++;
      const raw = (a.numeroRastreador ?? "").toString().trim();
      if (raw) {
        s.rastreadorInvalido++;
        const norm = raw.toLowerCase();
        let motivo = "outro";
        if (/^0+$/.test(norm)) motivo = "somente zeros";
        else if (["sem", "nao", "não", "n/a", "na", "-", "null"].includes(norm)) motivo = "genérico";
        else if (/^-?\d+(\.\d+)?e[+\-]?\d+$/i.test(norm)) motivo = "notação científica";
        else if (/^\d+$/.test(norm)) motivo = "numérico não reconhecido";
        motivos.set(motivo, (motivos.get(motivo) || 0) + 1);
      }
    }
    if (a.situacao === "cancelado" && a.temRastreador) s.canceladosComRastreador++;
    if (a.temRastreador) {
      const key = (a.numeroRastreador ?? "").toString().toLowerCase().replace(/\s+/g, "");
      if (key && dupSet.has(key)) s.rastreadorDuplicado++;
    }
    if (a.tipo === "carro") s.carros++;
    else if (a.tipo === "moto") s.motos++;
    else if (a.tipo === "caminhao") s.caminhoes++;
    else s.naoClassificados++;
    if (a.categoriaOriginal) cats.set(a.categoriaOriginal, (cats.get(a.categoriaOriginal) || 0) + 1);
    if (a.cidade && a.estado) {
      const k = `${a.cidade}|${a.estado}`;
      const e = cid.get(k) ?? { cidade: a.cidade, uf: a.estado, total: 0 };
      e.total++;
      cid.set(k, e);
    }
  }
  s.categorias = Array.from(cats.entries())
    .map(([categoria, total]) => ({ categoria, total }))
    .sort((a, b) => b.total - a.total);
  s.cidades = Array.from(cid.values()).sort((a, b) => b.total - a.total);
  s.motivosInvalidos = Array.from(motivos.entries())
    .map(([motivo, total]) => ({ motivo, total }))
    .sort((a, b) => b.total - a.total);
  s.coberturaPct = s.total > 0 ? Math.round((s.comRastreador / s.total) * 1000) / 10 : 0;
  return s;
}

export function aggregateCitiesFromAssocs(assocs: Associado[]): CityAgg[] {
  return aggregateCities(assocs, computeDuplicateTrackers(assocs));
}

// Regra aplicada à cidade (ou centro), quando existir
export function regraDaCidade(
  lat: number | null,
  lng: number | null,
  regras: RegraRisco[],
  tipos: TipoVeiculo[] = [],
): RegraRisco | null {
  if (lat == null || lng == null) return null;
  const tiposConsulta: TipoVeiculo[] = tipos.length
    ? tipos
    : (["carro", "moto", "caminhao", "nao_classificado"] as TipoVeiculo[]);
  let best: { regra: RegraRisco; raio: number } | null = null;
  for (const t of tiposConsulta) {
    for (const r of regras) {
      if (r.status !== "ativa") continue;
      if (r.latCentral == null || r.lngCentral == null) continue;
      if (r.tipoVeiculo !== "todos" && r.tipoVeiculo !== t) continue;
      const d = haversineKm(lat, lng, r.latCentral, r.lngCentral);
      if (d <= r.raioKm) {
        if (!best || r.raioKm < best.raio) best = { regra: r, raio: r.raioKm };
      }
    }
  }
  return best?.regra ?? null;
}

// Prestadores que atendem lat/lng (Haversine + raio)
export function providersReaching(
  lat: number,
  lng: number,
  prestadores: Prestador[],
  filter: MapFilter,
): ProviderReach[] {
  return providersServingCity(lat, lng, prestadores, filter);
}

// Nível de risco por associado — reexport para o drawer
export function nivelRiscoAssociado(a: Associado, regras: RegraRisco[]) {
  return nivelRiscoManual(a, regras);
}

// Export XLSX específico do drawer (região selecionada)
export function exportDrawerXlsx(params: {
  filename: string;
  headerContext: Record<string, string | number>;
  assocs: Associado[];
  regras: RegraRisco[];
  prestadoresQueAtendem: ProviderReach[];
}) {
  const { filename, headerContext, assocs, regras, prestadoresQueAtendem } = params;
  const wb = XLSX.utils.book_new();
  const rows = assocs.map((a) => ({
    associado: a.associado,
    placa: a.placa,
    cidade: a.cidade,
    uf: a.estado,
    tipo: a.tipo,
    categoria_original: a.categoriaOriginal,
    situacao: a.situacao,
    tem_rastreador_valido: a.temRastreador ? "sim" : "nao",
    numero_rastreador: a.numeroRastreador,
    consultor: a.consultor,
    plano: a.plano,
    valor_fipe: a.valorFipe ?? "",
    risco_manual: nivelRiscoManual(a, regras),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Registros");
  const prestRows = prestadoresQueAtendem.map((r) => ({
    prestador: r.prestador.nome,
    cidade: r.prestador.cidade,
    uf: r.prestador.uf,
    distancia_km: r.distanciaKm,
    raio_km: r.prestador.raioKm,
    status: r.prestador.status,
    tipos: (r.prestador.tiposAtendidos ?? []).join(","),
    capacidade: r.prestador.capacidadeMensal ?? "",
    localizacao: r.prestador.localizacaoAproximada ? "aproximada" : "exata",
    compativel_com_filtro: r.compatibleWithTypes ? "sim" : "nao",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(prestRows), "Prestadores");
  const ctxRows = Object.entries(headerContext).map(([chave, valor]) => ({ chave, valor }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(ctxRows), "Contexto");
  XLSX.writeFile(wb, filename);
}
