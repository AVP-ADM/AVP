// Configuração pura das camadas do Mapa de Decisão.
// Extraída para permitir testes de contrato sem instanciar Leaflet.

export interface PaneCfg {
  name: string;
  z: number;
  interactive: boolean; // false ⇒ pane.style.pointerEvents = "none"
}

// Ordem, de baixo para cima:
// tiles(200) → risco(320) → raios(330) → cidades(450)
// → prestadores(500) → riscoMarkers(510) → selecionado(620)
export const PANE_CONFIG = {
  risco:         { name: "riskAreasPane",       z: 320, interactive: false },
  raios:         { name: "providerRadiusPane",  z: 330, interactive: false },
  cidades:       { name: "cityBubblesPane",     z: 450, interactive: true  },
  prestadores:   { name: "providerMarkersPane", z: 500, interactive: true  },
  riscoMarkers:  { name: "riskMarkersPane",     z: 510, interactive: true  },
  selecionado:   { name: "selectedPane",        z: 620, interactive: true  },
} satisfies Record<string, PaneCfg>;

// Opções compartilhadas: os círculos NUNCA capturam eventos.
export const NON_INTERACTIVE_CIRCLE = {
  interactive: false,
  bubblingMouseEvents: false,
} as const;

export const RISK_CIRCLE_STYLE = {
  fillOpacity: 0.05,
  opacity: 0.55,
  weight: 1.5,
} as const;

export const PROVIDER_RADIUS_STYLE = {
  fillOpacity: 0.0,
  opacity: 0.45,
  weight: 1,
  dashArray: "4 4",
} as const;
