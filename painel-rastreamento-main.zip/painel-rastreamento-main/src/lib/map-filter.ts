// Filtros avançados do Mapa de Decisão. Um único conjunto derivado
// `filteredAssociados` é a fonte de verdade para bolhas, popups, KPIs,
// contagens e exportação.

import { haversineKm, matchRegra } from "./calc";
import { cityKey, normalizeUF } from "./classify";
import { lookupCoords } from "./city-coords";
import {
  NIVEL_RISCO_LABEL,
  type Associado,
  type NivelRisco,
  type Prestador,
  type RegraRisco,
  type Situacao,
  type TipoVeiculo,
} from "./types";

export type RastreamentoStatus =
  | "com_valido"
  | "sem_valido"
  | "invalido"
  | "duplicado"
  | "cancelado_com_rast";

export type PrestadorStatus = "ativo" | "pendente" | "inativo";

export interface MapFilter {
  tipos: TipoVeiculo[]; // vazio = todos
  situacoes: Situacao[]; // default [ativo, suspenso]
  rastreamento: RastreamentoStatus[];
  riscos: NivelRisco[];
  categorias: string[]; // categoriaOriginal
  ufs: string[];
  cidades: string[]; // "Cidade|UF"
  dentroRiscoManual: boolean | null;
  dentroRaioPrestador: boolean | null;

  prestadorNomes: string[];
  prestadorStatus: PrestadorStatus[];
  prestadorAtende: TipoVeiculo[];
  prestadorCapacidade: "todas" | "com" | "sem";
}

export const DEFAULT_MAP_FILTER: MapFilter = {
  tipos: [],
  situacoes: ["ativo", "suspenso"],
  rastreamento: [],
  riscos: [],
  categorias: [],
  ufs: [],
  cidades: [],
  dentroRiscoManual: null,
  dentroRaioPrestador: null,
  prestadorNomes: [],
  prestadorStatus: ["ativo"],
  prestadorAtende: [],
  prestadorCapacidade: "todas",
};

const normNumero = (s: string) => (s ?? "").toString().toLowerCase().replace(/\s+/g, "");

export function computeDuplicateTrackers(assocs: Associado[]): Set<string> {
  const counts = new Map<string, number>();
  for (const a of assocs) {
    if (!a.temRastreador) continue;
    const k = normNumero(a.numeroRastreador);
    if (!k) continue;
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  const dup = new Set<string>();
  for (const [k, n] of counts) if (n > 1) dup.add(k);
  return dup;
}

export interface AdvancedFilterContext {
  regras: RegraRisco[];
  prestadores: Prestador[];
  duplicateTrackers: Set<string>;
}

function coordsOfAssoc(a: Associado): [number, number] | null {
  return lookupCoords(a.cidade, a.estado);
}

// Nível de risco manual de um associado (considerando seu tipo).
export function nivelRiscoManual(a: Associado, regras: RegraRisco[]): NivelRisco {
  const c = coordsOfAssoc(a);
  if (!c) return "sem_classificacao";
  const m = matchRegra(c[0], c[1], a.tipo, regras);
  return m ? m.regra.nivelRisco : "sem_classificacao";
}

export function applyAdvancedFilter(
  assocs: Associado[],
  f: MapFilter,
  ctx: AdvancedFilterContext,
): Associado[] {
  const prestativos = ctx.prestadores.filter(
    (p) => p.status === "ativo" && p.latitude != null && p.longitude != null,
  );
  const setUF = new Set(f.ufs);
  const setCity = new Set(f.cidades);
  const setCat = new Set(f.categorias);
  const setTipos = new Set(f.tipos);
  const setSit = new Set(f.situacoes);
  const setRisco = new Set(f.riscos);
  const setRast = new Set(f.rastreamento);

  // Cache por chave de cidade
  const nivelCache = new Map<string, NivelRisco>();
  const dentroRaioCache = new Map<string, boolean>();

  const needsNivel = setRisco.size > 0 || f.dentroRiscoManual !== null;
  const needsRaio = f.dentroRaioPrestador !== null;

  return assocs.filter((a) => {
    if (setTipos.size && !setTipos.has(a.tipo)) return false;
    if (setSit.size && !setSit.has(a.situacao)) return false;
    if (setUF.size && !setUF.has(a.estado)) return false;
    if (setCity.size && !setCity.has(`${a.cidade}|${a.estado}`)) return false;
    if (setCat.size && !setCat.has(a.categoriaOriginal)) return false;

    if (setRast.size) {
      const numero = normNumero(a.numeroRastreador);
      const temNumero = numero.length > 0;
      const dup = temNumero && ctx.duplicateTrackers.has(numero);
      const invalido = temNumero && !a.temRastreador;
      let match = false;
      for (const r of setRast) {
        if (r === "com_valido" && a.temRastreador) match = true;
        else if (r === "sem_valido" && !a.temRastreador) match = true;
        else if (r === "invalido" && invalido) match = true;
        else if (r === "duplicado" && dup) match = true;
        else if (r === "cancelado_com_rast" && a.situacao === "cancelado" && a.temRastreador) match = true;
        if (match) break;
      }
      if (!match) return false;
    }

    const ck = cityKey(a.cidade, a.estado);

    if (needsNivel) {
      let nivel = nivelCache.get(ck + ":" + a.tipo);
      if (nivel == null) {
        nivel = nivelRiscoManual(a, ctx.regras);
        nivelCache.set(ck + ":" + a.tipo, nivel);
      }
      if (setRisco.size && !setRisco.has(nivel)) return false;
      if (f.dentroRiscoManual === true && nivel === "sem_classificacao") return false;
      if (f.dentroRiscoManual === false && nivel !== "sem_classificacao") return false;
    }

    if (needsRaio) {
      let dentro = dentroRaioCache.get(ck);
      if (dentro == null) {
        const c = coordsOfAssoc(a);
        if (!c) dentro = false;
        else {
          dentro = false;
          for (const p of prestativos) {
            if (haversineKm(c[0], c[1], p.latitude!, p.longitude!) <= p.raioKm) {
              dentro = true;
              break;
            }
          }
        }
        dentroRaioCache.set(ck, dentro);
      }
      if (f.dentroRaioPrestador === true && !dentro) return false;
      if (f.dentroRaioPrestador === false && dentro) return false;
    }

    return true;
  });
}

// Filtro dos prestadores visíveis / considerados como sobreposição.
export function filterPrestadores(prestadores: Prestador[], f: MapFilter): Prestador[] {
  const nomes = new Set(f.prestadorNomes);
  const status = new Set(f.prestadorStatus);
  return prestadores.filter((p) => {
    if (nomes.size && !nomes.has(p.nome)) return false;
    if (status.size && !status.has(p.status)) return false;
    if (f.prestadorAtende.length) {
      const dec = p.tiposAtendidos ?? [];
      if (dec.length === 0) return false; // "não informado" nunca satisfaz filtro por tipo
      // OU entre tipos selecionados
      if (!f.prestadorAtende.some((t) => dec.includes(t))) return false;
    }
    if (f.prestadorCapacidade === "com" && p.capacidadeMensal == null) return false;
    if (f.prestadorCapacidade === "sem" && p.capacidadeMensal != null) return false;
    return true;
  });
}

// ============================================================
// Agregação por cidade (para bolhas e popup, sem risco manual)
// ============================================================
export interface CityAgg {
  cidade: string;
  uf: string;
  chave: string;
  lat: number | null;
  lng: number | null;
  total: number;
  ativos: number;
  suspensos: number;
  cancelados: number;
  comRastreador: number;
  semRastreador: number;
  rastreadorInvalido: number;
  carros: number;
  motos: number;
  caminhoes: number;
  naoClassificados: number;
  canceladosComRastreador: number;
}

export function aggregateCities(
  assocs: Associado[],
  duplicates: Set<string>,
): CityAgg[] {
  const m = new Map<string, CityAgg>();
  for (const a of assocs) {
    if (!a.cidade || !a.estado) continue;
    const key = cityKey(a.cidade, a.estado);
    let c = m.get(key);
    if (!c) {
      const coords = lookupCoords(a.cidade, a.estado);
      c = {
        cidade: a.cidade,
        uf: a.estado,
        chave: key,
        lat: coords ? coords[0] : null,
        lng: coords ? coords[1] : null,
        total: 0,
        ativos: 0,
        suspensos: 0,
        cancelados: 0,
        comRastreador: 0,
        semRastreador: 0,
        rastreadorInvalido: 0,
        carros: 0,
        motos: 0,
        caminhoes: 0,
        naoClassificados: 0,
        canceladosComRastreador: 0,
      };
      m.set(key, c);
    }
    c.total++;
    if (a.situacao === "ativo") c.ativos++;
    else if (a.situacao === "suspenso") c.suspensos++;
    else if (a.situacao === "cancelado") c.cancelados++;
    if (a.temRastreador) c.comRastreador++;
    else {
      c.semRastreador++;
      const raw = (a.numeroRastreador ?? "").toString().trim();
      if (raw) c.rastreadorInvalido++;
    }
    if (a.tipo === "carro") c.carros++;
    else if (a.tipo === "moto") c.motos++;
    else if (a.tipo === "caminhao") c.caminhoes++;
    else c.naoClassificados++;
    if (a.situacao === "cancelado" && a.temRastreador) c.canceladosComRastreador++;
    // duplicates unused here but reserved for future
    void duplicates;
  }
  return Array.from(m.values());
}

// ============================================================
// Prestadores que atendem uma cidade (Haversine + raio + tipo)
// ============================================================
export interface ProviderReach {
  prestador: Prestador;
  distanciaKm: number;
  compatibleWithTypes: boolean;
}

const cacheDistances = new Map<string, number>();

function keyDist(lat1: number, lng1: number, p: Prestador): string {
  return `${lat1.toFixed(4)}|${lng1.toFixed(4)}|${p.id}|${p.latitude?.toFixed(4)}|${p.longitude?.toFixed(4)}|${p.raioKm}`;
}

export function providersServingCity(
  cityLat: number,
  cityLng: number,
  prestadores: Prestador[],
  filter: MapFilter,
): ProviderReach[] {
  const out: ProviderReach[] = [];
  for (const p of prestadores) {
    if (p.latitude == null || p.longitude == null) continue;
    const k = keyDist(cityLat, cityLng, p);
    let d = cacheDistances.get(k);
    if (d == null) {
      d = haversineKm(cityLat, cityLng, p.latitude, p.longitude);
      cacheDistances.set(k, d);
    }
    if (d > p.raioKm) continue;
    let compat = true;
    if (filter.tipos.length) {
      const dec = p.tiposAtendidos ?? [];
      compat = dec.length > 0 && filter.tipos.some((t) => dec.includes(t));
    }
    out.push({ prestador: p, distanciaKm: Math.round(d * 10) / 10, compatibleWithTypes: compat });
  }
  out.sort((a, b) => a.distanciaKm - b.distanciaKm);
  return out;
}

// ============================================================
// Auditoria de rastreamento por cidade (Qualidade dos Dados)
// ============================================================
const GENERIC_TRACKERS = new Set([
  "sem", "semrast", "semrastreador", "n", "nao", "naopossui",
  "null", "undefined", "-", "na", "n/a",
]);

function maskValue(v: string, keep = 2): string {
  const s = (v ?? "").toString();
  if (!s) return "";
  if (s.length <= keep) return s + "*";
  return s.slice(0, keep) + "*".repeat(Math.max(2, s.length - keep));
}

export interface CityAuditReport {
  cidade: string;
  uf: string;
  filtros: { tipo: TipoVeiculo | "todos"; situacao: Situacao | "todos" };
  total: number;
  ativos: number;
  suspensos: number;
  cancelados: number;
  comRastreadorValido: number;
  semRastreador: number;
  rastreadorInvalido: number;
  rastreadorDuplicado: number;
  rastreadoresDistintos: number;
  vazios: number;
  zeros: number;
  genericos: number;
  numericos: number;
  notacaoCientifica: number;
  motos: {
    total: number;
    operacionais: number;
    ativas: number;
    suspensas: number;
    canceladas: number;
    comRastreador: number;
    semRastreador: number;
    invalidos: number;
    duplicados: number;
  };
  examples: Array<{
    tipo: TipoVeiculo;
    situacao: Situacao;
    placaMask: string;
    rastMask: string;
    motivo: string;
  }>;
}

export function auditCity(
  assocs: Associado[],
  cidade: string,
  uf: string,
  filters: { tipo?: TipoVeiculo | "todos"; situacao?: Situacao | "todos" } = {},
): CityAuditReport {
  const cUf = normalizeUF(uf);
  const cLower = cidade.trim().toLowerCase();
  const tipo = filters.tipo ?? "todos";
  const situacao = filters.situacao ?? "todos";

  const list = assocs.filter((a) => {
    if ((a.cidade ?? "").toLowerCase() !== cLower) return false;
    if (normalizeUF(a.estado) !== cUf) return false;
    if (tipo !== "todos" && a.tipo !== tipo) return false;
    if (situacao !== "todos" && a.situacao !== situacao) return false;
    return true;
  });

  const rep: CityAuditReport = {
    cidade,
    uf: cUf,
    filtros: { tipo, situacao },
    total: list.length,
    ativos: 0,
    suspensos: 0,
    cancelados: 0,
    comRastreadorValido: 0,
    semRastreador: 0,
    rastreadorInvalido: 0,
    rastreadorDuplicado: 0,
    rastreadoresDistintos: 0,
    vazios: 0,
    zeros: 0,
    genericos: 0,
    numericos: 0,
    notacaoCientifica: 0,
    motos: {
      total: 0, operacionais: 0, ativas: 0, suspensas: 0, canceladas: 0,
      comRastreador: 0, semRastreador: 0, invalidos: 0, duplicados: 0,
    },
    examples: [],
  };

  const dedup = new Map<string, number>();
  const dedupMoto = new Map<string, number>();

  for (const a of list) {
    if (a.situacao === "ativo") rep.ativos++;
    else if (a.situacao === "suspenso") rep.suspensos++;
    else if (a.situacao === "cancelado") rep.cancelados++;

    const raw = (a.numeroRastreador ?? "").toString();
    const trimmed = raw.trim();
    const norm = normNumero(trimmed);
    const isEmpty = !trimmed;
    const isZero = /^0+$/.test(norm);
    const isGeneric = GENERIC_TRACKERS.has(norm);
    const isSci = /^-?\d+(\.\d+)?e[+\-]?\d+$/i.test(trimmed);
    const isNum = /^\d+$/.test(trimmed);

    if (isEmpty) rep.vazios++;
    if (isZero) rep.zeros++;
    if (isGeneric) rep.genericos++;
    if (isSci) rep.notacaoCientifica++;
    else if (isNum) rep.numericos++;

    if (a.temRastreador) {
      rep.comRastreadorValido++;
      dedup.set(norm, (dedup.get(norm) || 0) + 1);
    } else {
      rep.semRastreador++;
      if (trimmed && !isEmpty) rep.rastreadorInvalido++;
    }

    if (a.tipo === "moto") {
      rep.motos.total++;
      if (a.situacao === "ativo") rep.motos.ativas++;
      else if (a.situacao === "suspenso") rep.motos.suspensas++;
      else if (a.situacao === "cancelado") rep.motos.canceladas++;
      if (a.operacional) rep.motos.operacionais++;
      if (a.temRastreador) {
        rep.motos.comRastreador++;
        dedupMoto.set(norm, (dedupMoto.get(norm) || 0) + 1);
      } else {
        rep.motos.semRastreador++;
        if (trimmed) rep.motos.invalidos++;
      }
    }

    if (rep.examples.length < 10) {
      const motivo = isEmpty
        ? "vazio"
        : isZero
          ? "zeros"
          : isGeneric
            ? "genérico"
            : isSci
              ? "notação científica"
              : a.temRastreador
                ? "válido"
                : "inválido";
      rep.examples.push({
        tipo: a.tipo,
        situacao: a.situacao,
        placaMask: maskValue(a.placa, 2),
        rastMask: maskValue(trimmed, 3),
        motivo,
      });
    }
  }
  for (const [, c] of dedup) if (c > 1) rep.rastreadorDuplicado += c;
  for (const [, c] of dedupMoto) if (c > 1) rep.motos.duplicados += c;
  rep.rastreadoresDistintos = dedup.size;

  return rep;
}

export function chipsFrom(f: MapFilter): Array<{ group: string; label: string; onRemove: keyof MapFilter | string }> {
  const chips: Array<{ group: string; label: string; onRemove: string }> = [];
  const push = (group: string, label: string, onRemove: string) => chips.push({ group, label, onRemove });
  for (const t of f.tipos) push("tipo", t, `tipo:${t}`);
  for (const s of f.situacoes) push("situacao", s, `situacao:${s}`);
  for (const r of f.rastreamento) push("rastreamento", r, `rastreamento:${r}`);
  for (const n of f.riscos) push("risco", n, `risco:${n}`);
  for (const c of f.categorias) push("categoria", c, `categoria:${c}`);
  for (const u of f.ufs) push("uf", u, `uf:${u}`);
  for (const c of f.cidades) push("cidade", c, `cidade:${c}`);
  if (f.dentroRiscoManual === true) push("localizacao", "Dentro de área de risco", "dentroRiscoManual");
  if (f.dentroRiscoManual === false) push("localizacao", "Fora de área de risco", "dentroRiscoManual");
  if (f.dentroRaioPrestador === true) push("localizacao", "Dentro do raio de prestador", "dentroRaioPrestador");
  if (f.dentroRaioPrestador === false) push("localizacao", "Sem prestador no raio", "dentroRaioPrestador");
  for (const n of f.prestadorNomes) push("prestador", n, `prestadorNomes:${n}`);
  for (const s of f.prestadorStatus) push("prestador", `status:${s}`, `prestadorStatus:${s}`);
  for (const t of f.prestadorAtende) push("prestador", `atende:${t}`, `prestadorAtende:${t}`);
  if (f.prestadorCapacidade !== "todas") push("prestador", `cap:${f.prestadorCapacidade}`, `prestadorCapacidade`);
  return chips;
}

export function removeChip(f: MapFilter, chip: string): MapFilter {
  const [key, val] = chip.split(":");
  const next: MapFilter = { ...f };
  const toggle = <T,>(arr: T[], v: T) => arr.filter((x) => x !== v);
  switch (key) {
    case "tipo": next.tipos = toggle(next.tipos, val as TipoVeiculo); break;
    case "situacao": next.situacoes = toggle(next.situacoes, val as Situacao); break;
    case "rastreamento": next.rastreamento = toggle(next.rastreamento, val as RastreamentoStatus); break;
    case "risco": next.riscos = toggle(next.riscos, val as NivelRisco); break;
    case "categoria": next.categorias = toggle(next.categorias, val); break;
    case "uf": next.ufs = toggle(next.ufs, val); break;
    case "cidade": next.cidades = toggle(next.cidades, val); break;
    case "dentroRiscoManual": next.dentroRiscoManual = null; break;
    case "dentroRaioPrestador": next.dentroRaioPrestador = null; break;
    case "prestadorNomes": next.prestadorNomes = toggle(next.prestadorNomes, val); break;
    case "prestadorStatus": next.prestadorStatus = toggle(next.prestadorStatus, val as PrestadorStatus); break;
    case "prestadorAtende": next.prestadorAtende = toggle(next.prestadorAtende, val as TipoVeiculo); break;
    case "prestadorCapacidade": next.prestadorCapacidade = "todas"; break;
  }
  return next;
}

// ============================================================
// Tooltips de hover (leves, respeitam filteredAssociados)
// ============================================================


const NIVEL_LABEL_HOVER: Record<NivelRisco, string> = NIVEL_RISCO_LABEL;

function escHover(s: unknown): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!
  ));
}

/** Nível de risco manual para a coordenada da cidade, respeitando precedência. */
export function nivelRiscoManualCidade(
  lat: number,
  lng: number,
  regras: RegraRisco[],
  tipos: TipoVeiculo[] = [],
): NivelRisco {
  const tiposConsulta: Array<TipoVeiculo> = tipos.length
    ? tipos
    : (["carro", "moto", "caminhao", "nao_classificado"] as TipoVeiculo[]);
  const order: NivelRisco[] = ["critico", "alto", "medio", "baixo", "sem_classificacao"];
  let best: NivelRisco = "sem_classificacao";
  for (const t of tiposConsulta) {
    const m = matchRegra(lat, lng, t, regras);
    const n = m ? m.regra.nivelRisco : "sem_classificacao";
    if (order.indexOf(n) < order.indexOf(best)) best = n;
  }
  return best;
}

/** Tooltip resumido para bolha da cidade — usa somente dados agregados do recorte. */
export function tooltipCidadeHtml(params: {
  cidade: CityAgg;
  filter: MapFilter;
  reachCount: number;
  nivelRisco: NivelRisco;
}): string {
  const { cidade: c, filter, reachCount, nivelRisco } = params;
  const showTipo = (t: TipoVeiculo) => filter.tipos.length === 0 || filter.tipos.includes(t);
  const showSit = (s: Situacao) => filter.situacoes.length === 0 || filter.situacoes.includes(s);
  const showRast = (r: RastreamentoStatus) =>
    filter.rastreamento.length === 0 || filter.rastreamento.includes(r);

  const linhas: string[] = [];
  linhas.push(`Registros no recorte: <b>${c.total}</b>`);
  if (showTipo("carro")) linhas.push(`Carros: <b>${c.carros}</b>`);
  if (showTipo("moto")) linhas.push(`Motos: <b>${c.motos}</b>`);
  if (showTipo("caminhao")) linhas.push(`Caminhões: <b>${c.caminhoes}</b>`);
  if (showTipo("nao_classificado") && c.naoClassificados > 0)
    linhas.push(`Não classificados: <b>${c.naoClassificados}</b>`);
  if (showSit("ativo")) linhas.push(`Ativos: <b>${c.ativos}</b>`);
  if (showSit("suspenso")) linhas.push(`Suspensos: <b>${c.suspensos}</b>`);
  if (showSit("cancelado") && c.cancelados > 0)
    linhas.push(`Cancelados: <b>${c.cancelados}</b>`);
  if (showRast("com_valido")) linhas.push(`Com rastreador: <b>${c.comRastreador}</b>`);
  if (showRast("sem_valido")) linhas.push(`Sem rastreador: <b>${c.semRastreador}</b>`);
  if (c.rastreadorInvalido > 0 && showRast("invalido"))
    linhas.push(`Inválidos: <b>${c.rastreadorInvalido}</b>`);
  linhas.push(`Prestadores que atendem: <b>${reachCount}</b>`);
  linhas.push(`Risco manual: <b>${NIVEL_LABEL_HOVER[nivelRisco]}</b>`);

  return `<div class="avp-tt"><div class="avp-tt-title">${escHover(c.cidade)}/${escHover(c.uf)}</div>
    <div class="avp-tt-body">${linhas.map((l) => `<div>${l}</div>`).join("")}</div></div>`;
}

export function tooltipPrestadorHtml(p: Prestador): string {
  const tipos = p.tiposAtendidos?.length
    ? p.tiposAtendidos.join(", ")
    : `<i style="color:#9ca3af">não informado</i>`;
  const cap = p.capacidadeMensal == null
    ? `<i style="color:#9ca3af">não informada</i>`
    : `${p.capacidadeMensal}/mês`;
  const loc = p.localizacaoAproximada ? "aproximada" : "exata";
  return `<div class="avp-tt"><div class="avp-tt-title">${escHover(p.nome)}</div>
    <div class="avp-tt-body">
      <div>${escHover(p.cidade)}/${escHover(p.uf)}</div>
      <div>Status: <b>${escHover(p.status)}</b></div>
      <div>Raio: <b>${p.raioKm} km</b></div>
      <div>Tipos: ${tipos}</div>
      <div>Capacidade: ${cap}</div>
      <div>Localização: ${loc}</div>
    </div></div>`;
}

export function tooltipRegraHtml(r: RegraRisco): string {
  const cor = ({
    sem_classificacao: "#9ca3af",
    baixo: "#16a34a",
    medio: "#eab308",
    alto: "#f97316",
    critico: "#dc2626",
  } as Record<NivelRisco, string>)[r.nivelRisco];
  const motivo = r.motivo
    ? `<div>Motivo: ${escHover(r.motivo)}</div>`
    : "";
  return `<div class="avp-tt"><div class="avp-tt-title">${escHover(r.nome || `${r.cidade}/${r.uf}`)}</div>
    <div class="avp-tt-body">
      <div>${escHover(r.cidade)}/${escHover(r.uf)}</div>
      <div>Risco: <b style="color:${cor}">${NIVEL_LABEL_HOVER[r.nivelRisco]}</b></div>
      <div>Política: <b>${escHover(r.politica)}</b></div>
      <div>Raio: <b>${r.raioKm} km</b></div>
      <div>Tipo: <b>${escHover(r.tipoVeiculo)}</b></div>
      ${motivo}
    </div></div>`;
}
