// Coordenadas aproximadas de cidades e capitais brasileiras.
// Formato da chave: "cidade normalizada__uf" (minusculo, sem acentos).

const RAW: Array<[string, string, number, number]> = [
  // Capitais
  ["Rio Branco", "AC", -9.9747, -67.8243],
  ["Maceio", "AL", -9.6658, -35.7353],
  ["Macapa", "AP", 0.0349, -51.0694],
  ["Manaus", "AM", -3.119, -60.0217],
  ["Salvador", "BA", -12.9714, -38.5014],
  ["Fortaleza", "CE", -3.7319, -38.5267],
  ["Brasilia", "DF", -15.7942, -47.8825],
  ["Vitoria", "ES", -20.3155, -40.3128],
  ["Goiania", "GO", -16.6869, -49.2648],
  ["Sao Luis", "MA", -2.5307, -44.3068],
  ["Cuiaba", "MT", -15.6014, -56.0979],
  ["Campo Grande", "MS", -20.4697, -54.6201],
  ["Belo Horizonte", "MG", -19.9167, -43.9345],
  ["Belem", "PA", -1.4558, -48.4902],
  ["Joao Pessoa", "PB", -7.1195, -34.845],
  ["Curitiba", "PR", -25.4284, -49.2733],
  ["Recife", "PE", -8.0476, -34.877],
  ["Teresina", "PI", -5.0919, -42.8034],
  ["Rio de Janeiro", "RJ", -22.9068, -43.1729],
  ["Natal", "RN", -5.7945, -35.211],
  ["Porto Alegre", "RS", -30.0346, -51.2177],
  ["Porto Velho", "RO", -8.7612, -63.9004],
  ["Boa Vista", "RR", 2.8235, -60.6758],
  ["Florianopolis", "SC", -27.5949, -48.548],
  ["Sao Paulo", "SP", -23.5505, -46.6333],
  ["Aracaju", "SE", -10.9472, -37.0731],
  ["Palmas", "TO", -10.1689, -48.3317],
  // Cidades do Nordeste com base operacional relevante
  ["Petrolina", "PE", -9.3891, -40.5027],
  ["Juazeiro", "BA", -9.4111, -40.4986],
  ["Itabuna", "BA", -14.7856, -39.2803],
  ["Juazeiro do Norte", "CE", -7.213, -39.315],
  ["Feira de Santana", "BA", -12.2664, -38.9663],
  ["Jaboatao dos Guararapes", "PE", -8.1128, -35.0148],
  ["Carpina", "PE", -7.849, -35.253],
  ["Arapiraca", "AL", -9.7519, -36.6614],
  ["Senhor do Bonfim", "BA", -10.4614, -40.1897],
  ["Caruaru", "PE", -8.2842, -35.9764],
  ["Garanhuns", "PE", -8.8828, -36.4967],
  ["Serra Talhada", "PE", -7.9906, -38.2925],
  ["Salgueiro", "PE", -8.0714, -39.1189],
  ["Ouricuri", "PE", -7.8811, -40.0819],
  ["Araripina", "PE", -7.5757, -40.4986],
  ["Belem do Sao Francisco", "PE", -8.7561, -38.9647],
  ["Cabrobo", "PE", -8.5133, -39.3131],
  ["Sertania", "PE", -8.0731, -37.2653],
  ["Afogados da Ingazeira", "PE", -7.7461, -37.6389],
  ["Vitoria de Santo Antao", "PE", -8.1189, -35.2919],
  ["Olinda", "PE", -8.0089, -34.855],
  ["Paulista", "PE", -7.9408, -34.8728],
  ["Igarassu", "PE", -7.8342, -34.9067],
  ["Camaragibe", "PE", -8.0217, -34.9781],
  ["Sao Lourenco da Mata", "PE", -8.0025, -35.0175],
  ["Cabo de Santo Agostinho", "PE", -8.2864, -35.0353],
  ["Ipojuca", "PE", -8.3997, -35.0631],
  ["Escada", "PE", -8.36, -35.2242],
  ["Palmares", "PE", -8.6836, -35.5919],
  ["Gravata", "PE", -8.2117, -35.5647],
  ["Bezerros", "PE", -8.2331, -35.7969],
  ["Santa Cruz do Capibaribe", "PE", -7.9575, -36.205],
  ["Toritama", "PE", -8.0072, -36.0575],
  ["Surubim", "PE", -7.8322, -35.7561],
  ["Limoeiro", "PE", -7.8747, -35.4497],
  ["Goiana", "PE", -7.5619, -35.0022],
  ["Timbauba", "PE", -7.5039, -35.3181],
  ["Nazare da Mata", "PE", -7.7422, -35.2244],
  ["Alagoinhas", "BA", -12.135, -38.4192],
  ["Barreiras", "BA", -12.1522, -44.99],
  ["Vitoria da Conquista", "BA", -14.8619, -40.8444],
  ["Ilheus", "BA", -14.7935, -39.0463],
  ["Teixeira de Freitas", "BA", -17.5395, -39.7422],
  ["Camacari", "BA", -12.6996, -38.3239],
  ["Lauro de Freitas", "BA", -12.8942, -38.3225],
  ["Simoes Filho", "BA", -12.7817, -38.4036],
  ["Paulo Afonso", "BA", -9.4053, -38.2214],
  ["Jequie", "BA", -13.856, -40.0831],
  ["Barra do Choca", "BA", -14.87, -40.5789],
  ["Guanambi", "BA", -14.2231, -42.7803],
  ["Irece", "BA", -11.3025, -41.8556],
  ["Jacobina", "BA", -11.181, -40.5111],
  ["Serrinha", "BA", -11.6644, -39.0075],
  ["Ribeira do Pombal", "BA", -10.8367, -38.5364],
  ["Euclides da Cunha", "BA", -10.5069, -39.0161],
  ["Casa Nova", "BA", -9.1614, -40.9711],
  ["Remanso", "BA", -9.6203, -42.0797],
  ["Sobradinho", "BA", -9.4508, -40.8206],
  ["Curaca", "BA", -8.9906, -39.9081],
  ["Cicero Dantas", "BA", -10.6, -38.3814],
  ["Sousa", "PB", -6.7597, -38.2278],
  ["Campina Grande", "PB", -7.2306, -35.8811],
  ["Patos", "PB", -7.0244, -37.28],
  ["Cajazeiras", "PB", -6.89, -38.5578],
  ["Guarabira", "PB", -6.855, -35.4903],
  ["Mossoro", "RN", -5.1875, -37.3441],
  ["Parnamirim", "RN", -5.9156, -35.2628],
  ["Caico", "RN", -6.4581, -37.0978],
  ["Currais Novos", "RN", -6.2611, -36.5142],
  ["Assu", "RN", -5.5772, -36.9086],
  ["Sobral", "CE", -3.6889, -40.3489],
  ["Crato", "CE", -7.2342, -39.4092],
  ["Iguatu", "CE", -6.3597, -39.2989],
  ["Caucaia", "CE", -3.7364, -38.6531],
  ["Maracanau", "CE", -3.8767, -38.6256],
  ["Maranguape", "CE", -3.89, -38.6853],
  ["Quixada", "CE", -4.9711, -39.0156],
  ["Quixeramobim", "CE", -5.1989, -39.2919],
  ["Russas", "CE", -4.9403, -37.9756],
  ["Barbalha", "CE", -7.3, -39.3025],
  ["Penedo", "AL", -10.2911, -36.5747],
  ["Palmeira dos Indios", "AL", -9.4053, -36.6289],
  ["Delmiro Gouveia", "AL", -9.3856, -37.9992],
  ["Sao Miguel dos Campos", "AL", -9.7811, -36.0947],
  ["Uniao dos Palmares", "AL", -9.1633, -36.0347],
  ["Rio Largo", "AL", -9.4783, -35.8583],
  ["Coruripe", "AL", -10.1258, -36.1747],
  ["Estancia", "SE", -11.2683, -37.4381],
  ["Itabaiana", "SE", -10.6853, -37.4258],
  ["Lagarto", "SE", -10.9172, -37.6675],
  ["Nossa Senhora do Socorro", "SE", -10.855, -37.1258],
  ["Sao Cristovao", "SE", -11.0158, -37.2064],
  ["Tobias Barreto", "SE", -11.1836, -37.9992],
  ["Parauapebas", "PA", -6.0678, -49.9019],
  ["Santarem", "PA", -2.4386, -54.6996],
  ["Maraba", "PA", -5.3689, -49.1178],
  ["Imperatriz", "MA", -5.5265, -47.4776],
  ["Caxias", "MA", -4.8586, -43.3556],
  ["Timon", "MA", -5.0942, -42.8367],
  ["Bacabal", "MA", -4.2247, -44.7811],
  ["Codo", "MA", -4.4553, -43.8858],
  // SP grandes
  ["Guarulhos", "SP", -23.4629, -46.5333],
  ["Campinas", "SP", -22.9099, -47.0626],
  ["Sao Bernardo do Campo", "SP", -23.6944, -46.565],
  ["Santo Andre", "SP", -23.6633, -46.5306],
  ["Osasco", "SP", -23.5325, -46.7917],
  ["Ribeirao Preto", "SP", -21.1704, -47.8103],
  ["Sorocaba", "SP", -23.5015, -47.4526],
  ["Sao Jose dos Campos", "SP", -23.2237, -45.9009],
  ["Santos", "SP", -23.9608, -46.3336],
  ["Bauru", "SP", -22.3149, -49.0605],
  // Sudeste outras
  ["Niteroi", "RJ", -22.8833, -43.1036],
  ["Duque de Caxias", "RJ", -22.7856, -43.3117],
  ["Nova Iguacu", "RJ", -22.7561, -43.4611],
  ["Sao Goncalo", "RJ", -22.8269, -43.0537],
  ["Uberlandia", "MG", -18.9128, -48.2755],
  ["Contagem", "MG", -19.9317, -44.0536],
  ["Juiz de Fora", "MG", -21.7647, -43.3497],
  // Cidades de prestadores AVP
  ["Batalha", "AL", -9.6753, -37.1272],
  ["Morada Nova", "CE", -5.1064, -38.3722],
  ["Queimada Nova", "PI", -8.5772, -41.4053],
];





// Centroides aproximados por UF para fallback
const UF_CENTROIDS: Record<string, [number, number]> = {
  AC: [-9.0479, -70.526],
  AL: [-9.5713, -36.782],
  AP: [1.4144, -51.7865],
  AM: [-4.148, -63.1815],
  BA: [-12.5797, -41.7007],
  CE: [-5.4984, -39.3206],
  DF: [-15.7998, -47.8645],
  ES: [-19.1834, -40.3089],
  GO: [-15.827, -49.8362],
  MA: [-4.9609, -45.2744],
  MT: [-12.6819, -56.9211],
  MS: [-20.7722, -54.7852],
  MG: [-18.5122, -44.555],
  PA: [-3.9018, -52.4805],
  PB: [-7.24, -36.782],
  PR: [-24.89, -51.5548],
  PE: [-8.8137, -36.9541],
  PI: [-7.7183, -42.7289],
  RJ: [-22.9099, -43.2094],
  RN: [-5.4026, -36.9541],
  RS: [-30.0346, -53.2],
  RO: [-11.5057, -63.5806],
  RR: [1.9985, -61.3308],
  SC: [-27.2423, -50.2189],
  SP: [-22.5, -48.5],
  SE: [-10.5741, -37.3857],
  TO: [-10.1753, -48.2982],
};

const normalize = (s: string) =>
  (s ?? "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

const MAP = new Map<string, [number, number]>();
for (const [c, uf, lat, lng] of RAW) {
  MAP.set(`${normalize(c)}__${uf.toLowerCase()}`, [lat, lng]);
}

export function lookupCoords(cidade: string, uf: string): [number, number] | null {
  const key = `${normalize(cidade)}__${uf.toLowerCase()}`;
  const hit = MAP.get(key);
  if (hit) return hit;
  const centroid = UF_CENTROIDS[uf.toUpperCase()];
  if (centroid) return centroid;
  return null;
}

export function hasExactCoords(cidade: string, uf: string): boolean {
  return MAP.has(`${normalize(cidade)}__${uf.toLowerCase()}`);
}
