import { describe, it, expect } from "vitest";
import {
  assocsInCity,
  assocsWithinRadius,
  citiesWithinRadius,
  computeDrawerSummary,
  regraDaCidade,
} from "../map-drawer";
import type { Associado, RegraRisco } from "../types";

function mk(o: Partial<Associado>): Associado {
  return {
    associado: "Assoc", placa: "AAA1234", numeroRastreador: "12345",
    consultor: "", cidade: "Recife", estado: "PE", plano: "",
    situacao: "ativo", situacaoOriginal: "Ativo", valorFipe: 10000,
    categoria: "", categoriaOriginal: "",
    tipo: "carro", temRastreador: true, operacional: true, ...o,
  };
}
const RECIFE_ALTO: RegraRisco = {
  id: "r1", nome: "Recife 50km", uf: "PE", cidade: "Recife",
  latCentral: -8.0476, lngCentral: -34.877, raioKm: 50,
  tipoVeiculo: "todos", nivelRisco: "alto", politica: "aceita_normalmente",
  motivo: "", fonte: "", atualizadoEm: "2025-01-01", status: "ativa",
};

describe("assocsInCity", () => {
  it("filtra por cidade+uf sem alterar o array original", () => {
    const base = [mk({ cidade: "Recife", estado: "PE" }), mk({ cidade: "Olinda", estado: "PE" })];
    const out = assocsInCity(base, "Recife", "PE");
    expect(out).toHaveLength(1);
    expect(base).toHaveLength(2); // não muta
  });
});

describe("assocsWithinRadius", () => {
  it("inclui somente cidades dentro do raio (Haversine)", () => {
    const base = [
      mk({ cidade: "Recife", estado: "PE" }),
      mk({ cidade: "Petrolina", estado: "PE" }),
    ];
    const out = assocsWithinRadius(base, -8.0476, -34.877, 100);
    expect(out.map((a) => a.cidade)).toEqual(["Recife"]);
  });
  it("aplica restrição de tipo quando informada", () => {
    const base = [
      mk({ cidade: "Recife", tipo: "moto" }),
      mk({ cidade: "Recife", tipo: "carro" }),
    ];
    const out = assocsWithinRadius(base, -8.0476, -34.877, 100, "moto");
    expect(out).toHaveLength(1);
    expect(out[0]?.tipo).toBe("moto");
  });
});

describe("citiesWithinRadius", () => {
  it("retorna cidades distintas dentro do raio", () => {
    const base = [
      mk({ cidade: "Recife", estado: "PE" }),
      mk({ cidade: "Recife", estado: "PE" }),
      mk({ cidade: "Olinda", estado: "PE" }),
    ];
    const out = citiesWithinRadius(base, -8.0476, -34.877, 30);
    expect(out.map((c) => c.cidade).sort()).toEqual(["Olinda", "Recife"]);
  });
});

describe("computeDrawerSummary", () => {
  const base = [
    mk({ tipo: "moto", situacao: "ativo", temRastreador: false, numeroRastreador: "" }),
    mk({ tipo: "moto", situacao: "ativo", temRastreador: true, numeroRastreador: "111" }),
    mk({ tipo: "carro", situacao: "suspenso", temRastreador: true, numeroRastreador: "222", operacional: true }),
    mk({ tipo: "caminhao", situacao: "cancelado", temRastreador: true, numeroRastreador: "333", operacional: false }),
  ];
  it("computa totais consistentes", () => {
    const s = computeDrawerSummary(base);
    expect(s.total).toBe(4);
    expect(s.motos).toBe(2);
    expect(s.carros).toBe(1);
    expect(s.caminhoes).toBe(1);
    expect(s.comRastreador).toBe(3);
    expect(s.semRastreador).toBe(1);
    expect(s.canceladosComRastreador).toBe(1);
    expect(s.coberturaPct).toBeCloseTo(75, 0);
  });
  it("recorte diferente do total geral produz números diferentes", () => {
    const recorte = base.filter((a) => a.tipo === "moto");
    const geral = computeDrawerSummary(base);
    const filtrado = computeDrawerSummary(recorte);
    expect(filtrado.total).toBe(2);
    expect(geral.total).toBe(4);
    expect(filtrado.total).not.toBe(geral.total);
  });
});

describe("regraDaCidade", () => {
  it("aplica regra manual dentro do raio", () => {
    expect(regraDaCidade(-8.0476, -34.877, [RECIFE_ALTO])?.id).toBe("r1");
  });
  it("retorna null fora do raio", () => {
    expect(regraDaCidade(-23.55, -46.63, [RECIFE_ALTO])).toBeNull();
  });
  it("null sem coordenadas", () => {
    expect(regraDaCidade(null, null, [RECIFE_ALTO])).toBeNull();
  });
});
