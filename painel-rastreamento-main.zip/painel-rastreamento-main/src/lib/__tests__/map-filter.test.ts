import { describe, it, expect } from "vitest";
import {
  applyAdvancedFilter,
  auditCity,
  computeDuplicateTrackers,
  DEFAULT_MAP_FILTER,
  filterPrestadores,
  providersServingCity,
  nivelRiscoManual,
  chipsFrom,
  removeChip,
} from "../map-filter";
import type { Associado, Prestador, RegraRisco } from "../types";

function mk(o: Partial<Associado>): Associado {
  return {
    associado: "X", placa: "AAA1234", numeroRastreador: "12345",
    consultor: "", cidade: "Recife", estado: "PE", plano: "",
    situacao: "ativo", situacaoOriginal: "Ativo", valorFipe: 10000,
    categoria: "", categoriaOriginal: "",
    tipo: "carro", temRastreador: true, operacional: true, ...o,
  };
}
function pr(o: Partial<Prestador>): Prestador {
  return {
    id: "p" + Math.random(), nome: "P", cidade: "Recife", uf: "PE",
    latitude: -8.0476, longitude: -34.877,
    tiposAtendidos: [], capacidadeMensal: null, raioKm: 30, status: "ativo",
    ...o,
  };
}
const RECIFE_RULE_ALTO: RegraRisco = {
  id: "r1", nome: "Recife 50km", uf: "PE", cidade: "Recife",
  latCentral: -8.0476, lngCentral: -34.877, raioKm: 50,
  tipoVeiculo: "todos", nivelRisco: "alto", politica: "aceita_normalmente",
  motivo: "", fonte: "", atualizadoEm: "2025-01-01", status: "ativa",
};

describe("applyAdvancedFilter — tipos", () => {
  const base = [mk({ tipo: "carro" }), mk({ tipo: "moto" }), mk({ tipo: "caminhao" })];
  const ctx = { regras: [], prestadores: [], duplicateTrackers: new Set<string>() };

  it("Moto exclui Carro e Caminhão", () => {
    const out = applyAdvancedFilter(base, { ...DEFAULT_MAP_FILTER, tipos: ["moto"], situacoes: [] }, ctx);
    expect(out).toHaveLength(1);
    expect(out[0]?.tipo).toBe("moto");
  });
  it("Carro + Moto inclui apenas os dois", () => {
    const out = applyAdvancedFilter(base, { ...DEFAULT_MAP_FILTER, tipos: ["carro", "moto"], situacoes: [] }, ctx);
    expect(out.map((a) => a.tipo).sort()).toEqual(["carro", "moto"]);
  });
});

describe("applyAdvancedFilter — situacao", () => {
  const base = [mk({ situacao: "ativo" }), mk({ situacao: "suspenso" }), mk({ situacao: "cancelado", operacional: false })];
  const ctx = { regras: [], prestadores: [], duplicateTrackers: new Set<string>() };
  it("Ativo + Suspenso exclui Cancelado", () => {
    const out = applyAdvancedFilter(base, { ...DEFAULT_MAP_FILTER, situacoes: ["ativo", "suspenso"] }, ctx);
    expect(out).toHaveLength(2);
    expect(out.every((a) => a.situacao !== "cancelado")).toBe(true);
  });
});

describe("applyAdvancedFilter — rastreamento", () => {
  const base = [
    mk({ temRastreador: true, numeroRastreador: "111" }),
    mk({ temRastreador: false, numeroRastreador: "" }),
    mk({ temRastreador: false, numeroRastreador: "0" }), // inválido
  ];
  const ctx = { regras: [], prestadores: [], duplicateTrackers: new Set<string>() };
  it("Sem rastreador retorna somente registros sem rastreador válido", () => {
    const out = applyAdvancedFilter(base, { ...DEFAULT_MAP_FILTER, situacoes: [], rastreamento: ["sem_valido"] }, ctx);
    expect(out).toHaveLength(2);
    expect(out.every((a) => !a.temRastreador)).toBe(true);
  });
});

describe("interseção Moto + Sem rastreador", () => {
  const base = [
    mk({ tipo: "moto", temRastreador: false, numeroRastreador: "" }),
    mk({ tipo: "moto", temRastreador: true }),
    mk({ tipo: "carro", temRastreador: false, numeroRastreador: "" }),
  ];
  const ctx = { regras: [], prestadores: [], duplicateTrackers: new Set<string>() };
  it("aplica AND entre grupos", () => {
    const out = applyAdvancedFilter(base, {
      ...DEFAULT_MAP_FILTER, situacoes: [], tipos: ["moto"], rastreamento: ["sem_valido"],
    }, ctx);
    expect(out).toHaveLength(1);
    expect(out[0]?.tipo).toBe("moto");
    expect(out[0]?.temRastreador).toBe(false);
  });
});

describe("risco manual", () => {
  const dentro = mk({ cidade: "Recife", estado: "PE" });
  const fora = mk({ cidade: "Petrolina", estado: "PE" });
  const ctx = { regras: [RECIFE_RULE_ALTO], prestadores: [], duplicateTrackers: new Set<string>() };
  it("Alto considera apenas cidades dentro de regras manuais", () => {
    const out = applyAdvancedFilter([dentro, fora], { ...DEFAULT_MAP_FILTER, situacoes: [], riscos: ["alto"] }, ctx);
    expect(out).toHaveLength(1);
    expect(out[0]?.cidade).toBe("Recife");
  });
  it("Cidade sem regra fica sem_classificacao", () => {
    expect(nivelRiscoManual(fora, [RECIFE_RULE_ALTO])).toBe("sem_classificacao");
    expect(nivelRiscoManual(dentro, [RECIFE_RULE_ALTO])).toBe("alto");
  });
});

describe("providersServingCity — outra cidade dentro do raio", () => {
  const petro: Prestador = pr({ id: "petro", nome: "IBS", cidade: "Petrolina", uf: "PE", latitude: -9.3891, longitude: -40.5027, raioKm: 100 });
  const salvador: Prestador = pr({ id: "sal", nome: "Jean", cidade: "Salvador", uf: "BA", latitude: -12.9714, longitude: -38.5014, raioKm: 30 });
  it("prestador de outra cidade entra se estiver no raio", () => {
    const juaz = { lat: -9.4111, lng: -40.4986 }; // Juazeiro/BA — próximo de Petrolina
    const out = providersServingCity(juaz.lat, juaz.lng, [petro, salvador], DEFAULT_MAP_FILTER);
    expect(out.map((p) => p.prestador.id)).toContain("petro");
    expect(out.map((p) => p.prestador.id)).not.toContain("sal");
  });
});

describe("filterPrestadores — tipos declarados", () => {
  const semTipos = pr({ id: "a", nome: "A", tiposAtendidos: [] });
  const comMoto = pr({ id: "b", nome: "B", tiposAtendidos: ["moto"] });
  it("tipoAtendido vazio não significa atende todos", () => {
    const out = filterPrestadores([semTipos, comMoto], { ...DEFAULT_MAP_FILTER, prestadorStatus: [], prestadorAtende: ["moto"] });
    expect(out.map((p) => p.id)).toEqual(["b"]);
  });
});

describe("duplicados / notação científica / numérico", () => {
  const base = [
    mk({ temRastreador: true, numeroRastreador: "123" }),
    mk({ temRastreador: true, numeroRastreador: "123" }),
    mk({ temRastreador: true, numeroRastreador: "1.23E+10" }),
    mk({ temRastreador: true, numeroRastreador: "999999" }),
  ];
  it("numérico continua válido", () => {
    expect(base[3]!.temRastreador).toBe(true);
  });
  it("duplicados detectados", () => {
    const dup = computeDuplicateTrackers(base);
    expect(dup.has("123")).toBe(true);
    expect(dup.has("999999")).toBe(false);
  });
  it("auditoria mascara valores e conta notação científica", () => {
    const rep = auditCity(base, "Recife", "PE");
    expect(rep.notacaoCientifica).toBe(1);
    expect(rep.numericos).toBe(3);
    expect(rep.examples.every((e) => e.placaMask.includes("*") || e.placaMask.length <= 2)).toBe(true);
    expect(rep.examples.every((e) => !e.placaMask.match(/^[A-Z]{3}\d{4}$/))).toBe(true);
  });
});

describe("chips", () => {
  it("gera chips e remove corretamente", () => {
    const f = { ...DEFAULT_MAP_FILTER, tipos: ["moto" as const], situacoes: ["ativo" as const] };
    const chips = chipsFrom(f);
    expect(chips.some((c) => c.label === "moto")).toBe(true);
    const next = removeChip(f, "tipo:moto");
    expect(next.tipos).toEqual([]);
    expect(next.situacoes).toEqual(["ativo"]);
  });
});
