import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock supabase client BEFORE importing the module under test
const mockFrom = vi.fn();
const mockInvoke = vi.fn();
const mockChannel = vi.fn();
const mockRemoveChannel = vi.fn();

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: any[]) => mockFrom(...args),
    functions: { invoke: (...args: any[]) => mockInvoke(...args) },
    channel: (...args: any[]) => mockChannel(...args),
    removeChannel: (...args: any[]) => mockRemoveChannel(...args),
  },
}));

import {
  rowToPrestador,
  prestadorToRemoteInput,
  fetchPrestadoresFromSupabase,
  createPrestadorRemote,
  updatePrestadorRemote,
  activatePrestadorRemote,
  deactivatePrestadorRemote,
  deletePrestadorRemote,
  migrateLocalPrestadores,
  subscribePrestadoresRealtime,
  PrestadoresApiError,
} from "../prestadores-api";
import type { Prestador } from "../types";

beforeEach(() => {
  vi.clearAllMocks();
});

function providerFixture(overrides: Partial<Prestador> = {}): Prestador {
  return {
    id: "",
    nome: "IBS",
    cidade: "Petrolina",
    uf: "PE",
    latitude: -9.3891,
    longitude: -40.5027,
    tiposAtendidos: [],
    capacidadeMensal: null,
    raioKm: 30,
    status: "ativo",
    fonte: "mapa_anterior_avp",
    sourceKey: "ibs__petrolina__pe",
    localizacaoAproximada: true,
    ...overrides,
  };
}

describe("rowToPrestador", () => {
  it("mapeia colunas da view para o tipo do domínio", () => {
    const p = rowToPrestador({
      id: "u1",
      nome: "IBS",
      cidade: "Petrolina",
      uf: "pe",
      latitude: "-9.39",
      longitude: "-40.50",
      raio_atendimento_km: "30",
      status: "ativo",
      capacidade_mensal: null,
      tipos_atendidos: ["carro", "moto"],
      fonte: "mapa_anterior_avp",
      localizacao_aproximada: true,
    });
    expect(p.id).toBe("u1");
    expect(p.uf).toBe("PE");
    expect(p.latitude).toBeCloseTo(-9.39);
    expect(p.raioKm).toBe(30);
    expect(p.tiposAtendidos).toEqual(["carro", "moto"]);
    expect(p.capacidadeMensal).toBeNull();
  });

  it("descarta tipos inválidos e normaliza tipos ausentes para array vazio", () => {
    const p = rowToPrestador({ id: "x", nome: "X", cidade: "Y", uf: "PE", tipos_atendidos: ["carro", "aviao"] });
    expect(p.tiposAtendidos).toEqual(["carro"]);
    const p2 = rowToPrestador({ id: "x", nome: "X", cidade: "Y", uf: "PE", tipos_atendidos: null });
    expect(p2.tiposAtendidos).toEqual([]);
  });
});

describe("prestadorToRemoteInput", () => {
  it("mapeia camelCase → snake_case e converte tipos vazios para null", () => {
    const remote = prestadorToRemoteInput(providerFixture());
    expect(remote.source_key).toBe("ibs__petrolina__pe");
    expect(remote.raio_atendimento_km).toBe(30);
    expect(remote.tipos_atendidos).toBeNull();
    expect(remote.localizacao_aproximada).toBe(true);
  });

  it("gera source_key quando ausente", () => {
    const remote = prestadorToRemoteInput(providerFixture({ sourceKey: undefined }));
    expect(remote.source_key).toBe("ibs__petrolina__pe");
  });
});

describe("fetchPrestadoresFromSupabase", () => {
  it("lê da view pública e mapeia rows", async () => {
    const order = vi.fn().mockResolvedValue({
      data: [{ id: "1", nome: "IBS", cidade: "Petrolina", uf: "PE", raio_atendimento_km: 30, status: "ativo" }],
      error: null,
    });
    const select = vi.fn().mockReturnValue({ order });
    mockFrom.mockReturnValue({ select });
    const list = await fetchPrestadoresFromSupabase();
    expect(mockFrom).toHaveBeenCalledWith("public_tracking_service_providers");
    expect(list).toHaveLength(1);
    expect(list[0]!.nome).toBe("IBS");
  });

  it("lança PrestadoresApiError em falha de leitura", async () => {
    const order = vi.fn().mockResolvedValue({ data: null, error: { message: "conn refused" } });
    mockFrom.mockReturnValue({ select: () => ({ order }) });
    await expect(fetchPrestadoresFromSupabase()).rejects.toBeInstanceOf(PrestadoresApiError);
  });
});

describe("edge function actions", () => {
  it("createPrestadorRemote envia action=create e admin_code", async () => {
    mockInvoke.mockResolvedValue({
      data: { ok: true, provider: { id: "u1", nome: "IBS", cidade: "Petrolina", uf: "PE" } },
      error: null,
    });
    const created = await createPrestadorRemote({ adminCode: "SEGREDO", provider: providerFixture() });
    expect(mockInvoke).toHaveBeenCalledWith("manage-tracking-provider", expect.objectContaining({
      body: expect.objectContaining({ action: "create", admin_code: "SEGREDO" }),
    }));
    expect(created.id).toBe("u1");
  });

  it("propaga code do erro remoto (admin_code_invalid)", async () => {
    mockInvoke.mockResolvedValue({
      data: { ok: false, error: { code: "admin_code_invalid", message: "Código administrativo inválido" } },
      error: null,
    });
    await expect(
      createPrestadorRemote({ adminCode: "errado", provider: providerFixture() }),
    ).rejects.toMatchObject({ code: "admin_code_invalid" });
  });

  it("propaga rate limit (429) com retry_after_ms", async () => {
    mockInvoke.mockResolvedValue({
      data: { ok: false, error: { code: "rate_limited", message: "Muitas tentativas", retry_after_ms: 60000 } },
      error: null,
    });
    try {
      await createPrestadorRemote({ adminCode: "x", provider: providerFixture() });
      expect.fail("deveria ter lançado");
    } catch (e) {
      expect(e).toBeInstanceOf(PrestadoresApiError);
      expect((e as PrestadoresApiError).code).toBe("rate_limited");
      expect((e as PrestadoresApiError).retryAfterMs).toBe(60000);
    }
  });

  it("updatePrestadorRemote monta patch snake_case somente com campos definidos", async () => {
    mockInvoke.mockResolvedValue({
      data: { ok: true, provider: { id: "u1", nome: "IBS2", cidade: "Petrolina", uf: "PE" } },
      error: null,
    });
    await updatePrestadorRemote({
      adminCode: "SEGREDO",
      id: "u1",
      patch: { nome: "IBS2", capacidadeMensal: 120 },
    });
    const call = mockInvoke.mock.calls[0]![1] as any;
    expect(call.body.action).toBe("update");
    expect(call.body.patch).toEqual({ nome: "IBS2", capacidade_mensal: 120 });
  });

  it("activate/deactivate enviam ação correta", async () => {
    mockInvoke.mockResolvedValue({ data: { ok: true, provider: { id: "u1", nome: "X", cidade: "Y", uf: "PE", status: "ativo" } }, error: null });
    await activatePrestadorRemote("k", "u1");
    expect(mockInvoke.mock.calls[0]![1]!.body.action).toBe("activate");
    mockInvoke.mockResolvedValue({ data: { ok: true, provider: { id: "u1", nome: "X", cidade: "Y", uf: "PE", status: "inativo" } }, error: null });
    await deactivatePrestadorRemote("k", "u1");
    expect(mockInvoke.mock.calls[1]![1]!.body.action).toBe("deactivate");
  });

  it("delete envia action=delete", async () => {
    mockInvoke.mockResolvedValue({ data: { ok: true }, error: null });
    await deletePrestadorRemote("k", "u1");
    expect(mockInvoke.mock.calls[0]![1]!.body.action).toBe("delete");
  });

  it("migrateLocalPrestadores retorna inserted/skipped", async () => {
    mockInvoke.mockResolvedValue({ data: { ok: true, inserted: 2, skipped: 3 }, error: null });
    const res = await migrateLocalPrestadores("k", [providerFixture(), providerFixture({ nome: "Outro", sourceKey: "outro__petrolina__pe" })]);
    expect(res).toEqual({ inserted: 2, skipped: 3 });
    expect(mockInvoke.mock.calls[0]![1]!.body.action).toBe("migrate_missing");
  });

  it("migrateLocalPrestadores retorna 0/0 quando lista vazia (sem chamada de rede)", async () => {
    const res = await migrateLocalPrestadores("k", []);
    expect(res).toEqual({ inserted: 0, skipped: 0 });
    expect(mockInvoke).not.toHaveBeenCalled();
  });
});

describe("realtime subscription", () => {
  it("subscribePrestadoresRealtime registra canal e retorna unsubscribe", () => {
    const subscribeFn = vi.fn().mockReturnValue({ id: "channel" });
    const on = vi.fn().mockReturnValue({ subscribe: subscribeFn });
    mockChannel.mockReturnValue({ on });
    const onChange = vi.fn();
    const unsubscribe = subscribePrestadoresRealtime(onChange);
    expect(mockChannel).toHaveBeenCalledWith("tracking_service_providers_changes");
    expect(on).toHaveBeenCalled();
    unsubscribe();
    expect(mockRemoveChannel).toHaveBeenCalled();
  });
});
