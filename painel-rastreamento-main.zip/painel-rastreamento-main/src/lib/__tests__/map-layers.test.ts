import { describe, it, expect } from "vitest";
import {
  NON_INTERACTIVE_CIRCLE,
  PANE_CONFIG,
  PROVIDER_RADIUS_STYLE,
  RISK_CIRCLE_STYLE,
} from "../map-layers";

describe("PANE_CONFIG", () => {
  it("empilha panes de baixo para cima: risco < raios < cidades < prestadores < riscoMarkers < selecionado", () => {
    const zs = [
      PANE_CONFIG.risco.z,
      PANE_CONFIG.raios.z,
      PANE_CONFIG.cidades.z,
      PANE_CONFIG.prestadores.z,
      PANE_CONFIG.riscoMarkers.z,
      PANE_CONFIG.selecionado.z,
    ];
    expect(zs).toEqual([320, 330, 450, 500, 510, 620]);
    for (let i = 1; i < zs.length; i++) expect(zs[i]).toBeGreaterThan(zs[i - 1]!);
  });
  it("marca panes de círculos como não-interativos (pointerEvents:none)", () => {
    expect(PANE_CONFIG.risco.interactive).toBe(false);
    expect(PANE_CONFIG.raios.interactive).toBe(false);
  });
  it("mantém bolhas e marcadores interativos e acima dos círculos", () => {
    expect(PANE_CONFIG.cidades.interactive).toBe(true);
    expect(PANE_CONFIG.prestadores.interactive).toBe(true);
    expect(PANE_CONFIG.riscoMarkers.interactive).toBe(true);
    expect(PANE_CONFIG.cidades.z).toBeGreaterThan(PANE_CONFIG.risco.z);
    expect(PANE_CONFIG.cidades.z).toBeGreaterThan(PANE_CONFIG.raios.z);
    expect(PANE_CONFIG.prestadores.z).toBeGreaterThan(PANE_CONFIG.cidades.z);
    expect(PANE_CONFIG.riscoMarkers.z).toBeGreaterThan(PANE_CONFIG.prestadores.z);
  });
});

describe("Estilo dos círculos", () => {
  it("círculos não interceptam cliques", () => {
    expect(NON_INTERACTIVE_CIRCLE.interactive).toBe(false);
    expect(NON_INTERACTIVE_CIRCLE.bubblingMouseEvents).toBe(false);
  });
  it("área de risco discreta", () => {
    expect(RISK_CIRCLE_STYLE.fillOpacity).toBeLessThanOrEqual(0.1);
    expect(RISK_CIRCLE_STYLE.weight).toBeLessThanOrEqual(2);
  });
  it("raio de prestador sem preenchimento e tracejado", () => {
    expect(PROVIDER_RADIUS_STYLE.fillOpacity).toBe(0);
    expect(PROVIDER_RADIUS_STYLE.dashArray).toBeDefined();
  });
});
