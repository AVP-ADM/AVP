import { describe, it, expect } from "vitest";
import {
  classifySituacao,
  classifyTipoVeiculo,
  categoriasDoTipo,
  hasValidTracker,
  normalizeUF,
  normalizeCidade,
  parseFipe,
  cityKey,
} from "../classify";

describe("classifySituacao", () => {
  it("mapeia ativo/cancelado/suspenso", () => {
    expect(classifySituacao("Ativo")).toBe("ativo");
    expect(classifySituacao("ATIVO")).toBe("ativo");
    expect(classifySituacao("Cancelado")).toBe("cancelado");
    expect(classifySituacao("Suspenso")).toBe("suspenso");
    expect(classifySituacao("")).toBe("outro");
    expect(classifySituacao("qualquer coisa")).toBe("outro");
  });
});

describe("classifyTipoVeiculo — mapeamento oficial", () => {
  const carro = [
    "Atividade Remunerada (SUV | Caminhonete | Utilitário)",
    "Atividade Remunerada (veículo leve)",
    "Automóvel Premium",
    "Automóvel Start",
    "Categoria teste (não usar)",
    "Elétrico | Híbrido",
    "Passeio - Importado",
    "Passeio - Nacional",
    "SUV | Caminhonete | Utilitário",
    "SUV | Caminhonete | Utilitário - Importado",
  ];
  const moto = [
    "Atividade Remunerada (motocicleta - Avelloz | Shineray | Bajaj)",
    "Atividade Remunerada (motocicleta - Honda)",
    "Atividade Remunerada (motocicleta - Yamaha)",
    "ELITE 125 | FLUO 125 | NEO",
    "Motocicletas - Avelloz | Shineray | Bajaj",
    "Motocicletas - Honda",
    "Motocicletas - Yamaha",
    "Motocicletas Especiais",
    "PCX 150 | NMAX 160 | ADV 150",
    "PCX 160 | XMAX 250 | ADV 160",
  ];
  const caminhao = [
    "Truck Leve (até 14t)",
    "Truck Pesado (a partir de 14t)",
    "Agregado Carreta",
  ];

  it.each(carro)("classifica como carro: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("carro"));
  it.each(moto)("classifica como moto: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("moto"));
  it.each(caminhao)("classifica como caminhao: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("caminhao"));

  it("classifica valores fora do mapa como nao_classificado", () => {
    expect(classifyTipoVeiculo("")).toBe("nao_classificado");
    expect(classifyTipoVeiculo("SUV")).toBe("nao_classificado");
    expect(classifyTipoVeiculo("Reboque")).toBe("nao_classificado");
    expect(classifyTipoVeiculo("leve")).toBe("nao_classificado");
    expect(classifyTipoVeiculo("Passeio")).toBe("nao_classificado");
    // Palavras isoladas como "truck", "auto" não devem classificar automaticamente
    expect(classifyTipoVeiculo("truck")).toBe("nao_classificado");
    expect(classifyTipoVeiculo("auto")).toBe("nao_classificado");
  });

  describe("aliases aprovados", () => {
    const motoAliases = [
      "Motocicleta",
      "Atividade Remunerada (motocicleta)",
      "SHINERAY | AVELLOZ",
      "shineray | avelloz",
      "  motocicleta  ",
      "motocícleta",
    ];
    const carroAliases = [
      "Automóvel Elétrico",
      "Automóvel Híbrido",
      "automovel eletrico",
      "AUTOMÓVEL HÍBRIDO",
    ];
    const caminhaoAliases = [
      "Frota Publica (Leve até 14t)",
      "Frota Publica (Pesado a partir de 14t)",
      "Rastreamento | Monitoramento - Comodato (Truck)",
      "  frota publica (leve ate 14t)  ",
    ];
    it.each(motoAliases)("alias moto: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("moto"));
    it.each(carroAliases)("alias carro: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("carro"));
    it.each(caminhaoAliases)("alias caminhao: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("caminhao"));
  });

  describe("categorias administrativas permanecem nao_classificado", () => {
    const admin = [
      "Rastreamento | Monitoramento - Comodato",
      "Inativado",
      "Teste",
      "  inativado  ",
      "RASTREAMENTO | MONITORAMENTO - COMODATO",
    ];
    it.each(admin)("admin: %s", (c) => expect(classifyTipoVeiculo(c)).toBe("nao_classificado"));
  });


  it("categoriasDoTipo retorna a lista oficial", () => {
    expect(categoriasDoTipo("carro")).toEqual(carro);
    expect(categoriasDoTipo("moto")).toEqual(moto);
    expect(categoriasDoTipo("caminhao")).toEqual(caminhao);
    expect(categoriasDoTipo("todos").length).toBe(carro.length + moto.length + caminhao.length);
  });
});

describe("hasValidTracker", () => {
  it("aceita imei/id validos", () => {
    expect(hasValidTracker("865080043871157")).toBe(true);
    expect(hasValidTracker("Terceirizado")).toBe(true);
  });
  it("rejeita vazios/zeros/placeholders", () => {
    expect(hasValidTracker("")).toBe(false);
    expect(hasValidTracker("000000000000000")).toBe(false);
    expect(hasValidTracker("0")).toBe(false);
    expect(hasValidTracker("N/A")).toBe(false);
    expect(hasValidTracker("-")).toBe(false);
    expect(hasValidTracker("nao possui")).toBe(false);
  });
});

describe("normalizeUF", () => {
  it("converte nomes por extenso em siglas", () => {
    expect(normalizeUF("Pernambuco")).toBe("PE");
    expect(normalizeUF("Bahia")).toBe("BA");
    expect(normalizeUF("Rio Grande do Norte")).toBe("RN");
    expect(normalizeUF("Rio Grande do Sul")).toBe("RS");
    expect(normalizeUF("Minas Gerais")).toBe("MG");
    expect(normalizeUF("São Paulo")).toBe("SP");
    expect(normalizeUF("Rio de Janeiro")).toBe("RJ");
    expect(normalizeUF("Paraíba")).toBe("PB");
    expect(normalizeUF("Espírito Santo")).toBe("ES");
  });
  it("mantem siglas ja em uso", () => {
    expect(normalizeUF("PE")).toBe("PE");
    expect(normalizeUF(" ba ")).toBe("BA");
  });
});

describe("normalizeCidade / cityKey", () => {
  it("titlecase e chave estavel", () => {
    expect(normalizeCidade("PETROLINA")).toBe("Petrolina");
    expect(normalizeCidade(" juazeiro ")).toBe("Juazeiro");
    expect(cityKey("Petrolina", "Pernambuco")).toBe(cityKey("PETROLINA", "PE"));
  });
});

describe("parseFipe", () => {
  it("aceita numero e string BR", () => {
    expect(parseFipe(83366)).toBe(83366);
    expect(parseFipe("R$ 246.715,00")).toBe(246715);
    expect(parseFipe("")).toBeNull();
    expect(parseFipe(null)).toBeNull();
  });
});
