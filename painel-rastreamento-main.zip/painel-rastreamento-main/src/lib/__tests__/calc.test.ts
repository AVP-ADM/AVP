import { describe, it, expect } from "vitest";
import { computeGlobal, computeCities } from "../calc";
import type { Associado, AppSettings } from "../types";

const S: AppSettings = {
  ratioNormal: 500,
  ratioAlta: 300,
  motoBoost: 1.3,
};

function a(o: Partial<Associado>): Associado {
  return {
    associado: "X",
    placa: "AAA1234",
    numeroRastreador: "",
    consultor: "",
    cidade: "Petrolina",
    estado: "PE",
    plano: "",
    situacao: "ativo",
    situacaoOriginal: "Ativo",
    valorFipe: null,
    categoria: "Passeio - Nacional",
    categoriaOriginal: "Passeio - Nacional",
    tipo: "carro",
    temRastreador: false,
    operacional: true,
    ...o,
  };
}

describe("computeGlobal", () => {
  it("conta operacionais/rastreador/cancelados com rastreador", () => {
    const data: Associado[] = [
      a({ situacao: "ativo", operacional: true, temRastreador: true }),
      a({ situacao: "ativo", operacional: true, temRastreador: false }),
      a({ situacao: "suspenso", operacional: true, temRastreador: false }),
      a({ situacao: "cancelado", operacional: false, temRastreador: true }),
      a({ situacao: "cancelado", operacional: false, temRastreador: false }),
    ];
    const m = computeGlobal(data);
    expect(m.total).toBe(5);
    expect(m.operacionais).toBe(3);
    expect(m.comRastreador).toBe(1);
    expect(m.semRastreador).toBe(2);
    expect(m.canceladosComRastreador).toBe(1);
    expect(m.cobertura).toBeCloseTo(1 / 3, 3);
  });
});

describe("computeCities score/prioridade", () => {
  it("gera score maior para cidade com muitos sem rastreador", () => {
    const many: Associado[] = Array.from({ length: 100 }, () =>
      a({ cidade: "Petrolina", estado: "PE", temRastreador: false })
    );
    const few: Associado[] = Array.from({ length: 5 }, () =>
      a({ cidade: "Recife", estado: "PE", temRastreador: false })
    );
    const list = computeCities([...many, ...few], [], [], S);
    const petro = list.find((c) => c.cidade === "Petrolina")!;
    const recife = list.find((c) => c.cidade === "Recife")!;
    expect(petro.score).toBeGreaterThan(recife.score);
    expect(petro.semRastreador).toBe(100);
  });
});
