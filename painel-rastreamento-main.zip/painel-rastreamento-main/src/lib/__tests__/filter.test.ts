import { describe, it, expect } from "vitest";
import { applyFilter, computeCities } from "../calc";
import type { Associado } from "../types";

function mk(overrides: Partial<Associado>): Associado {
  return {
    associado: "x", placa: "AAA0000", numeroRastreador: "12345",
    consultor: "", cidade: "Recife", estado: "PE", plano: "",
    situacao: "ativo", situacaoOriginal: "Ativo", valorFipe: 10000,
    categoria: "", categoriaOriginal: "",
    tipo: "carro", temRastreador: true, operacional: true,
    ...overrides,
  };
}

describe("applyFilter (multi-tipo)", () => {
  const base: Associado[] = [
    mk({ tipo: "carro" }),
    mk({ tipo: "moto" }),
    mk({ tipo: "moto", temRastreador: false }),
    mk({ tipo: "caminhao" }),
  ];

  it("Moto não soma carros nem caminhões", () => {
    const out = applyFilter(base, { tipoVeiculo: "moto", categoria: "" });
    expect(out).toHaveLength(2);
    expect(out.every((a) => a.tipo === "moto")).toBe(true);
  });

  it("Sem filtro devolve tudo", () => {
    const out = applyFilter(base, { tipoVeiculo: "todos", categoria: "" });
    expect(out).toHaveLength(4);
  });

  it("computeCities sobre base filtrada zera outros tipos no popup-source", () => {
    const filtered = applyFilter(base, { tipoVeiculo: "moto", categoria: "" });
    const cities = computeCities(filtered, [], [], { ratioAlta: 150, ratioNormal: 250, motoBoost: 1.2 }, "moto");
    const recife = cities.find((c) => c.cidade === "Recife");
    expect(recife?.motos).toBe(2);
    expect(recife?.carros).toBe(0);
    expect(recife?.caminhoes).toBe(0);
    expect(recife?.comRastreador).toBe(1);
    expect(recife?.semRastreador).toBe(1);
  });
});
