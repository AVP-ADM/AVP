import { describe, it, expect } from "vitest";
import {
  PRESTADORES_MAPA_ANTERIOR,
  makeSourceKey,
  seedPrestadoresMapaAnterior,
} from "../prestadores-seed";
import type { Prestador } from "../types";

describe("seedPrestadoresMapaAnterior", () => {
  it("insere os 20 prestadores em base vazia", () => {
    const { next, report } = seedPrestadoresMapaAnterior([]);
    expect(PRESTADORES_MAPA_ANTERIOR).toHaveLength(20);
    expect(report.inserted).toBe(20);
    expect(report.existed).toBe(0);
    expect(next).toHaveLength(20);
    // Fortaleza aparece duas vezes (Troia e FI'CAR) como prestadores distintos.
    const fortaleza = next.filter((p) => p.cidade === "Fortaleza" && p.uf === "CE");
    expect(fortaleza).toHaveLength(2);
    // Todos com raio 30 e status ativo.
    for (const p of next) {
      expect(p.raioKm).toBe(30);
      expect(p.status).toBe("ativo");
      expect(p.fonte).toBe("mapa_anterior_avp");
      expect(p.sourceKey).toBeTruthy();
      expect(p.capacidadeMensal).toBeNull();
      expect(p.tiposAtendidos).toEqual([]);
    }
  });

  it("é idempotente: nova execução não duplica", () => {
    const first = seedPrestadoresMapaAnterior([]).next;
    const { next, report } = seedPrestadoresMapaAnterior(first);
    expect(report.inserted).toBe(0);
    expect(report.existed).toBe(20);
    expect(next).toHaveLength(20);
  });

  it("preserva edições manuais e não sobrescreve por sourceKey", () => {
    const base = seedPrestadoresMapaAnterior([]).next;
    const troia = base.find((p) => p.nome === "Troia")!;
    // Simula edição manual: usuário alterou raio e capacidade.
    troia.raioKm = 55;
    troia.capacidadeMensal = 120;
    const { next, report } = seedPrestadoresMapaAnterior(base);
    expect(report.inserted).toBe(0);
    const troiaDepois = next.find((p) => p.nome === "Troia")!;
    expect(troiaDepois.raioKm).toBe(55);
    expect(troiaDepois.capacidadeMensal).toBe(120);
  });

  it("não recria prestador já cadastrado manualmente com mesmo nome/cidade/uf", () => {
    const manual: Prestador = {
      id: "manual-1",
      nome: "IBS",
      cidade: "Petrolina",
      uf: "PE",
      latitude: -9.3891,
      longitude: -40.5027,
      tiposAtendidos: ["carro", "moto"],
      capacidadeMensal: 80,
      raioKm: 40,
      status: "ativo",
      sourceKey: makeSourceKey("IBS", "Petrolina", "PE"),
    };
    const { next, report } = seedPrestadoresMapaAnterior([manual]);
    expect(report.existed).toBe(1);
    expect(report.inserted).toBe(19);
    // O manual continua com raio 40 (não foi sobrescrito para 30).
    const ibs = next.find((p) => p.id === "manual-1")!;
    expect(ibs.raioKm).toBe(40);
    expect(ibs.capacidadeMensal).toBe(80);
    // Não há um segundo IBS/Petrolina/PE inserido pelo seed.
    const ibsCount = next.filter(
      (p) => makeSourceKey(p.nome, p.cidade, p.uf) === makeSourceKey("IBS", "Petrolina", "PE")
    );
    expect(ibsCount).toHaveLength(1);
  });

  it("localiza coordenadas de todos os 20 prestadores", () => {
    const { next, report } = seedPrestadoresMapaAnterior([]);
    expect(report.withoutCoords).toEqual([]);
    for (const p of next) {
      expect(p.latitude).not.toBeNull();
      expect(p.longitude).not.toBeNull();
    }
  });
});
