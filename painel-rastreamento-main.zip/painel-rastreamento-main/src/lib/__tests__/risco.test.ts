import { describe, it, expect } from "vitest";
import { haversineKm, matchRegra, computeCities } from "../calc";
import type { Associado, AppSettings, RegraRisco } from "../types";

const S: AppSettings = { ratioAlta: 150, ratioNormal: 250, motoBoost: 1.2 };

const RECIFE: [number, number] = [-8.0476, -34.877];
const OLINDA: [number, number] = [-8.0089, -34.8553]; // ~5 km de Recife
const CARUARU: [number, number] = [-8.2836, -35.9761]; // ~110 km
const SP: [number, number] = [-23.5505, -46.6333];

function regra(o: Partial<RegraRisco> = {}): RegraRisco {
  return {
    id: o.id ?? Math.random().toString(36).slice(2),
    nome: o.nome ?? "Recife 50km",
    uf: o.uf ?? "PE",
    cidade: o.cidade ?? "Recife",
    latCentral: o.latCentral ?? RECIFE[0],
    lngCentral: o.lngCentral ?? RECIFE[1],
    raioKm: o.raioKm ?? 50,
    tipoVeiculo: o.tipoVeiculo ?? "todos",
    nivelRisco: o.nivelRisco ?? "alto",
    politica: o.politica ?? "aceita_somente_com_rastreador",
    motivo: o.motivo ?? "",
    fonte: o.fonte ?? "",
    atualizadoEm: o.atualizadoEm ?? new Date().toISOString(),
    status: o.status ?? "ativa",
  };
}

describe("haversineKm", () => {
  it("mede 0 km entre o mesmo ponto", () => {
    expect(haversineKm(RECIFE[0], RECIFE[1], RECIFE[0], RECIFE[1])).toBeCloseTo(0, 5);
  });
  it("mede Recife → Olinda em torno de 5 km", () => {
    const d = haversineKm(RECIFE[0], RECIFE[1], OLINDA[0], OLINDA[1]);
    expect(d).toBeGreaterThan(3);
    expect(d).toBeLessThan(8);
  });
  it("mede Recife → São Paulo > 2000 km", () => {
    const d = haversineKm(RECIFE[0], RECIFE[1], SP[0], SP[1]);
    expect(d).toBeGreaterThan(2000);
    expect(d).toBeLessThan(2400);
  });
});

describe("matchRegra — dentro/fora do raio", () => {
  const r = regra({ raioKm: 50 });
  it("Olinda (≈5 km) está DENTRO do raio de 50 km", () => {
    const m = matchRegra(OLINDA[0], OLINDA[1], "carro", [r]);
    expect(m).not.toBeNull();
    expect(m!.distanciaKm).toBeLessThan(50);
  });
  it("Caruaru (≈110 km) está FORA do raio de 50 km", () => {
    const m = matchRegra(CARUARU[0], CARUARU[1], "carro", [r]);
    expect(m).toBeNull();
  });
  it("São Paulo está FORA", () => {
    const m = matchRegra(SP[0], SP[1], "carro", [r]);
    expect(m).toBeNull();
  });
});

describe("matchRegra — status", () => {
  it("regra INATIVA não é aplicada", () => {
    const r = regra({ status: "inativa" });
    expect(matchRegra(RECIFE[0], RECIFE[1], "carro", [r])).toBeNull();
  });
});

describe("matchRegra — filtro por tipo de veículo", () => {
  const rMoto = regra({ id: "m", raioKm: 20, tipoVeiculo: "moto", nivelRisco: "critico" });
  it("aplica regra de moto apenas quando tipo=moto", () => {
    expect(matchRegra(RECIFE[0], RECIFE[1], "moto", [rMoto])).not.toBeNull();
    expect(matchRegra(RECIFE[0], RECIFE[1], "carro", [rMoto])).toBeNull();
  });
});

describe("matchRegra — precedência", () => {
  const geral = regra({ id: "g", raioKm: 50, tipoVeiculo: "todos", nivelRisco: "alto" });
  const moto = regra({ id: "m", raioKm: 20, tipoVeiculo: "moto", nivelRisco: "critico" });

  it("carro dentro dos dois raios: recebe a regra geral (Alto)", () => {
    const m = matchRegra(RECIFE[0], RECIFE[1], "carro", [geral, moto]);
    expect(m!.regra.id).toBe("g");
    expect(m!.regra.nivelRisco).toBe("alto");
  });

  it("moto dentro dos dois raios: recebe a regra específica (Crítico, menor raio)", () => {
    const m = matchRegra(RECIFE[0], RECIFE[1], "moto", [geral, moto]);
    expect(m!.regra.id).toBe("m");
    expect(m!.regra.nivelRisco).toBe("critico");
  });

  it("entre duas regras do mesmo tipo, menor raio vence", () => {
    const r1 = regra({ id: "r1", raioKm: 50, tipoVeiculo: "todos", nivelRisco: "medio" });
    const r2 = regra({ id: "r2", raioKm: 10, tipoVeiculo: "todos", nivelRisco: "baixo" });
    const m = matchRegra(RECIFE[0], RECIFE[1], "carro", [r1, r2]);
    expect(m!.regra.id).toBe("r2");
  });

  it("mesmo raio e tipo: maior nível de risco vence", () => {
    const r1 = regra({ id: "r1", raioKm: 30, tipoVeiculo: "todos", nivelRisco: "medio" });
    const r2 = regra({ id: "r2", raioKm: 30, tipoVeiculo: "todos", nivelRisco: "critico" });
    const m = matchRegra(RECIFE[0], RECIFE[1], "carro", [r1, r2]);
    expect(m!.regra.id).toBe("r2");
  });

  it("mesmo raio, tipo e nível: mais recente vence", () => {
    const r1 = regra({ id: "r1", raioKm: 30, tipoVeiculo: "todos", nivelRisco: "alto", atualizadoEm: "2024-01-01T00:00:00Z" });
    const r2 = regra({ id: "r2", raioKm: 30, tipoVeiculo: "todos", nivelRisco: "alto", atualizadoEm: "2026-06-01T00:00:00Z" });
    const m = matchRegra(RECIFE[0], RECIFE[1], "carro", [r1, r2]);
    expect(m!.regra.id).toBe("r2");
  });
});

describe("computeCities — risco não depende de operacionais", () => {
  function a(o: Partial<Associado>): Associado {
    return {
      associado: "X", placa: "AAA1234", numeroRastreador: "",
      consultor: "", cidade: "Recife", estado: "PE", plano: "",
      situacao: "ativo", situacaoOriginal: "Ativo",
      valorFipe: null, categoria: "Passeio - Nacional",
      categoriaOriginal: "Passeio - Nacional",
      tipo: "carro", temRastreador: false, operacional: true,
      ...o,
    };
  }

  it("cidade com 1 e cidade com 100 registros dentro da mesma área recebem o mesmo nível de risco", () => {
    const um = [a({ cidade: "Recife" })];
    const cem = Array.from({ length: 100 }, () => a({ cidade: "Recife" }));
    const r = [regra({ raioKm: 50, nivelRisco: "alto" })];
    const [c1] = computeCities(um, [], r, S);
    const [c2] = computeCities(cem, [], r, S);
    expect(c1!.nivelRisco).toBe("alto");
    expect(c2!.nivelRisco).toBe("alto");
    // Prioridade OPERACIONAL pode divergir (isso é outro indicador)
    // mas risco não muda com volume.
  });

  it("sem regras cadastradas, nivelRisco fica sem_classificacao independente da massa de dados", () => {
    const many = Array.from({ length: 500 }, () => a({ cidade: "Recife", temRastreador: false }));
    const [c] = computeCities(many, [], [], S);
    expect(c!.nivelRisco).toBe("sem_classificacao");
    expect(c!.regraAplicada).toBeNull();
  });
});

describe("persistência (localStorage) do módulo de risco", () => {
  it("regra salva pode ser lida de volta com o mesmo raio/nível", async () => {
    const mem = new Map<string, string>();
    (globalThis as any).localStorage = {
      getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null),
      setItem: (k: string, v: string) => { mem.set(k, v); },
      removeItem: (k: string) => { mem.delete(k); },
      clear: () => { mem.clear(); },
    };
    (globalThis as any).window = globalThis;
    const store = await import("../store");
    store.setRegras([]);
    const r = regra({ id: "persist-1", raioKm: 42, nivelRisco: "critico" });
    store.upsertRegra(r);
    const raw = mem.get("avp.regras");
    expect(raw).toBeTruthy();
    const parsed = JSON.parse(raw!);
    expect(parsed.some((x: any) => x.id === "persist-1" && x.raioKm === 42 && x.nivelRisco === "critico")).toBe(true);
    store.setRegras([]);
  });
});

describe("importação/exportação (round-trip lógico)", () => {
  it("preserva campos essenciais em um round-trip JSON (equivalente ao CSV)", () => {
    const r = regra({ id: "rt", raioKm: 25, tipoVeiculo: "moto", nivelRisco: "critico", politica: "nao_aceita_moto" });
    const round = JSON.parse(JSON.stringify([r]))[0];
    expect(round.raioKm).toBe(25);
    expect(round.tipoVeiculo).toBe("moto");
    expect(round.nivelRisco).toBe("critico");
    expect(round.politica).toBe("nao_aceita_moto");
    // matchRegra ainda funciona após serialização
    const m = matchRegra(RECIFE[0], RECIFE[1], "moto", [round]);
    expect(m).not.toBeNull();
  });
});
