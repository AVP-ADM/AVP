// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// Mock the supabase client BEFORE importing the module under test.
type InvokeCall = { body: any };
const invokeCalls: InvokeCall[] = [];
let mockImpl: (body: any) => Promise<{ data: any; error: any }> = async () => ({ data: null, error: null });

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    functions: {
      invoke: (_name: string, opts: { body: any }) => {
        invokeCalls.push({ body: opts.body });
        return mockImpl(opts.body);
      },
    },
  },
}));

// Dynamic import after mock is in place.
async function loadModule() {
  vi.resetModules();
  return await import("../aeasy-sync");
}

function makeResponse(status: number, payload: any) {
  return {
    status,
    clone() { return this; },
    async json() { return payload; },
    async text() { return JSON.stringify(payload); },
  } as unknown as Response;
}

beforeEach(() => {
  invokeCalls.length = 0;
  if (typeof window !== "undefined") window.localStorage.clear();
});
afterEach(() => { vi.restoreAllMocks(); });

describe("aeasy-sync invoke — mapeamento de erro estruturado", () => {
  it("extrai code/stage/details/status do payload JSON", async () => {
    mockImpl = async () => ({
      data: null,
      error: Object.assign(new Error("Edge Function returned a non-2xx status code"), {
        context: makeResponse(429, {
          ok: false, code: "COOLDOWN_ACTIVE", message: "Aguarde 10 min.",
          stage: "cooldown", remaining_min: 10,
        }),
      }),
    });
    const mod = await loadModule();
    await expect(mod.startSync("dry_run")).rejects.toMatchObject({
      code: "COOLDOWN_ACTIVE", stage: "cooldown", status: 429, remaining_min: 10,
      message: "Aguarde 10 min.",
    });
  });

  it("extrai code de erro de período (409 PART_IN_PROGRESS)", async () => {
    mockImpl = async () => ({
      data: null,
      error: Object.assign(new Error("HTTP 409"), {
        context: makeResponse(409, {
          ok: false, code: "PART_IN_PROGRESS", stage: "lock", period_key: "2024",
          message: "Período em execução.", retryable: true,
        }),
      }),
    });
    const mod = await loadModule();
    await expect(mod.processPeriod("s1", "2024")).rejects.toMatchObject({
      code: "PART_IN_PROGRESS", stage: "lock", period_key: "2024", status: 409,
    });
  });

  it("mantém mensagem de fallback quando o payload não é JSON", async () => {
    mockImpl = async () => ({
      data: null,
      error: Object.assign(new Error("boom"), {
        context: {
          status: 500,
          clone() { return this; },
          async json() { throw new Error("not json"); },
          async text() { return "server exploded"; },
        } as unknown as Response,
      }),
    });
    const mod = await loadModule();
    await expect(mod.getSyncStatus("x")).rejects.toMatchObject({
      status: 500, message: "server exploded",
    });
  });
});

describe("aeasy-sync localStorage helpers", () => {
  it("setStoredSyncId persiste e null limpa", async () => {
    const mod = await loadModule();
    mod.setStoredSyncId("abc");
    expect(mod.getStoredSyncId()).toBe("abc");
    mod.setStoredSyncId(null);
    expect(mod.getStoredSyncId()).toBeNull();
  });

  it("startSync grava sync_id retornado", async () => {
    mockImpl = async () => ({
      data: { ok: true, sync_id: "S-42", status: "collecting", mode: "dry_run",
        official_total: 100, official_total_matched_pattern: null,
        situacoes: [], periods: [] },
      error: null,
    });
    const mod = await loadModule();
    const res = await mod.startSync("dry_run");
    expect(res.sync_id).toBe("S-42");
    expect(mod.getStoredSyncId()).toBe("S-42");
  });

  it("cancelSync limpa o sync_id local", async () => {
    mockImpl = async () => ({ data: { ok: true, status: "cancelled" }, error: null });
    const mod = await loadModule();
    mod.setStoredSyncId("S-99");
    await mod.cancelSync("S-99");
    expect(mod.getStoredSyncId()).toBeNull();
  });
});

describe("orchestrateSync — processa períodos pendentes em sequência", () => {
  it("chama process_period para cada pending e finalize ao terminar", async () => {
    const parts = [
      { period_key: "2024", status: "pending", granularity: "year",
        period_year: 2024, date_start: "2024-01-01", date_end: "2024-12-31",
        attempt: 0, source_rows: 0, valid_rows: 0, invalid_rows: 0,
        discarded_status_rows: 0, file_name: null, file_size_bytes: null,
        duration_ms: null, error_code: null, error_message: null,
        split_into: null, parent_period_key: null },
      { period_key: "2025", status: "pending", granularity: "year",
        period_year: 2025, date_start: "2025-01-01", date_end: "2025-12-31",
        attempt: 0, source_rows: 0, valid_rows: 0, invalid_rows: 0,
        discarded_status_rows: 0, file_name: null, file_size_bytes: null,
        duration_ms: null, error_code: null, error_message: null,
        split_into: null, parent_period_key: null },
    ];
    const runBase = { sync_id: "S1", run_mode: "dry_run", status: "collecting",
      official_total: 100, periods_total: 2, periods_completed: 0, periods_failed: 0,
      valid_rows_total: 0, consolidated_total: null, ready_to_apply: null,
      started_at: "", finished_at: null, heartbeat_at: null, error_code: null,
      error_stage: null, error_message: null, statuses_detected: null, analysis: null,
      official_total_captured_at: null };
    let statusCall = 0;
    mockImpl = async (body) => {
      if (body.action === "status") {
        statusCall++;
        // primeira chamada: ambos pending. depois marca cada um como success à medida que process_period roda.
        return { data: { ok: true, run: runBase, parts: parts.map((p) => ({ ...p })) }, error: null };
      }
      if (body.action === "process_period") {
        const p = parts.find((x) => x.period_key === body.period_key)!;
        p.status = "success"; p.valid_rows = 50;
        return { data: { ok: true, period_key: p.period_key, status: "success", source_rows: 50, valid_rows: 50, duration_ms: 100 }, error: null };
      }
      if (body.action === "finalize") {
        return { data: { ok: true, sync_id: "S1", status: "success", mode: "dry_run", ready_to_apply: false, analysis: { consolidated_total: 100 } }, error: null };
      }
      return { data: null, error: null };
    };
    const mod = await loadModule();
    const report = await mod.orchestrateSync("S1", { intervalMs: 0 });
    expect(report?.status).toBe("success");
    const processed = invokeCalls.filter((c) => c.body.action === "process_period").map((c) => c.body.period_key);
    expect(processed.sort()).toEqual(["2024", "2025"]);
    expect(invokeCalls.some((c) => c.body.action === "finalize")).toBe(true);
    // status foi chamado ao menos 3x (inicial + entre períodos + antes de finalize)
    expect(statusCall).toBeGreaterThanOrEqual(3);
  });

  it("aciona split_period em EDGE_FUNCTION_RESOURCE_LIMIT para períodos não mensais", async () => {
    const runBase = { sync_id: "S2", run_mode: "dry_run", status: "collecting",
      official_total: 0, periods_total: 1, periods_completed: 0, periods_failed: 0,
      valid_rows_total: 0, consolidated_total: null, ready_to_apply: null,
      started_at: "", finished_at: null, heartbeat_at: null, error_code: null,
      error_stage: null, error_message: null, statuses_detected: null, analysis: null,
      official_total_captured_at: null };
    const state = {
      parts: [{ period_key: "2024", status: "pending", granularity: "year",
        period_year: 2024, date_start: "2024-01-01", date_end: "2024-12-31",
        attempt: 0, source_rows: 0, valid_rows: 0, invalid_rows: 0,
        discarded_status_rows: 0, file_name: null, file_size_bytes: null,
        duration_ms: null, error_code: null, error_message: null,
        split_into: null, parent_period_key: null }] as any[],
    };
    let splitCalled = false;
    mockImpl = async (body) => {
      if (body.action === "status") return { data: { ok: true, run: runBase, parts: state.parts.map((p) => ({ ...p })) }, error: null };
      if (body.action === "process_period") {
        return { data: null, error: Object.assign(new Error("Memory limit exceeded"), {
          context: makeResponse(500, { ok: false, code: "EDGE_FUNCTION_RESOURCE_LIMIT", stage: "resource_limit", message: "memory" }),
        }) };
      }
      if (body.action === "split_period") {
        splitCalled = true;
        state.parts[0].status = "split";
        state.parts.push({ period_key: "2024-Q1", status: "success", granularity: "quarter",
          period_year: 2024, date_start: "2024-01-01", date_end: "2024-03-31",
          attempt: 1, source_rows: 10, valid_rows: 10, invalid_rows: 0,
          discarded_status_rows: 0, file_name: "x.xlsx", file_size_bytes: 100,
          duration_ms: 50, error_code: null, error_message: null,
          split_into: null, parent_period_key: "2024" });
        return { data: { ok: true, split_into: [] }, error: null };
      }
      if (body.action === "finalize") return { data: { ok: true, status: "success" }, error: null };
      return { data: null, error: null };
    };
    const mod = await loadModule();
    // orchestrator vai propagar o erro se split não resolver — mas o próximo status já mostra o filho como success
    await mod.orchestrateSync("S2", { intervalMs: 0, maxRetries: 1 }).catch(() => {});
    expect(splitCalled).toBe(true);
  });

  it("relança erros que não são de recurso após maxRetries", async () => {
    const runBase: any = { sync_id: "S3", run_mode: "dry_run", status: "collecting",
      periods_total: 1, periods_completed: 0, periods_failed: 0, valid_rows_total: 0,
      consolidated_total: null, ready_to_apply: null, started_at: "", finished_at: null,
      heartbeat_at: null, error_code: null, error_stage: null, error_message: null,
      statuses_detected: null, analysis: null, official_total: null, official_total_captured_at: null };
    const parts = [{ period_key: "2024", status: "pending", granularity: "year",
      period_year: 2024, date_start: "2024-01-01", date_end: "2024-12-31", attempt: 0,
      source_rows: 0, valid_rows: 0, invalid_rows: 0, discarded_status_rows: 0,
      file_name: null, file_size_bytes: null, duration_ms: null, error_code: null,
      error_message: null, split_into: null, parent_period_key: null }];
    mockImpl = async (body) => {
      if (body.action === "status") return { data: { ok: true, run: runBase, parts }, error: null };
      if (body.action === "process_period") {
        return { data: null, error: Object.assign(new Error("boom"), {
          context: makeResponse(500, { ok: false, code: "GENERATE_REPORT_FAILED", stage: "generate_report", message: "boom" }),
        }) };
      }
      return { data: null, error: null };
    };
    const mod = await loadModule();
    await expect(mod.orchestrateSync("S3", { intervalMs: 0, maxRetries: 1 })).rejects.toBeDefined();
  });
});
