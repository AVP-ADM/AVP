// API layer para prestadores — leitura pública direta na view do Supabase e
// escritas por Edge Function protegida por código administrativo.
import { supabase } from "@/integrations/supabase/client";
import { makeSourceKey } from "./prestadores-seed";
import type { Prestador } from "./types";

export interface RemoteError {
  code: string;
  message: string;
  status?: number;
  retryAfterMs?: number;
  blockedUntilMs?: number;
}

export class PrestadoresApiError extends Error {
  code: string;
  status?: number;
  retryAfterMs?: number;
  blockedUntilMs?: number;
  constructor(err: RemoteError) {
    super(err.message);
    this.code = err.code;
    this.status = err.status;
    this.retryAfterMs = err.retryAfterMs;
    this.blockedUntilMs = err.blockedUntilMs;
  }
}

const ALLOWED_TIPO = new Set<Prestador["tiposAtendidos"][number]>(["carro", "moto", "caminhao"]);

function coerceTipos(raw: unknown): Prestador["tiposAtendidos"] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((t): t is Prestador["tiposAtendidos"][number] => typeof t === "string" && ALLOWED_TIPO.has(t as any));
}

export function rowToPrestador(row: Record<string, any>): Prestador {
  const nome = String(row.nome ?? "");
  const cidade = String(row.cidade ?? "");
  const uf = String(row.uf ?? "").toUpperCase();
  return {
    id: String(row.id ?? ""),
    nome,
    cidade,
    uf,
    latitude: row.latitude == null ? null : Number(row.latitude),
    longitude: row.longitude == null ? null : Number(row.longitude),
    tiposAtendidos: coerceTipos(row.tipos_atendidos),
    capacidadeMensal: row.capacidade_mensal == null ? null : Number(row.capacidade_mensal),
    raioKm: row.raio_atendimento_km == null ? 30 : Number(row.raio_atendimento_km),
    status: (row.status === "inativo" ? "inativo" : row.status === "pendente" ? "pendente" : "ativo") as Prestador["status"],
    fonte: row.fonte ?? undefined,
    sourceKey: row.source_key ?? makeSourceKey(nome, cidade, uf),
    localizacaoAproximada: row.localizacao_aproximada ?? undefined,
  };
}

export function prestadorToRemoteInput(p: Prestador): Record<string, unknown> {
  return {
    nome: p.nome,
    cidade: p.cidade,
    uf: p.uf,
    latitude: p.latitude,
    longitude: p.longitude,
    raio_atendimento_km: p.raioKm,
    status: p.status,
    capacidade_mensal: p.capacidadeMensal,
    tipos_atendidos: p.tiposAtendidos.length ? p.tiposAtendidos : null,
    fonte: p.fonte ?? null,
    source_key: p.sourceKey || makeSourceKey(p.nome, p.cidade, p.uf),
    localizacao_aproximada: p.localizacaoAproximada ?? true,
  };
}

export async function fetchPrestadoresFromSupabase(): Promise<Prestador[]> {
  const { data, error } = await supabase
    .from("public_tracking_service_providers")
    .select("id, nome, cidade, uf, latitude, longitude, raio_atendimento_km, status, capacidade_mensal, tipos_atendidos, fonte, localizacao_aproximada, updated_at")
    .order("nome");
  if (error) throw new PrestadoresApiError({ code: "read_failed", message: error.message });
  return (data ?? []).map(rowToPrestador);
}

async function invokeManage(body: Record<string, unknown>): Promise<any> {
  const { data, error } = await supabase.functions.invoke("manage-tracking-provider", {
    body,
  });
  // supabase-js retorna erro em `error`, mas o corpo com detalhes vem em `data` mesmo quando o status != 2xx
  if (error && !data) {
    throw new PrestadoresApiError({
      code: "network_error",
      message: error.message ?? "Falha de rede",
    });
  }
  const payload = data as any;
  if (payload?.ok) return payload;
  const errObj = payload?.error ?? {};
  throw new PrestadoresApiError({
    code: errObj.code ?? "unknown_error",
    message: errObj.message ?? "Erro ao processar solicitação",
    status: errObj.status,
    retryAfterMs: errObj.retry_after_ms,
    blockedUntilMs: errObj.blocked_until_ms,
  });
}

export interface CreateArgs { adminCode: string; provider: Prestador }
export async function createPrestadorRemote({ adminCode, provider }: CreateArgs): Promise<Prestador> {
  const res = await invokeManage({ action: "create", admin_code: adminCode, provider: prestadorToRemoteInput(provider) });
  return rowToPrestador(res.provider);
}

export interface UpdateArgs { adminCode: string; id: string; patch: Partial<Prestador> }
export async function updatePrestadorRemote({ adminCode, id, patch }: UpdateArgs): Promise<Prestador> {
  const remotePatch: Record<string, unknown> = {};
  if (patch.nome !== undefined) remotePatch.nome = patch.nome;
  if (patch.cidade !== undefined) remotePatch.cidade = patch.cidade;
  if (patch.uf !== undefined) remotePatch.uf = patch.uf;
  if (patch.latitude !== undefined) remotePatch.latitude = patch.latitude;
  if (patch.longitude !== undefined) remotePatch.longitude = patch.longitude;
  if (patch.raioKm !== undefined) remotePatch.raio_atendimento_km = patch.raioKm;
  if (patch.status !== undefined) remotePatch.status = patch.status;
  if (patch.capacidadeMensal !== undefined) remotePatch.capacidade_mensal = patch.capacidadeMensal;
  if (patch.tiposAtendidos !== undefined) remotePatch.tipos_atendidos = patch.tiposAtendidos.length ? patch.tiposAtendidos : null;
  if (patch.fonte !== undefined) remotePatch.fonte = patch.fonte ?? null;
  if (patch.localizacaoAproximada !== undefined) remotePatch.localizacao_aproximada = patch.localizacaoAproximada;
  const res = await invokeManage({ action: "update", admin_code: adminCode, id, patch: remotePatch });
  return rowToPrestador(res.provider);
}

export async function activatePrestadorRemote(adminCode: string, id: string): Promise<Prestador> {
  const res = await invokeManage({ action: "activate", admin_code: adminCode, id });
  return rowToPrestador(res.provider);
}

export async function deactivatePrestadorRemote(adminCode: string, id: string): Promise<Prestador> {
  const res = await invokeManage({ action: "deactivate", admin_code: adminCode, id });
  return rowToPrestador(res.provider);
}

export async function deletePrestadorRemote(adminCode: string, id: string): Promise<void> {
  await invokeManage({ action: "delete", admin_code: adminCode, id });
}

export interface MigrateResult { inserted: number; skipped: number }
export async function migrateLocalPrestadores(adminCode: string, providers: Prestador[]): Promise<MigrateResult> {
  if (!providers.length) return { inserted: 0, skipped: 0 };
  const res = await invokeManage({
    action: "migrate_missing",
    admin_code: adminCode,
    providers: providers.map(prestadorToRemoteInput),
  });
  return { inserted: res.inserted ?? 0, skipped: res.skipped ?? 0 };
}

export function subscribePrestadoresRealtime(onChange: () => void): () => void {
  const channel = supabase
    .channel("tracking_service_providers_changes")
    .on(
      "postgres_changes" as any,
      { event: "*", schema: "public", table: "tracking_service_providers" },
      () => onChange(),
    )
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}
