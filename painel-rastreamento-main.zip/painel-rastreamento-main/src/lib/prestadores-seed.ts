import { lookupCoords, hasExactCoords } from "./city-coords";
import type { Prestador } from "./types";

// Prestadores extraídos do mapa anterior da AVP.
// Fonte: https://avp-adm.github.io/AVP/mapa-associados.html
// Nome preservado exatamente como consta no mapa anterior.
export const PRESTADORES_MAPA_ANTERIOR: Array<{
  nome: string;
  cidade: string;
  uf: string;
}> = [
  { nome: "IBS", cidade: "Petrolina", uf: "PE" },
  { nome: "Hiago", cidade: "Recife", uf: "PE" },
  { nome: "Joas", cidade: "Carpina", uf: "PE" },
  { nome: "Nunes", cidade: "Serra Talhada", uf: "PE" },
  { nome: "Laudisvan", cidade: "Arapiraca", uf: "AL" },
  { nome: "Cleysinho", cidade: "Batalha", uf: "AL" },
  { nome: "Mundial Radar", cidade: "Feira de Santana", uf: "BA" },
  { nome: "Jean", cidade: "Salvador", uf: "BA" },
  { nome: "Box Car", cidade: "Itabuna", uf: "BA" },
  { nome: "JS Rastreamento", cidade: "Ilhéus", uf: "BA" },
  { nome: "Rafael Soares", cidade: "Senhor do Bonfim", uf: "BA" },
  { nome: "Leandro", cidade: "Remanso", uf: "BA" },
  { nome: "Elite Parts", cidade: "Mossoró", uf: "RN" },
  { nome: "Werick", cidade: "Vitória", uf: "ES" },
  { nome: "Marcelo", cidade: "Juazeiro do Norte", uf: "CE" },
  { nome: "David Mendonca", cidade: "Crato", uf: "CE" },
  { nome: "Troia", cidade: "Fortaleza", uf: "CE" },
  { nome: "FI'CAR", cidade: "Fortaleza", uf: "CE" },
  { nome: "Andre Moroni", cidade: "Morada Nova", uf: "CE" },
  { nome: "Jarlan", cidade: "Queimada Nova", uf: "PI" },
];

const normalize = (s: string) =>
  (s ?? "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

export function makeSourceKey(nome: string, cidade: string, uf: string): string {
  return `${normalize(nome)}__${normalize(cidade)}__${uf.toLowerCase()}`;
}

export interface SeedReport {
  inserted: number;
  existed: number;
  duplicatesIgnored: number;
  withoutCoords: string[];
}

const uid = () => Math.random().toString(36).slice(2, 10);

// Rotina idempotente: apenas insere prestadores do mapa anterior que ainda
// não existam pela chave estável source_key. Edições manuais são preservadas.
export function seedPrestadoresMapaAnterior(existing: Prestador[]): {
  next: Prestador[];
  report: SeedReport;
} {
  const bySourceKey = new Map<string, Prestador>();
  const seen = new Set<string>();
  for (const p of existing) {
    const key = p.sourceKey ?? makeSourceKey(p.nome, p.cidade, p.uf);
    if (!bySourceKey.has(key)) bySourceKey.set(key, p);
  }

  const report: SeedReport = {
    inserted: 0,
    existed: 0,
    duplicatesIgnored: 0,
    withoutCoords: [],
  };
  const next: Prestador[] = [...existing];

  for (const seed of PRESTADORES_MAPA_ANTERIOR) {
    const key = makeSourceKey(seed.nome, seed.cidade, seed.uf);
    if (seen.has(key)) {
      report.duplicatesIgnored++;
      continue;
    }
    seen.add(key);
    if (bySourceKey.has(key)) {
      report.existed++;
      continue;
    }
    const coords = lookupCoords(seed.cidade, seed.uf);
    const exact = hasExactCoords(seed.cidade, seed.uf);
    if (!coords) {
      report.withoutCoords.push(`${seed.nome} — ${seed.cidade}/${seed.uf}`);
    }
    const prestador: Prestador = {
      id: uid(),
      nome: seed.nome,
      cidade: seed.cidade,
      uf: seed.uf.toUpperCase(),
      latitude: coords ? coords[0] : null,
      longitude: coords ? coords[1] : null,
      tiposAtendidos: [],
      capacidadeMensal: null,
      raioKm: 30,
      status: "ativo",
      fonte: "mapa_anterior_avp",
      sourceKey: key,
      localizacaoAproximada: !exact,
    };
    next.push(prestador);
    report.inserted++;
  }

  return { next, report };
}
