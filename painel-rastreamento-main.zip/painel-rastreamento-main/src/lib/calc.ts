import { cityKey } from "./classify";
import { lookupCoords } from "./city-coords";
import type {
  Associado,
  AppFilter,
  AppSettings,
  CidadeMetric,
  NivelRisco,
  Prestador,
  RegraAplicada,
  RegraRisco,
  TipoVeiculo,
} from "./types";
import { NIVEL_RISCO_SCORE } from "./types";

export interface GlobalMetrics {
  total: number;
  ativos: number;
  suspensos: number;
  cancelados: number;
  operacionais: number;
  comRastreador: number;
  semRastreador: number;
  cobertura: number;
  canceladosComRastreador: number;
  motos: number;
  carros: number;
  caminhoes: number;
  naoClassificados: number;
}

export function applyFilter(assocs: Associado[], filter?: AppFilter | null): Associado[] {
  if (!filter) return assocs;
  const { tipoVeiculo, categoria } = filter;
  if (tipoVeiculo === "todos" && !categoria) return assocs;
  return assocs.filter((a) => {
    if (tipoVeiculo !== "todos" && a.tipo !== tipoVeiculo) return false;
    if (categoria && a.categoriaOriginal !== categoria) return false;
    return true;
  });
}

export function computeGlobal(assocs: Associado[]): GlobalMetrics {
  const m: GlobalMetrics = {
    total: assocs.length,
    ativos: 0,
    suspensos: 0,
    cancelados: 0,
    operacionais: 0,
    comRastreador: 0,
    semRastreador: 0,
    cobertura: 0,
    canceladosComRastreador: 0,
    motos: 0,
    carros: 0,
    caminhoes: 0,
    naoClassificados: 0,
  };
  for (const a of assocs) {
    if (a.situacao === "ativo") m.ativos++;
    else if (a.situacao === "suspenso") m.suspensos++;
    else if (a.situacao === "cancelado") m.cancelados++;
    if (a.operacional) {
      m.operacionais++;
      if (a.temRastreador) m.comRastreador++;
      else m.semRastreador++;
      if (a.tipo === "moto") m.motos++;
      else if (a.tipo === "carro") m.carros++;
      else if (a.tipo === "caminhao") m.caminhoes++;
      else m.naoClassificados++;
    } else if (a.situacao === "cancelado" && a.temRastreador) {
      m.canceladosComRastreador++;
    }
  }
  m.cobertura = m.operacionais ? m.comRastreador / m.operacionais : 0;
  return m;
}

// Distância em km entre dois pontos (Haversine).
export function haversineKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const toRad = (v: number) => (v * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

const NIVEL_ORDER: NivelRisco[] = [
  "sem_classificacao",
  "baixo",
  "medio",
  "alto",
  "critico",
];

// Retorna a regra mais específica que atinge o ponto, aplicando a precedência:
// 1. Regra específica por tipo (vence "todos")
// 2. Regra com menor raio
// 3. Regra com maior nível de risco
// 4. Regra atualizada mais recentemente
export function matchRegra(
  lat: number,
  lng: number,
  tipo: TipoVeiculo | "todos",
  regras: RegraRisco[]
): { regra: RegraRisco; distanciaKm: number } | null {
  const candidatas: Array<{ regra: RegraRisco; distanciaKm: number }> = [];
  for (const r of regras) {
    if (r.status !== "ativa") continue;
    if (r.latCentral == null || r.lngCentral == null) continue;
    if (r.tipoVeiculo !== "todos" && tipo !== "todos" && r.tipoVeiculo !== tipo) continue;
    const d = haversineKm(lat, lng, r.latCentral, r.lngCentral);
    if (d <= r.raioKm) candidatas.push({ regra: r, distanciaKm: d });
  }
  if (!candidatas.length) return null;
  candidatas.sort((a, b) => {
    const aEsp = a.regra.tipoVeiculo === "todos" ? 1 : 0;
    const bEsp = b.regra.tipoVeiculo === "todos" ? 1 : 0;
    if (aEsp !== bEsp) return aEsp - bEsp; // específica primeiro
    if (a.regra.raioKm !== b.regra.raioKm) return a.regra.raioKm - b.regra.raioKm;
    const na = NIVEL_ORDER.indexOf(a.regra.nivelRisco);
    const nb = NIVEL_ORDER.indexOf(b.regra.nivelRisco);
    if (na !== nb) return nb - na; // maior nível primeiro
    return (b.regra.atualizadoEm || "").localeCompare(a.regra.atualizadoEm || "");
  });
  return candidatas[0]!;
}

function toAplicada(m: { regra: RegraRisco; distanciaKm: number }): RegraAplicada {
  return {
    id: m.regra.id,
    nome: m.regra.nome || `${m.regra.cidade}/${m.regra.uf}`,
    distanciaKm: Math.round(m.distanciaKm * 10) / 10,
    nivelRisco: m.regra.nivelRisco,
    politica: m.regra.politica,
    motivo: m.regra.motivo,
    fonte: m.regra.fonte,
    atualizadoEm: m.regra.atualizadoEm,
    tipoVeiculo: m.regra.tipoVeiculo,
    raioKm: m.regra.raioKm,
  };
}

export function computeCities(
  assocs: Associado[],
  prestadores: Prestador[],
  regras: RegraRisco[],
  settings: AppSettings,
  filterTipo: TipoVeiculo | "todos" = "todos"
): CidadeMetric[] {
  const map = new Map<string, CidadeMetric>();
  for (const a of assocs) {
    if (!a.cidade || !a.estado) continue;
    const key = cityKey(a.cidade, a.estado);
    let c = map.get(key);
    if (!c) {
      const coords = lookupCoords(a.cidade, a.estado);
      c = {
        cidade: a.cidade,
        uf: a.estado,
        chave: key,
        total: 0,
        operacionais: 0,
        comRastreador: 0,
        semRastreador: 0,
        cobertura: 0,
        canceladosComRastreador: 0,
        motos: 0,
        carros: 0,
        caminhoes: 0,
        naoClassificados: 0,
        prestadoresAtivos: 0,
        prestadoresNecessarios: 0,
        deficit: 0,
        nivelRisco: "sem_classificacao",
        riscoScore: 0,
        regraAplicada: null,
        politica: null,
        score: 0,
        prioridade: "baixo",
        lat: coords ? coords[0] : null,
        lng: coords ? coords[1] : null,
      };
      map.set(key, c);
    }
    c.total++;
    if (a.operacional) {
      c.operacionais++;
      if (a.temRastreador) c.comRastreador++;
      else c.semRastreador++;
      if (a.tipo === "moto") c.motos++;
      else if (a.tipo === "carro") c.carros++;
      else if (a.tipo === "caminhao") c.caminhoes++;
      else c.naoClassificados++;
    } else if (a.situacao === "cancelado" && a.temRastreador) {
      c.canceladosComRastreador++;
    }
  }

  // Prestadores por cidade
  for (const p of prestadores) {
    if (p.status !== "ativo") continue;
    const key = cityKey(p.cidade, p.uf);
    const c = map.get(key);
    if (c) c.prestadoresAtivos++;
  }

  // Nível de risco: derivado exclusivamente das áreas de risco cadastradas.
  // Usa o centroide da cidade e aplica precedência (matchRegra).
  for (const c of map.values()) {
    if (c.lat == null || c.lng == null) continue;
    const m = matchRegra(c.lat, c.lng, filterTipo, regras);
    if (m) {
      c.nivelRisco = m.regra.nivelRisco;
      c.riscoScore = NIVEL_RISCO_SCORE[m.regra.nivelRisco];
      c.regraAplicada = toAplicada(m);
      c.politica = m.regra.politica;
    }
  }

  const list = Array.from(map.values());

  // ==== Prioridade OPERACIONAL (independente do risco de roubo/furto) ====
  const semRastSorted = [...list].sort((a, b) => b.semRastreador - a.semRastreador);
  const top20Set = new Set(semRastSorted.slice(0, 20).map((x) => x.chave));
  const maxSem = semRastSorted[0]?.semRastreador || 1;
  const maxCanc = list.reduce((m, c) => Math.max(m, c.canceladosComRastreador), 0) || 1;

  for (const c of list) {
    const ratio = top20Set.has(c.chave) ? settings.ratioAlta : settings.ratioNormal;
    let necess = c.semRastreador / ratio;
    if (c.operacionais > 0 && c.motos / c.operacionais > 0.5) {
      necess *= settings.motoBoost;
    }
    c.prestadoresNecessarios = Math.ceil(necess);
    c.deficit = Math.max(c.prestadoresNecessarios - c.prestadoresAtivos, 0);
    c.cobertura = c.operacionais ? c.comRastreador / c.operacionais : 0;

    // Score OPERACIONAL — NÃO usa nivelRisco (risco de roubo é indicador separado)
    let score = 0;
    if (top20Set.has(c.chave)) score += 40;
    score += Math.min(30, (c.semRastreador / maxSem) * 30);
    score += Math.min(15, (c.canceladosComRastreador / maxCanc) * 15);
    if (c.deficit > 0) score += Math.min(15, c.deficit * 3);
    c.score = Math.round(score);
    if (score >= 80) c.prioridade = "critico";
    else if (score >= 60) c.prioridade = "alto";
    else if (score >= 40) c.prioridade = "medio";
    else c.prioridade = "baixo";
  }

  return list;
}

export interface DataQualityIssue {
  tipo: string;
  descricao: string;
  quantidade: number;
  registros: Array<{
    index: number;
    associado: string;
    placa: string;
    cidade: string;
    estado: string;
    valor: string;
  }>;
}

export function computeDataQuality(assocs: Associado[]): DataQualityIssue[] {
  const placaVazia: DataQualityIssue["registros"] = [];
  const rastVazio: DataQualityIssue["registros"] = [];
  const cidadeVazia: DataQualityIssue["registros"] = [];
  const categoriaNC: DataQualityIssue["registros"] = [];
  const situacaoNP: DataQualityIssue["registros"] = [];
  const fipeInv: DataQualityIssue["registros"] = [];
  const placas = new Map<string, number[]>();
  const rasts = new Map<string, number[]>();

  assocs.forEach((a, i) => {
    if (!a.placa) placaVazia.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: "" });
    else {
      const arr = placas.get(a.placa) || [];
      arr.push(i);
      placas.set(a.placa, arr);
    }
    if (a.operacional && !a.temRastreador)
      rastVazio.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: a.numeroRastreador });
    else if (a.temRastreador) {
      const arr = rasts.get(a.numeroRastreador) || [];
      arr.push(i);
      rasts.set(a.numeroRastreador, arr);
    }
    if (!a.cidade || !a.estado)
      cidadeVazia.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: `${a.cidade}/${a.estado}` });
    if (a.tipo === "nao_classificado")
      categoriaNC.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: a.categoriaOriginal || a.categoria });
    if (a.situacao === "outro")
      situacaoNP.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: a.situacaoOriginal });
    if (a.valorFipe == null || a.valorFipe <= 0)
      fipeInv.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: String(a.valorFipe ?? "") });
  });

  const placaDup: DataQualityIssue["registros"] = [];
  for (const [placa, idxs] of placas) {
    if (idxs.length > 1) {
      for (const i of idxs) {
        const a = assocs[i]!;
        placaDup.push({ index: i, associado: a.associado, placa, cidade: a.cidade, estado: a.estado, valor: `${idxs.length} ocorrencias` });
      }
    }
  }
  const rastDup: DataQualityIssue["registros"] = [];
  for (const [r, idxs] of rasts) {
    if (idxs.length > 1) {
      for (const i of idxs) {
        const a = assocs[i]!;
        rastDup.push({ index: i, associado: a.associado, placa: a.placa, cidade: a.cidade, estado: a.estado, valor: `${r} (${idxs.length}x)` });
      }
    }
  }

  return [
    { tipo: "placa_vazia", descricao: "Placa vazia", quantidade: placaVazia.length, registros: placaVazia.slice(0, 500) },
    { tipo: "placa_duplicada", descricao: "Placa duplicada", quantidade: placaDup.length, registros: placaDup.slice(0, 500) },
    { tipo: "rastreador_ausente", descricao: "Operacional sem rastreador válido", quantidade: rastVazio.length, registros: rastVazio.slice(0, 500) },
    { tipo: "rastreador_duplicado", descricao: "Rastreador duplicado", quantidade: rastDup.length, registros: rastDup.slice(0, 500) },
    { tipo: "cidade_uf_vazia", descricao: "Cidade/UF vazia", quantidade: cidadeVazia.length, registros: cidadeVazia.slice(0, 500) },
    { tipo: "categoria_nao_classificada", descricao: "Categoria não classificada (revisar)", quantidade: categoriaNC.length, registros: categoriaNC.slice(0, 500) },
    { tipo: "situacao_fora_padrao", descricao: "Situação fora do padrão", quantidade: situacaoNP.length, registros: situacaoNP.slice(0, 500) },
    { tipo: "fipe_invalido", descricao: "Valor FIPE ausente ou inválido", quantidade: fipeInv.length, registros: fipeInv.slice(0, 500) },
  ];
}

export interface UnclassifiedGroup {
  categoriaOriginal: string;
  total: number;
  operacionais: number;
  ativos: number;
  suspensos: number;
  cancelados: number;
  situacaoPredominante: string;
  motivo: string;
}

// Agrupa os registros "nao_classificado" por categoria original para a aba Qualidade.
export function computeUnclassifiedGroups(assocs: Associado[]): UnclassifiedGroup[] {
  const groups = new Map<string, UnclassifiedGroup>();
  for (const a of assocs) {
    if (a.tipo !== "nao_classificado") continue;
    const key = (a.categoriaOriginal || a.categoria || "(vazio)").trim() || "(vazio)";
    let g = groups.get(key);
    if (!g) {
      g = {
        categoriaOriginal: key,
        total: 0,
        operacionais: 0,
        ativos: 0,
        suspensos: 0,
        cancelados: 0,
        situacaoPredominante: "",
        motivo: "",
      };
      groups.set(key, g);
    }
    g.total++;
    if (a.operacional) g.operacionais++;
    if (a.situacao === "ativo") g.ativos++;
    else if (a.situacao === "suspenso") g.suspensos++;
    else if (a.situacao === "cancelado") g.cancelados++;
  }
  const ADMIN = new Set([
    "rastreamento monitoramento comodato",
    "inativado",
    "teste",
  ]);
  const norm = (s: string) =>
    s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  for (const g of groups.values()) {
    const pairs: Array<[string, number]> = [
      ["ativo", g.ativos],
      ["suspenso", g.suspensos],
      ["cancelado", g.cancelados],
    ];
    pairs.sort((a, b) => b[1] - a[1]);
    g.situacaoPredominante = pairs[0]![1] > 0 ? pairs[0]![0] : "outro";
    if (ADMIN.has(norm(g.categoriaOriginal))) {
      g.motivo = "Categoria administrativa / produto / teste";
    } else if (!g.categoriaOriginal || g.categoriaOriginal === "(vazio)") {
      g.motivo = "Categoria vazia";
    } else {
      g.motivo = "Categoria fora do mapeamento oficial e sem alias aprovado";
    }
  }
  return Array.from(groups.values()).sort((a, b) => b.total - a.total);
}

export type { TipoVeiculo };

