import * as XLSX from "xlsx";
import type { Associado, Prestador, RegraRisco } from "./types";
import type { CityAgg, MapFilter, ProviderReach } from "./map-filter";
import { providersServingCity, nivelRiscoManual } from "./map-filter";
import { NIVEL_RISCO_LABEL } from "./types";

function filterLabel(f: MapFilter): string {
  const parts: string[] = [];
  if (f.tipos.length) parts.push(f.tipos.join("+"));
  if (f.rastreamento.length) parts.push(f.rastreamento.join("+"));
  if (f.riscos.length) parts.push("risco-" + f.riscos.join("+"));
  if (f.situacoes.length && f.situacoes.length < 3) parts.push(f.situacoes.join("+"));
  const s = parts.join("-").replace(/[^a-z0-9+\-]/gi, "").toLowerCase();
  return s || "todos";
}

export function exportFilteredXlsx(params: {
  filter: MapFilter;
  filteredAssociados: Associado[];
  cities: CityAgg[];
  prestadores: Prestador[];
  regras: RegraRisco[];
}) {
  const { filter, filteredAssociados, cities, prestadores, regras } = params;
  const wb = XLSX.utils.book_new();

  // ==== Registros
  const regRows = filteredAssociados.map((a) => ({
    associado: a.associado,
    placa: a.placa,
    cidade: a.cidade,
    uf: a.estado,
    tipo: a.tipo,
    categoria_original: a.categoriaOriginal,
    situacao: a.situacao,
    tem_rastreador_valido: a.temRastreador ? "sim" : "nao",
    numero_rastreador: a.numeroRastreador,
    consultor: a.consultor,
    plano: a.plano,
    valor_fipe: a.valorFipe ?? "",
    risco_manual: nivelRiscoManual(a, regras),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(regRows), "Registros");

  // ==== Cidades
  const cityRows = cities.map((c) => {
    const reach = c.lat != null && c.lng != null
      ? providersServingCity(c.lat, c.lng, prestadores, filter)
      : [];
    const compat = reach.filter((r) => r.compatibleWithTypes);
    return {
      cidade: c.cidade,
      uf: c.uf,
      registros: c.total,
      ativos: c.ativos,
      suspensos: c.suspensos,
      cancelados: c.cancelados,
      com_rastreador: c.comRastreador,
      sem_rastreador: c.semRastreador,
      rastreador_invalido: c.rastreadorInvalido,
      carros: c.carros,
      motos: c.motos,
      caminhoes: c.caminhoes,
      nao_classificados: c.naoClassificados,
      prestadores_no_raio: reach.length,
      prestadores_compativeis_tipo: compat.length,
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(cityRows), "Cidades");

  // ==== Resumo
  const totais = cityRows.reduce((acc, r) => {
    acc.registros += r.registros;
    acc.com += r.com_rastreador;
    acc.sem += r.sem_rastreador;
    return acc;
  }, { registros: 0, com: 0, sem: 0 });
  const semPrestador = cityRows.filter((r) => r.prestadores_no_raio === 0).length;
  const totalPrestReach = new Set<string>();
  for (const c of cities) {
    if (c.lat == null || c.lng == null) continue;
    const reach = providersServingCity(c.lat, c.lng, prestadores, filter);
    for (const r of reach) totalPrestReach.add(r.prestador.id);
  }
  const nivelCount: Record<string, number> = {};
  for (const a of filteredAssociados) {
    const n = nivelRiscoManual(a, regras);
    nivelCount[n] = (nivelCount[n] || 0) + 1;
  }
  const resumo = [
    { chave: "exportado_em", valor: new Date().toISOString() },
    { chave: "filtros_tipos", valor: filter.tipos.join(",") || "todos" },
    { chave: "filtros_situacoes", valor: filter.situacoes.join(",") || "todos" },
    { chave: "filtros_rastreamento", valor: filter.rastreamento.join(",") || "todos" },
    { chave: "filtros_riscos", valor: filter.riscos.join(",") || "todos" },
    { chave: "filtros_ufs", valor: filter.ufs.join(",") || "todos" },
    { chave: "filtros_cidades", valor: filter.cidades.join(",") || "todos" },
    { chave: "filtros_categorias", valor: filter.categorias.join(",") || "todos" },
    { chave: "dentro_risco_manual", valor: filter.dentroRiscoManual == null ? "-" : String(filter.dentroRiscoManual) },
    { chave: "dentro_raio_prestador", valor: filter.dentroRaioPrestador == null ? "-" : String(filter.dentroRaioPrestador) },
    { chave: "total_registros", valor: totais.registros },
    { chave: "total_cidades", valor: cityRows.length },
    { chave: "com_rastreador", valor: totais.com },
    { chave: "sem_rastreador", valor: totais.sem },
    { chave: "prestadores_atendendo_regioes", valor: totalPrestReach.size },
    { chave: "cidades_sem_prestador_no_raio", valor: semPrestador },
    ...Object.entries(nivelCount).map(([k, v]) => ({ chave: `risco_${k}`, valor: v })),
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(resumo), "Resumo");

  const fname = `mapa-${filterLabel(filter)}.xlsx`;
  XLSX.writeFile(wb, fname);
}

export type { ProviderReach };
