// Feature flags do painel.
// A integração automática com o AEasy está desativada por padrão.
// Para reabilitar (uso interno/dev), defina VITE_ENABLE_AEASY_SYNC=true no .env
// ou true na variável de ambiente em build. O código da integração
// (edge function, RPCs, cliente, testes) permanece preservado como legado.

const flag = (name: string): boolean => {
  try {
    // Vite injects import.meta.env at build time.
    const v = (import.meta as any).env?.[name];
    return String(v ?? "").toLowerCase() === "true";
  } catch {
    return false;
  }
};

export const ENABLE_AEASY_SYNC = flag("VITE_ENABLE_AEASY_SYNC");
