import * as XLSX from "xlsx";
import type { Associado, ColumnMapping } from "./types";
import {
  classifySituacao,
  classifyTipoVeiculo,
  hasValidTracker,
  normalizeCidade,
  normalizeUF,
  parseFipe,
} from "./classify";

const normalize = (s: string) =>
  (s ?? "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

const CANDIDATES: Record<keyof ColumnMapping, string[]> = {
  associado: ["associado", "nome", "cliente"],
  placa: ["placa", "placa veiculo"],
  numeroRastreador: [
    "numero rastreador",
    "num rastreador",
    "rastreador",
    "id rastreador",
    "codigo rastreador",
    "imei",
  ],
  consultor: ["consultor", "vendedor", "captador"],
  cidade: ["cidade", "municipio"],
  estado: ["estado", "uf"],
  plano: ["plano", "contrato"],
  situacao: ["situacao", "status", "situacao contrato"],
  valorFipe: ["valor fipe", "fipe", "valor veiculo", "valor do veiculo"],
  categoria: ["categoria", "tipo veiculo", "tipo do veiculo", "especie"],
};

export function autoDetectColumns(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {};
  const normHeaders = headers.map((h) => ({ raw: h, n: normalize(h) }));
  (Object.keys(CANDIDATES) as (keyof ColumnMapping)[]).forEach((field) => {
    const options = CANDIDATES[field];
    for (const opt of options) {
      const hit = normHeaders.find((h) => h.n === opt || h.n.includes(opt));
      if (hit) {
        mapping[field] = hit.raw;
        return;
      }
    }
  });
  return mapping;
}

export interface ParseResult {
  headers: string[];
  rows: Record<string, unknown>[];
  sheetName: string;
}

export async function readWorkbook(file: File): Promise<ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  // Preferir aba "Worksheet" se existir
  const sheetName =
    wb.SheetNames.find((n) => n.toLowerCase() === "worksheet") ||
    wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, {
    defval: "",
    raw: true,
  });
  const headers = rows.length ? Object.keys(rows[0]) : [];
  return { headers, rows, sheetName };
}

export function buildAssociados(
  rows: Record<string, unknown>[],
  mapping: ColumnMapping
): Associado[] {
  const get = (row: Record<string, unknown>, k: keyof ColumnMapping) => {
    const col = mapping[k];
    if (!col) return "";
    const v = row[col];
    return v == null ? "" : String(v);
  };
  const result: Associado[] = new Array(rows.length);
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const situacaoRaw = get(row, "situacao");
    const situacao = classifySituacao(situacaoRaw);
    const categoria = get(row, "categoria");
    const tipo = classifyTipoVeiculo(categoria);
    const rastreador = get(row, "numeroRastreador");
    const temRastreador = hasValidTracker(rastreador);
    const catTrim = categoria.trim();
    result[i] = {
      associado: get(row, "associado").trim(),
      placa: get(row, "placa").trim().toUpperCase(),
      numeroRastreador: rastreador.trim(),
      consultor: get(row, "consultor").trim(),
      cidade: normalizeCidade(get(row, "cidade")),
      estado: normalizeUF(get(row, "estado")),
      plano: get(row, "plano").trim(),
      situacao,
      situacaoOriginal: situacaoRaw.trim(),
      valorFipe: parseFipe(row[mapping.valorFipe ?? ""]),
      categoria: catTrim,
      categoriaOriginal: catTrim,
      tipo,
      temRastreador,
      operacional: situacao === "ativo" || situacao === "suspenso",
    };
  }
  return result;
}
