const nf = new Intl.NumberFormat("pt-BR");
const pf = new Intl.NumberFormat("pt-BR", { style: "percent", maximumFractionDigits: 1 });
const cf = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

export const fmtInt = (n: number | null | undefined) =>
  n == null || !Number.isFinite(n) ? "—" : nf.format(Math.round(n));
export const fmtPct = (n: number | null | undefined) =>
  n == null || !Number.isFinite(n) ? "—" : pf.format(n);
export const fmtBRL = (n: number | null | undefined) =>
  n == null || !Number.isFinite(n) ? "—" : cf.format(n);
