export type Situacao = "ativo" | "suspenso" | "cancelado" | "outro";
export type TipoVeiculo = "carro" | "moto" | "caminhao" | "nao_classificado";

export interface Associado {
  associado: string;
  placa: string;
  numeroRastreador: string;
  consultor: string;
  cidade: string;
  estado: string;
  plano: string;
  situacao: Situacao;
  situacaoOriginal: string;
  valorFipe: number | null;
  categoria: string;
  categoriaOriginal: string;
  tipo: TipoVeiculo;
  temRastreador: boolean;
  operacional: boolean; // ativo ou suspenso
}

export interface ColumnMapping {
  associado?: string;
  placa?: string;
  numeroRastreador?: string;
  consultor?: string;
  cidade?: string;
  estado?: string;
  plano?: string;
  situacao?: string;
  valorFipe?: string;
  categoria?: string;
}

export interface Prestador {
  id: string;
  nome: string;
  cidade: string;
  uf: string;
  latitude: number | null;
  longitude: number | null;
  tiposAtendidos: TipoVeiculo[];
  capacidadeMensal: number | null;
  raioKm: number;
  status: "ativo" | "pendente" | "inativo";
  fonte?: string;
  sourceKey?: string;
  localizacaoAproximada?: boolean;
}

export type NivelRisco = "sem_classificacao" | "baixo" | "medio" | "alto" | "critico";
export type Politica =
  | "aceita_normalmente"
  | "aceita_somente_com_rastreador"
  | "aceita_com_vistoria"
  | "nao_aceita_moto"
  | "nao_aceita";

export type RegraTipoVeiculo = "todos" | TipoVeiculo;

// Área de risco definida manualmente pela empresa.
// Não deriva de dados operacionais (quantidade de associados, cobertura etc.).
export interface RegraRisco {
  id: string;
  nome: string;
  uf: string;
  cidade: string;
  latCentral: number | null;
  lngCentral: number | null;
  raioKm: number;
  tipoVeiculo: RegraTipoVeiculo;
  nivelRisco: NivelRisco;
  politica: Politica;
  motivo: string;
  fonte: string;
  atualizadoEm: string;
  status: "ativa" | "inativa";
  bairro?: string;
}

export interface AppSettings {
  ratioAlta: number;
  ratioNormal: number;
  motoBoost: number;
}

export interface AppFilter {
  tipoVeiculo: TipoVeiculo | "todos";
  categoria: string;
}

export interface RegraAplicada {
  id: string;
  nome: string;
  distanciaKm: number;
  nivelRisco: NivelRisco;
  politica: Politica;
  motivo: string;
  fonte: string;
  atualizadoEm: string;
  tipoVeiculo: RegraTipoVeiculo;
  raioKm: number;
}

export interface CidadeMetric {
  cidade: string;
  uf: string;
  chave: string;
  total: number;
  operacionais: number;
  comRastreador: number;
  semRastreador: number;
  cobertura: number;
  canceladosComRastreador: number;
  motos: number;
  carros: number;
  caminhoes: number;
  naoClassificados: number;
  prestadoresAtivos: number;
  prestadoresNecessarios: number;
  deficit: number;
  // Risco = classificação manual da empresa (áreas de risco cadastradas)
  nivelRisco: NivelRisco;
  riscoScore: number; // 0/25/50/75/100
  regraAplicada: RegraAplicada | null;
  politica: Politica | null;
  // Prioridade operacional (instalação, prestadores, recuperação)
  score: number;
  prioridade: "critico" | "alto" | "medio" | "baixo";
  lat: number | null;
  lng: number | null;
}

export const NIVEL_RISCO_SCORE: Record<NivelRisco, number> = {
  sem_classificacao: 0,
  baixo: 25,
  medio: 50,
  alto: 75,
  critico: 100,
};

export const NIVEL_RISCO_LABEL: Record<NivelRisco, string> = {
  sem_classificacao: "Sem classificação",
  baixo: "Baixo",
  medio: "Médio",
  alto: "Alto",
  critico: "Crítico",
};

export const NIVEL_RISCO_COLOR: Record<NivelRisco, string> = {
  sem_classificacao: "#9ca3af",
  baixo: "#16a34a",
  medio: "#eab308",
  alto: "#f97316",
  critico: "#dc2626",
};
