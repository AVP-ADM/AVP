import { useSyncExternalStore } from "react";
import type {
  Associado,
  AppFilter,
  AppSettings,
  ColumnMapping,
  Prestador,
  RegraRisco,
} from "./types";
import { makeSourceKey } from "./prestadores-seed";
import {
  fetchPrestadoresFromSupabase,
  migrateLocalPrestadores,
  subscribePrestadoresRealtime,
} from "./prestadores-api";

export type PrestadoresSource = "supabase" | "cache" | "empty";

interface State {
  associados: Associado[];
  prestadores: Prestador[];
  regras: RegraRisco[];
  mapping: ColumnMapping | null;
  settings: AppSettings;
  filter: AppFilter;
  importadoEm: string | null;
  fonte: string | null;
  prestadoresLoading: boolean;
  prestadoresSource: PrestadoresSource;
  prestadoresError: string | null;
  prestadoresLastFetch: string | null;
}

const LS_KEYS = {
  prestadoresLegacy: "avp.prestadores",              // backup por 1 versão
  prestadoresCache: "avp.prestadores.cache.v2",       // cache de leitura
  prestadoresMigrated: "avp.prestadores.migrated.v1", // flag de migração one-shot
  regras: "avp.regras",
  mapping: "avp.mapping",
  settings: "avp.settings",
  meta: "avp.meta",
};

const DEFAULT_SETTINGS: AppSettings = {
  ratioAlta: 150,
  ratioNormal: 250,
  motoBoost: 1.2,
};

function loadJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

let state: State = {
  associados: [],
  prestadores: [],
  regras: [],
  mapping: null,
  settings: DEFAULT_SETTINGS,
  filter: { tipoVeiculo: "todos", categoria: "" },
  importadoEm: null,
  fonte: null,
  prestadoresLoading: false,
  prestadoresSource: "empty",
  prestadoresError: null,
  prestadoresLastFetch: null,
};

let hydrated = false;
let realtimeUnsub: (() => void) | null = null;

function migrateRegra(raw: any): RegraRisco {
  return {
    id: raw.id ?? Math.random().toString(36).slice(2, 10),
    nome: raw.nome ?? `${raw.cidade ?? ""}/${(raw.uf ?? "").toUpperCase()}`,
    uf: (raw.uf ?? "").toUpperCase(),
    cidade: raw.cidade ?? "",
    latCentral: raw.latCentral ?? null,
    lngCentral: raw.lngCentral ?? null,
    raioKm: raw.raioKm ?? 30,
    tipoVeiculo: raw.tipoVeiculo ?? "todos",
    nivelRisco: raw.nivelRisco ?? "sem_classificacao",
    politica: raw.politica ?? "aceita_normalmente",
    motivo: raw.motivo ?? "",
    fonte: raw.fonte ?? "",
    atualizadoEm: raw.atualizadoEm ?? new Date().toISOString(),
    status: raw.status === "inativa" ? "inativa" : "ativa",
    bairro: raw.bairro,
  };
}

function migratePrestadorCached(raw: any): Prestador {
  return {
    id: raw.id ?? Math.random().toString(36).slice(2, 10),
    nome: raw.nome ?? "",
    cidade: raw.cidade ?? "",
    uf: (raw.uf ?? "").toUpperCase(),
    latitude: raw.latitude ?? null,
    longitude: raw.longitude ?? null,
    tiposAtendidos: Array.isArray(raw.tiposAtendidos) ? raw.tiposAtendidos : [],
    capacidadeMensal:
      raw.capacidadeMensal === null || raw.capacidadeMensal === undefined
        ? null
        : Number(raw.capacidadeMensal),
    raioKm: raw.raioKm ?? 30,
    status: raw.status === "inativo" ? "inativo" : raw.status === "pendente" ? "pendente" : "ativo",
    fonte: raw.fonte,
    sourceKey: raw.sourceKey ?? makeSourceKey(raw.nome ?? "", raw.cidade ?? "", raw.uf ?? ""),
    localizacaoAproximada: raw.localizacaoAproximada,
  };
}

function persistPrestadoresCache(list: Prestador[]) {
  try {
    localStorage.setItem(LS_KEYS.prestadoresCache, JSON.stringify(list));
  } catch { /* ignore */ }
}

// ID fixo da regra pré-cadastrada de Recife (50km, todos os tipos). É
// idempotente: se o usuário editar/remover a regra, não a recriamos.
const DEFAULT_RECIFE_RULE_ID = "seed-recife-50km-v1";
const SEEDED_DEFAULT_REGRAS_KEY = "avp.regras.seeded.v1";

function seedDefaultRegras(current: RegraRisco[]): RegraRisco[] {
  if (typeof window === "undefined") return current;
  if (localStorage.getItem(SEEDED_DEFAULT_REGRAS_KEY) === "1") return current;
  const already = current.some((r) => r.id === DEFAULT_RECIFE_RULE_ID);
  localStorage.setItem(SEEDED_DEFAULT_REGRAS_KEY, "1");
  if (already) return current;
  const regra: RegraRisco = {
    id: DEFAULT_RECIFE_RULE_ID,
    nome: "Recife e Região Metropolitana (50 km)",
    uf: "PE",
    cidade: "Recife",
    latCentral: -8.0476,
    lngCentral: -34.877,
    raioKm: 50,
    tipoVeiculo: "todos",
    nivelRisco: "alto",
    politica: "aceita_somente_com_rastreador",
    motivo: "Área metropolitana de Recife com maior incidência de roubo/furto",
    fonte: "Auto Vale — política interna",
    atualizadoEm: new Date().toISOString(),
    status: "ativa",
  };
  const next = [...current, regra];
  try { localStorage.setItem(LS_KEYS.regras, JSON.stringify(next)); } catch { /* ignore */ }
  return next;
}

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  const rawRegras = loadJSON<any[]>(LS_KEYS.regras, []);
  const rawCache = loadJSON<any[]>(LS_KEYS.prestadoresCache, []);
  const cache = Array.isArray(rawCache) ? rawCache.map(migratePrestadorCached) : [];
  const regras = Array.isArray(rawRegras) ? rawRegras.map(migrateRegra) : [];
  state = {
    ...state,
    prestadores: cache,
    prestadoresSource: cache.length ? "cache" : "empty",
    regras: seedDefaultRegras(regras),
    mapping: loadJSON(LS_KEYS.mapping, null),
    settings: loadJSON(LS_KEYS.settings, DEFAULT_SETTINGS),
    ...loadJSON(LS_KEYS.meta, { importadoEm: null, fonte: null }),
  };
  notify();
  // Fetch da fonte oficial (Supabase) em background
  void refreshPrestadoresFromSupabase();
  // Realtime
  startPrestadoresRealtime();
}


const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

export function subscribe(fn: () => void): () => void {
  hydrate();
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function getSnapshot(): State {
  return state;
}

function getServerSnapshot(): State {
  return state;
}

export function useStore(): State {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

// ---------- Prestadores (Supabase) ----------

export async function refreshPrestadoresFromSupabase(): Promise<void> {
  state = { ...state, prestadoresLoading: true, prestadoresError: null };
  notify();
  try {
    const list = await fetchPrestadoresFromSupabase();
    state = {
      ...state,
      prestadores: list,
      prestadoresLoading: false,
      prestadoresSource: "supabase",
      prestadoresError: null,
      prestadoresLastFetch: new Date().toISOString(),
    };
    persistPrestadoresCache(list);
    notify();
  } catch (e) {
    // Falha na leitura: manter cache atual. Não apagar dados existentes.
    state = {
      ...state,
      prestadoresLoading: false,
      prestadoresError: (e as Error).message ?? "Falha ao carregar prestadores",
      prestadoresSource: state.prestadores.length ? "cache" : "empty",
    };
    notify();
  }
}

function startPrestadoresRealtime() {
  if (realtimeUnsub || typeof window === "undefined") return;
  try {
    realtimeUnsub = subscribePrestadoresRealtime(() => {
      void refreshPrestadoresFromSupabase();
    });
  } catch { /* realtime é opcional */ }
}

// Migração one-shot: envia registros locais ainda inexistentes no Supabase.
export interface LocalMigrationResult {
  inserted: number;
  skipped: number;
  candidates: number;
  alreadyMigrated: boolean;
}

export async function migrateLegacyPrestadoresIfNeeded(
  adminCode: string,
): Promise<LocalMigrationResult> {
  if (typeof window === "undefined") return { inserted: 0, skipped: 0, candidates: 0, alreadyMigrated: true };
  const done = localStorage.getItem(LS_KEYS.prestadoresMigrated);
  if (done === "1") return { inserted: 0, skipped: 0, candidates: 0, alreadyMigrated: true };
  const legacy = loadJSON<any[]>(LS_KEYS.prestadoresLegacy, []);
  const local = Array.isArray(legacy) ? legacy.map(migratePrestadorCached) : [];
  if (!local.length) {
    localStorage.setItem(LS_KEYS.prestadoresMigrated, "1");
    return { inserted: 0, skipped: 0, candidates: 0, alreadyMigrated: false };
  }
  // Puxa lista remota atualizada para deduplicar
  const remote = await fetchPrestadoresFromSupabase();
  const remoteKeys = new Set(remote.map((r) => r.sourceKey ?? makeSourceKey(r.nome, r.cidade, r.uf)));
  const candidates = local.filter((p) => {
    const key = p.sourceKey ?? makeSourceKey(p.nome, p.cidade, p.uf);
    return !remoteKeys.has(key);
  });
  const res = await migrateLocalPrestadores(adminCode, candidates);
  localStorage.setItem(LS_KEYS.prestadoresMigrated, "1");
  await refreshPrestadoresFromSupabase();
  return { inserted: res.inserted, skipped: res.skipped, candidates: candidates.length, alreadyMigrated: false };
}

export function hasPendingLegacyMigration(): boolean {
  if (typeof window === "undefined") return false;
  if (localStorage.getItem(LS_KEYS.prestadoresMigrated) === "1") return false;
  const legacy = loadJSON<any[]>(LS_KEYS.prestadoresLegacy, []);
  return Array.isArray(legacy) && legacy.length > 0;
}

// Atualização otimista/local após uma mutação server-side.
export function applyRemotePrestador(p: Prestador) {
  const idx = state.prestadores.findIndex((x) => x.id === p.id);
  const prestadores = idx >= 0
    ? state.prestadores.map((x) => (x.id === p.id ? p : x))
    : [...state.prestadores, p];
  state = { ...state, prestadores };
  persistPrestadoresCache(prestadores);
  notify();
}

export function removePrestadorLocal(id: string) {
  const prestadores = state.prestadores.filter((p) => p.id !== id);
  state = { ...state, prestadores };
  persistPrestadoresCache(prestadores);
  notify();
}

// ---------- Associados / regras / config ----------

export function setAssociados(
  associados: Associado[],
  mapping: ColumnMapping | null,
  fonte: string,
) {
  state = {
    ...state,
    associados,
    mapping: mapping ?? state.mapping,
    importadoEm: new Date().toISOString(),
    fonte,
  };
  try {
    if (mapping) localStorage.setItem(LS_KEYS.mapping, JSON.stringify(mapping));
    localStorage.setItem(
      LS_KEYS.meta,
      JSON.stringify({ importadoEm: state.importadoEm, fonte }),
    );
  } catch { /* ignore */ }
  notify();
}

export function clearAssociados() {
  state = { ...state, associados: [], importadoEm: null, fonte: null };
  notify();
}

export function upsertRegra(r: RegraRisco) {
  const idx = state.regras.findIndex((x) => x.id === r.id);
  const regras =
    idx >= 0
      ? state.regras.map((x) => (x.id === r.id ? r : x))
      : [...state.regras, r];
  state = { ...state, regras };
  localStorage.setItem(LS_KEYS.regras, JSON.stringify(regras));
  notify();
}

export function removeRegra(id: string) {
  const regras = state.regras.filter((r) => r.id !== id);
  state = { ...state, regras };
  localStorage.setItem(LS_KEYS.regras, JSON.stringify(regras));
  notify();
}

export function setRegras(list: RegraRisco[]) {
  state = { ...state, regras: list };
  localStorage.setItem(LS_KEYS.regras, JSON.stringify(list));
  notify();
}

export function updateSettings(patch: Partial<AppSettings>) {
  const settings = { ...state.settings, ...patch };
  state = { ...state, settings };
  localStorage.setItem(LS_KEYS.settings, JSON.stringify(settings));
  notify();
}

export function setFilter(patch: Partial<AppFilter>) {
  const filter = { ...state.filter, ...patch };
  if (patch.tipoVeiculo !== undefined && patch.categoria === undefined) {
    filter.categoria = "";
  }
  state = { ...state, filter };
  notify();
}
