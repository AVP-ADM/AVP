import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { Activity, MapPin, PackageX, RotateCcw, Bike, AlertTriangle, Users, ShieldCheck } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { EmptyState, KpiCard } from "@/components/KpiCard";
import { useStore } from "@/lib/store";
import { applyFilter, computeCities, computeGlobal } from "@/lib/calc";
import { fmtInt, fmtPct } from "@/lib/format";

export const Route = createFileRoute("/")({
  component: Index,
});

const COLORS = ["#3b6ef5", "#f59e0b", "#10b981", "#ef4444", "#a855f7"];
const PRI_COLORS: Record<string, string> = {
  critico: "#dc2626",
  alto: "#f59e0b",
  medio: "#eab308",
  baixo: "#10b981",
};

function Index() {
  const { associados, prestadores, regras, settings, filter } = useStore();

  const baseFiltrada = useMemo(
    () => applyFilter(associados, filter),
    [associados, filter]
  );
  const global = useMemo(() => computeGlobal(baseFiltrada), [baseFiltrada]);
  const cities = useMemo(
    () => computeCities(baseFiltrada, prestadores, regras, settings),
    [baseFiltrada, prestadores, regras, settings]
  );

  if (!associados.length) {
    return (
      <AppLayout>
        <EmptyState
          title="Importe a base de associados para começar"
          description="Suporta .xlsx, .xls e .csv. Nenhum dado é enviado a servidor — tudo processado localmente no navegador."
        />
      </AppLayout>
    );
  }

  const topOperacionais = [...cities].sort((a, b) => b.operacionais - a.operacionais).slice(0, 15);
  const topSemRastreador = [...cities].sort((a, b) => b.semRastreador - a.semRastreador).slice(0, 15);
  const canceladosCidade = [...cities].sort((a, b) => b.canceladosComRastreador - a.canceladosComRastreador).slice(0, 15).filter(c => c.canceladosComRastreador > 0);

  const porEstado = new Map<string, { uf: string; oper: number; comRast: number }>();
  for (const a of baseFiltrada) {
    if (!a.operacional) continue;
    const uf = a.estado || "??";
    const e = porEstado.get(uf) || { uf, oper: 0, comRast: 0 };
    e.oper++;
    if (a.temRastreador) e.comRast++;
    porEstado.set(uf, e);
  }
  const estados = Array.from(porEstado.values())
    .map((e) => ({ ...e, cobertura: e.oper ? (e.comRast / e.oper) * 100 : 0 }))
    .sort((a, b) => b.oper - a.oper);

  const cidadesCriticas = cities.filter((c) => c.prioridade === "critico" || c.prioridade === "alto").length;
  const prestadoresNecess = cities.reduce((s, c) => s + c.prestadoresNecessarios, 0);
  const prestadoresAtiv = prestadores.filter((p) => p.status === "ativo").length;

  const distTipos = [
    { name: "Carro", value: global.carros },
    { name: "Moto", value: global.motos },
    { name: "Caminhão", value: global.caminhoes },
    { name: "Não classificado", value: global.naoClassificados },
  ];

  const distPri = ["critico", "alto", "medio", "baixo"].map((p) => ({
    name: p,
    value: cities.filter((c) => c.prioridade === p).length,
  }));

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Visão Executiva</h1>
          <p className="text-sm text-muted-foreground">
            Decisão rápida sobre rastreamento, prestadores e política de aceitação.
          </p>
        </div>

        <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <KpiCard label="Operacionais" value={fmtInt(global.operacionais)} tone="info" icon={<Activity className="h-4 w-4" />} hint="Ativo + Suspenso" />
          <KpiCard label="Com rastreador" value={fmtInt(global.comRastreador)} tone="success" icon={<ShieldCheck className="h-4 w-4" />} />
          <KpiCard label="Sem rastreador" value={fmtInt(global.semRastreador)} tone="warning" icon={<PackageX className="h-4 w-4" />} hint="Demanda de instalação" />
          <KpiCard label="Cobertura" value={fmtPct(global.cobertura)} tone={global.cobertura < 0.2 ? "danger" : "info"} />
          <KpiCard label="Cancelados c/ rastreador" value={fmtInt(global.canceladosComRastreador)} tone="danger" icon={<RotateCcw className="h-4 w-4" />} hint="Fila de recuperação" />
          <KpiCard label="Motos operacionais" value={fmtInt(global.motos)} icon={<Bike className="h-4 w-4" />} />
          <KpiCard label="Cidades críticas" value={fmtInt(cidadesCriticas)} tone="danger" icon={<AlertTriangle className="h-4 w-4" />} hint="Prioridade Alta+Crítica" />
          <KpiCard label="Prestadores necessários" value={fmtInt(prestadoresNecess)} tone="info" icon={<Users className="h-4 w-4" />} hint={`${fmtInt(prestadoresAtiv)} ativos`} />
        </section>

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-lg bg-card p-4">
            <h2 className="text-sm font-semibold mb-3 flex items-center gap-2"><MapPin className="h-4 w-4" /> Cobertura por estado</h2>
            <div style={{ height: 320 }}>
              <ResponsiveContainer>
                <BarChart data={estados.slice(0, 15)} layout="vertical" margin={{ left: 8, right: 20 }}>
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="uf" width={30} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: any, k: any) => k === "cobertura" ? `${v.toFixed(1)}%` : fmtInt(v)} />
                  <Bar dataKey="oper" fill="#3b6ef5" name="Operacionais" />
                  <Bar dataKey="comRast" fill="#10b981" name="Com rastreador" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-lg bg-card p-4">
            <h2 className="text-sm font-semibold mb-3">Distribuição por tipo de veículo</h2>
            <div style={{ height: 320 }}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={distTipos} dataKey="value" nameKey="name" outerRadius={110} label={(e) => `${e.name}: ${fmtInt(e.value as number)}`}>
                    {distTipos.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-lg bg-card p-4 lg:col-span-2">
            <h2 className="text-sm font-semibold mb-3">Top 15 cidades por associados operacionais</h2>
            <div style={{ height: 380 }}>
              <ResponsiveContainer>
                <BarChart data={topOperacionais} layout="vertical" margin={{ left: 8, right: 20 }}>
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="cidade" width={160} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: any) => fmtInt(v)} />
                  <Bar dataKey="operacionais" name="Operacionais" fill="#3b6ef5" />
                  <Bar dataKey="semRastreador" name="Sem rastreador" fill="#f59e0b" />
                  <Bar dataKey="comRastreador" name="Com rastreador" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-lg bg-card p-4">
            <h2 className="text-sm font-semibold mb-3">Top 15 cidades sem rastreador</h2>
            <div style={{ height: 380 }}>
              <ResponsiveContainer>
                <BarChart data={topSemRastreador} layout="vertical" margin={{ left: 8, right: 20 }}>
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="cidade" width={160} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: any) => fmtInt(v)} />
                  <Bar dataKey="semRastreador" fill="#f59e0b" name="Sem rastreador" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-lg bg-card p-4">
            <h2 className="text-sm font-semibold mb-3">Cancelados com rastreador (recuperação)</h2>
            {canceladosCidade.length === 0 ? (
              <div className="text-sm text-muted-foreground py-10 text-center">Sem cancelados com rastreador informado.</div>
            ) : (
              <div style={{ height: 380 }}>
                <ResponsiveContainer>
                  <BarChart data={canceladosCidade} layout="vertical" margin={{ left: 8, right: 20 }}>
                    <XAxis type="number" tick={{ fontSize: 11 }} />
                    <YAxis type="category" dataKey="cidade" width={160} tick={{ fontSize: 11 }} />
                    <Tooltip formatter={(v: any) => fmtInt(v)} />
                    <Bar dataKey="canceladosComRastreador" fill="#dc2626" name="Recuperação" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          <div className="rounded-lg bg-card p-4 lg:col-span-2">
            <h2 className="text-sm font-semibold mb-3">Cidades por nível de prioridade</h2>
            <div className="flex items-center gap-4">
              {distPri.map((p) => (
                <div key={p.name} className="flex-1 rounded-md border border-border p-3 text-center">
                  <div className="text-xs uppercase text-muted-foreground">{p.name}</div>
                  <div className="text-2xl font-bold" style={{ color: PRI_COLORS[p.name] }}>
                    {fmtInt(p.value)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </AppLayout>
  );
}
