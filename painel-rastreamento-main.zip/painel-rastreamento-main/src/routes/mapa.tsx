import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { AppLayout } from "@/components/AppLayout";
import { EmptyState } from "@/components/KpiCard";
import { useStore } from "@/lib/store";

const MapView = lazy(() => import("@/components/MapView").then((m) => ({ default: m.MapView })));

export const Route = createFileRoute("/mapa")({
  component: Page,
});

function Page() {
  const { associados } = useStore();
  return (
    <AppLayout>
      {!associados.length ? (
        <EmptyState title="Sem base carregada" description="Importe a planilha para ver o mapa de decisão." />
      ) : (
        <Suspense fallback={<div className="text-sm text-muted-foreground">Carregando mapa…</div>}>
          <MapView />
        </Suspense>
      )}
    </AppLayout>
  );
}
