import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download, Loader2, Power, PowerOff, Plus, RefreshCw, Trash2, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { AppLayout } from "@/components/AppLayout";
import {
  useStore,
  updateSettings,
  refreshPrestadoresFromSupabase,
  applyRemotePrestador,
  removePrestadorLocal,
  migrateLegacyPrestadoresIfNeeded,
  hasPendingLegacyMigration,
} from "@/lib/store";
import { applyFilter, computeCities } from "@/lib/calc";
import { downloadCSV } from "@/lib/export-csv";
import { fmtInt } from "@/lib/format";
import {
  activatePrestadorRemote,
  createPrestadorRemote,
  deactivatePrestadorRemote,
  deletePrestadorRemote,
  PrestadoresApiError,
} from "@/lib/prestadores-api";
import type { Prestador, TipoVeiculo } from "@/lib/types";

export const Route = createFileRoute("/prestadores")({
  component: Page,
});

const uid = () => Math.random().toString(36).slice(2, 10);

type PendingAction =
  | { kind: "create"; provider: Prestador }
  | { kind: "activate"; id: string; nome: string }
  | { kind: "deactivate"; id: string; nome: string }
  | { kind: "delete"; id: string; nome: string }
  | { kind: "migrate" }
  | { kind: "import"; providers: Prestador[] };

function Page() {
  const {
    associados,
    prestadores,
    regras,
    settings,
    filter,
    prestadoresLoading,
    prestadoresSource,
    prestadoresError,
  } = useStore();
  const baseFiltrada = useMemo(() => applyFilter(associados, filter), [associados, filter]);
  const cities = useMemo(
    () => computeCities(baseFiltrada, prestadores, regras, settings),
    [baseFiltrada, prestadores, regras, settings]
  );

  const [form, setForm] = useState<Prestador>({
    id: "", nome: "", cidade: "", uf: "", latitude: null, longitude: null,
    tiposAtendidos: [], capacidadeMensal: null, raioKm: 30, status: "ativo",
  });
  const [pending, setPending] = useState<PendingAction | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [adminCode, setAdminCode] = useState("");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const totalNecess = cities.reduce((s, c) => s + c.prestadoresNecessarios, 0);
  const totalAtivos = prestadores.filter((p) => p.status === "ativo").length;
  const deficit = cities.reduce((s, c) => s + c.deficit, 0);
  const legacyPending = typeof window !== "undefined" && hasPendingLegacyMigration();

  const executePending = async () => {
    if (!pending) return;
    setDialogError(null);
    setBusy("dialog");
    try {
      if (pending.kind === "create") {
        const created = await createPrestadorRemote({ adminCode, provider: pending.provider });
        applyRemotePrestador(created);
        setForm({ id: "", nome: "", cidade: "", uf: "", latitude: null, longitude: null, tiposAtendidos: [], capacidadeMensal: null, raioKm: 30, status: "ativo" });
        setNotice("Prestador criado com sucesso.");
      } else if (pending.kind === "activate") {
        const updated = await activatePrestadorRemote(adminCode, pending.id);
        applyRemotePrestador(updated);
        setNotice(`${pending.nome} ativado.`);
      } else if (pending.kind === "deactivate") {
        const updated = await deactivatePrestadorRemote(adminCode, pending.id);
        applyRemotePrestador(updated);
        setNotice(`${pending.nome} inativado.`);
      } else if (pending.kind === "delete") {
        await deletePrestadorRemote(adminCode, pending.id);
        removePrestadorLocal(pending.id);
        setNotice(`${pending.nome} excluído.`);
      } else if (pending.kind === "migrate") {
        const res = await migrateLegacyPrestadoresIfNeeded(adminCode);
        setNotice(`Migração concluída: ${res.inserted} inseridos, ${res.skipped} ignorados (${res.candidates} candidatos).`);
      } else if (pending.kind === "import") {
        let ok = 0;
        for (const p of pending.providers) {
          try {
            const created = await createPrestadorRemote({ adminCode, provider: p });
            applyRemotePrestador(created);
            ok++;
          } catch (e) {
            if (e instanceof PrestadoresApiError && e.code === "duplicate") continue;
            throw e;
          }
        }
        setNotice(`Importação: ${ok} novos prestadores criados.`);
      }
      setPending(null);
      setAdminCode("");
      void refreshPrestadoresFromSupabase();
    } catch (e) {
      if (e instanceof PrestadoresApiError) {
        setDialogError(`${e.message}${e.blockedUntilMs ? ` (bloqueado até ${new Date(e.blockedUntilMs).toLocaleTimeString()})` : ""}`);
      } else {
        setDialogError((e as Error).message ?? "Falha inesperada");
      }
    } finally {
      setBusy(null);
    }
  };

  const handleImport = async (file: File) => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const ws = wb.Sheets[wb.SheetNames[0]!]!;
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(ws);
    const list: Prestador[] = rows.map((r) => ({
      id: uid(),
      nome: String(r.nome || r.Nome || ""),
      cidade: String(r.cidade || r.Cidade || ""),
      uf: String(r.uf || r.UF || "").toUpperCase(),
      latitude: r.latitude != null ? parseFloat(String(r.latitude)) : null,
      longitude: r.longitude != null ? parseFloat(String(r.longitude)) : null,
      tiposAtendidos: String(r.tipos || r.tiposAtendidos || "")
        .split(/[|,;]/).map((s) => s.trim().toLowerCase())
        .filter((s): s is TipoVeiculo => ["moto", "carro", "caminhao"].includes(s)),
      capacidadeMensal: (r.capacidade ?? r.capacidadeMensal) != null && String(r.capacidade ?? r.capacidadeMensal) !== ""
        ? (parseInt(String(r.capacidade ?? r.capacidadeMensal)) || null)
        : null,
      raioKm: parseInt(String(r.raio || r.raioKm || "30")) || 30,
      status: (String(r.status || "ativo").toLowerCase() as any) || "ativo",
    })).filter((p) => p.nome && p.cidade && p.uf);
    if (!list.length) return;
    setPending({ kind: "import", providers: list });
  };

  const exportModelo = () => {
    downloadCSV("prestadores_modelo.csv", [
      { nome: "Oficina Exemplo", cidade: "Petrolina", uf: "PE", latitude: -9.3891, longitude: -40.5027, tipos: "moto|carro", capacidade: 80, raio: 40, status: "ativo" },
    ]);
  };

  const submit = () => {
    if (!form.nome || !form.cidade || !form.uf) return;
    setPending({ kind: "create", provider: { ...form, id: "", uf: form.uf.toUpperCase() } });
  };

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold">Prestadores</h1>
            <p className="text-sm text-muted-foreground">
              Fonte oficial: Supabase. LocalStorage é usado apenas como cache de leitura.
            </p>
            <div className="mt-1 text-xs flex items-center gap-2">
              {prestadoresLoading && <span className="inline-flex items-center gap-1 text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin" /> Carregando…</span>}
              {!prestadoresLoading && prestadoresSource === "supabase" && <span className="text-green-600">● Dados oficiais (Supabase)</span>}
              {!prestadoresLoading && prestadoresSource === "cache" && <span className="text-amber-600">● Cache local (Supabase indisponível)</span>}
              {!prestadoresLoading && prestadoresSource === "empty" && <span className="text-muted-foreground">Sem dados</span>}
              {prestadoresError && <span className="text-destructive">— {prestadoresError}</span>}
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => void refreshPrestadoresFromSupabase()}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${prestadoresLoading ? "animate-spin" : ""}`} /> Recarregar
            </button>
            <label className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs cursor-pointer hover:bg-muted">
              <Upload className="h-3.5 w-3.5" /> Importar CSV/XLSX
              <input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => e.target.files && handleImport(e.target.files[0]!)} />
            </label>
            <button onClick={exportModelo} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted">
              <Download className="h-3.5 w-3.5" /> Modelo CSV
            </button>
          </div>
        </div>

        {legacyPending && (
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs flex items-center justify-between">
            <div>
              <div className="font-semibold text-amber-800">Migração pendente</div>
              <div className="text-amber-700">Existem prestadores cadastrados neste dispositivo em versão anterior. Envie para o Supabase.</div>
            </div>
            <button onClick={() => setPending({ kind: "migrate" })} className="rounded-md bg-amber-600 px-3 py-1.5 text-white hover:opacity-90">
              Migrar agora
            </button>
          </div>
        )}

        {notice && (
          <div className="rounded-md border border-green-500/40 bg-green-500/10 p-2 text-xs text-green-800 flex items-center justify-between">
            <span>{notice}</span>
            <button onClick={() => setNotice(null)} className="text-green-700">×</button>
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="Prestadores cadastrados" value={fmtInt(prestadores.length)} />
          <Stat label="Ativos" value={fmtInt(totalAtivos)} />
          <Stat label="Necessários (estimado)" value={fmtInt(totalNecess)} />
          <Stat label="Déficit total" value={fmtInt(deficit)} />
        </div>

        <div className="rounded-lg bg-card p-4">
          <h2 className="text-sm font-semibold mb-3">Parâmetros de cálculo</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <label>
              <div className="text-muted-foreground">Sem rastreador por prestador (alta prioridade)</div>
              <input type="number" min={1} value={settings.ratioAlta} onChange={(e) => updateSettings({ ratioAlta: parseInt(e.target.value) || 150 })} className="w-full rounded border border-input bg-background px-2 py-1.5" />
            </label>
            <label>
              <div className="text-muted-foreground">Sem rastreador por prestador (normal)</div>
              <input type="number" min={1} value={settings.ratioNormal} onChange={(e) => updateSettings({ ratioNormal: parseInt(e.target.value) || 250 })} className="w-full rounded border border-input bg-background px-2 py-1.5" />
            </label>
            <label>
              <div className="text-muted-foreground">Multiplicador moto ({">"} 50%)</div>
              <input type="number" step="0.05" value={settings.motoBoost} onChange={(e) => updateSettings({ motoBoost: parseFloat(e.target.value) || 1 })} className="w-full rounded border border-input bg-background px-2 py-1.5" />
            </label>
          </div>
        </div>

        <div className="rounded-lg bg-card p-4">
          <h2 className="text-sm font-semibold mb-3">Novo prestador</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <Field label="Nome"><input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="input" /></Field>
            <Field label="Cidade"><input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} className="input" /></Field>
            <Field label="UF"><input maxLength={2} value={form.uf} onChange={(e) => setForm({ ...form, uf: e.target.value })} className="input" /></Field>
            <Field label="Status">
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="input">
                <option value="ativo">Ativo</option>
                <option value="pendente">Pendente</option>
                <option value="inativo">Inativo</option>
              </select>
            </Field>
            <Field label="Latitude"><input type="number" step="0.0001" value={form.latitude ?? ""} onChange={(e) => setForm({ ...form, latitude: e.target.value ? parseFloat(e.target.value) : null })} className="input" /></Field>
            <Field label="Longitude"><input type="number" step="0.0001" value={form.longitude ?? ""} onChange={(e) => setForm({ ...form, longitude: e.target.value ? parseFloat(e.target.value) : null })} className="input" /></Field>
            <Field label="Capacidade/mês (opcional)"><input type="number" value={form.capacidadeMensal ?? ""} onChange={(e) => setForm({ ...form, capacidadeMensal: e.target.value === "" ? null : (parseInt(e.target.value) || 0) })} className="input" placeholder="Não informado" /></Field>
            <Field label="Raio (km)"><input type="number" value={form.raioKm} onChange={(e) => setForm({ ...form, raioKm: parseInt(e.target.value) || 0 })} className="input" /></Field>
            <Field label="Tipos atendidos (Ctrl+clique)">
              <select multiple value={form.tiposAtendidos} onChange={(e) => setForm({ ...form, tiposAtendidos: Array.from(e.target.selectedOptions).map((o) => o.value as TipoVeiculo) })} className="input h-20">
                <option value="moto">Moto</option>
                <option value="carro">Carro</option>
                <option value="caminhao">Caminhão</option>
              </select>
            </Field>
          </div>
          <button onClick={submit} className="mt-3 inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> Adicionar prestador
          </button>
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm">Cadastro ({prestadores.length})</div>
          <div className="overflow-auto max-h-[400px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr className="text-left">
                {["Nome", "Cidade/UF", "Tipos", "Cap.", "Raio", "Status", ""].map((h) => (<th key={h} className="px-3 py-2 font-medium">{h}</th>))}
              </tr></thead>
              <tbody>
                {prestadores.map((p) => (
                  <tr key={p.id} className="border-t border-border">
                    <td className="px-3 py-1.5">{p.nome}</td>
                    <td className="px-3 py-1.5">{p.cidade}/{p.uf}</td>
                    <td className="px-3 py-1.5">{p.tiposAtendidos.length ? p.tiposAtendidos.join(", ") : <span className="text-muted-foreground">Não informado</span>}</td>
                    <td className="px-3 py-1.5 tabular-nums">{p.capacidadeMensal == null ? <span className="text-muted-foreground">Não informado</span> : p.capacidadeMensal}</td>
                    <td className="px-3 py-1.5 tabular-nums">{p.raioKm} km</td>
                    <td className="px-3 py-1.5">{p.status}</td>
                    <td className="px-3 py-1.5">
                      <div className="flex gap-1.5">
                        {p.status === "ativo" ? (
                          <button title="Inativar" onClick={() => setPending({ kind: "deactivate", id: p.id, nome: p.nome })} className="text-amber-600 hover:opacity-80">
                            <PowerOff className="h-3.5 w-3.5" />
                          </button>
                        ) : (
                          <button title="Ativar" onClick={() => setPending({ kind: "activate", id: p.id, nome: p.nome })} className="text-green-600 hover:opacity-80">
                            <Power className="h-3.5 w-3.5" />
                          </button>
                        )}
                        <button title="Excluir" onClick={() => setPending({ kind: "delete", id: p.id, nome: p.nome })} className="text-destructive hover:opacity-80">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!prestadores.length && (<tr><td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">Nenhum prestador cadastrado.</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm">Déficit por cidade (top 30)</div>
          <div className="overflow-auto max-h-[400px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr className="text-left">
                {["Cidade/UF", "Sem rast.", "Recuperação", "Prest. ativos", "Necessários", "Déficit", "Prioridade"].map((h) => (<th key={h} className="px-3 py-2 font-medium">{h}</th>))}
              </tr></thead>
              <tbody>
                {[...cities].sort((a, b) => b.deficit - a.deficit).slice(0, 30).map((c) => (
                  <tr key={c.chave} className="border-t border-border">
                    <td className="px-3 py-1.5 font-medium">{c.cidade}/{c.uf}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.semRastreador)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.canceladosComRastreador)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.prestadoresAtivos)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.prestadoresNecessarios)}</td>
                    <td className="px-3 py-1.5 tabular-nums font-semibold text-destructive">{fmtInt(c.deficit)}</td>
                    <td className="px-3 py-1.5">{c.prioridade}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {pending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => !busy && setPending(null)}>
          <div className="w-full max-w-sm rounded-lg bg-background border border-border p-4 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold mb-1">Confirmação administrativa</div>
            <div className="text-xs text-muted-foreground mb-3">
              {pending.kind === "create" && `Criar prestador "${pending.provider.nome}"?`}
              {pending.kind === "activate" && `Ativar "${pending.nome}"?`}
              {pending.kind === "deactivate" && `Inativar "${pending.nome}"?`}
              {pending.kind === "delete" && `Excluir "${pending.nome}"? Esta ação não pode ser desfeita.`}
              {pending.kind === "migrate" && `Enviar prestadores locais deste dispositivo para o Supabase.`}
              {pending.kind === "import" && `Importar ${pending.providers.length} prestadores para o Supabase.`}
            </div>
            <label className="block text-xs mb-1 text-muted-foreground">Código administrativo</label>
            <input
              type="password"
              autoFocus
              value={adminCode}
              onChange={(e) => setAdminCode(e.target.value)}
              className="w-full rounded border border-input bg-background px-2 py-1.5 text-sm"
              placeholder="Digite o código"
              onKeyDown={(e) => { if (e.key === "Enter" && !busy) void executePending(); }}
            />
            {dialogError && <div className="mt-2 text-xs text-destructive">{dialogError}</div>}
            <div className="mt-3 flex justify-end gap-2">
              <button
                disabled={!!busy}
                onClick={() => { setPending(null); setAdminCode(""); setDialogError(null); }}
                className="rounded-md border border-border px-3 py-1.5 text-xs hover:bg-muted disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                disabled={!adminCode || !!busy}
                onClick={() => void executePending()}
                className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground hover:opacity-90 disabled:opacity-50"
              >
                {busy && <Loader2 className="h-3 w-3 animate-spin" />} Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`.input{width:100%;border:1px solid var(--input);background:var(--background);border-radius:6px;padding:6px 8px;font-size:12px}`}</style>
    </AppLayout>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="space-y-1"><div className="text-muted-foreground">{label}</div>{children}</label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-card border border-border p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-xl font-semibold tabular-nums">{value}</div>
    </div>
  );
}
