import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { EmptyState } from "@/components/KpiCard";
import { useStore } from "@/lib/store";
import { applyFilter, computeCities } from "@/lib/calc";
import { fmtInt, fmtPct } from "@/lib/format";
import { downloadCSV } from "@/lib/export-csv";

export const Route = createFileRoute("/rastreamento")({
  component: Page,
});

function Page() {
  const { associados, prestadores, regras, settings, filter } = useStore();
  const [situacao, setSituacao] = useState<"todos" | "ativo" | "suspenso" | "cancelado">("todos");
  const [uf, setUf] = useState("");
  const [cidade, setCidade] = useState("");
  const [consultor, setConsultor] = useState("");
  const [plano, setPlano] = useState("");
  const [fipeMin, setFipeMin] = useState("");
  const [fipeMax, setFipeMax] = useState("");

  const baseFiltrada = useMemo(() => applyFilter(associados, filter), [associados, filter]);

  const cities = useMemo(
    () => computeCities(baseFiltrada, prestadores, regras, settings),
    [baseFiltrada, prestadores, regras, settings]
  );

  const ufs = useMemo(() => Array.from(new Set(baseFiltrada.map((a) => a.estado).filter(Boolean))).sort(), [baseFiltrada]);
  const consultores = useMemo(() => Array.from(new Set(baseFiltrada.map((a) => a.consultor).filter(Boolean))).sort(), [baseFiltrada]);
  const planos = useMemo(() => Array.from(new Set(baseFiltrada.map((a) => a.plano).filter(Boolean))).sort(), [baseFiltrada]);

  const filtered = useMemo(() => {
    const min = fipeMin ? parseFloat(fipeMin) : null;
    const max = fipeMax ? parseFloat(fipeMax) : null;
    return baseFiltrada.filter((a) => {
      if (situacao !== "todos" && a.situacao !== situacao) return false;
      if (uf && a.estado !== uf) return false;
      if (cidade && !a.cidade.toLowerCase().includes(cidade.toLowerCase())) return false;
      if (consultor && a.consultor !== consultor) return false;
      if (plano && a.plano !== plano) return false;
      if (min != null && (a.valorFipe ?? 0) < min) return false;
      if (max != null && (a.valorFipe ?? 0) > max) return false;
      return true;
    });
  }, [baseFiltrada, situacao, uf, cidade, consultor, plano, fipeMin, fipeMax]);

  const oper = filtered.filter((a) => a.operacional);
  const comRast = oper.filter((a) => a.temRastreador).length;
  const semRast = oper.length - comRast;
  const canRast = filtered.filter((a) => a.situacao === "cancelado" && a.temRastreador).length;

  const prioridade = [...cities].sort((a, b) => b.score - a.score);

  const exportInst = () => {
    downloadCSV(
      "lista_instalacao.csv",
      oper
        .filter((a) => !a.temRastreador)
        .map((a) => ({
          associado: a.associado,
          placa: a.placa,
          cidade: a.cidade,
          uf: a.estado,
          tipo: a.tipo,
          categoria: a.categoriaOriginal,
          plano: a.plano,
          consultor: a.consultor,
          situacao: a.situacao,
          valor_fipe: a.valorFipe ?? "",
        }))
    );
  };

  const exportPrio = () => {
    downloadCSV(
      "cidades_prioritarias.csv",
      prioridade.slice(0, 200).map((c) => ({
        cidade: c.cidade,
        uf: c.uf,
        operacionais: c.operacionais,
        sem_rastreador: c.semRastreador,
        cancelados_com_rastreador: c.canceladosComRastreador,
        cobertura: c.cobertura.toFixed(3),
        motos: c.motos,
        carros: c.carros,
        caminhoes: c.caminhoes,
        prestadores_ativos: c.prestadoresAtivos,
        prestadores_necessarios: c.prestadoresNecessarios,
        deficit: c.deficit,
        nivel_risco: c.nivelRisco,
        politica: c.politica ?? "",
        score: c.score,
        prioridade: c.prioridade,
      }))
    );
  };

  if (!associados.length) {
    return (
      <AppLayout>
        <EmptyState title="Sem base carregada" description="Importe a planilha para ver rastreamento." />
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold">Rastreamento</h1>
            <p className="text-sm text-muted-foreground">
              Ativo e Suspenso = base operacional. Cancelado com rastreador = fila de recuperação.
            </p>
          </div>
          <div className="flex gap-2">
            <button onClick={exportInst} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted">
              <Download className="h-3.5 w-3.5" /> Lista de instalação
            </button>
            <button onClick={exportPrio} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90">
              <Download className="h-3.5 w-3.5" /> Cidades prioritárias
            </button>
          </div>
        </div>

        <div className="rounded-lg bg-card p-4 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
          <label>
            <div className="text-muted-foreground">Situação</div>
            <select value={situacao} onChange={(e) => setSituacao(e.target.value as any)} className="w-full rounded border border-input bg-background px-2 py-1.5">
              <option value="todos">Todos</option>
              <option value="ativo">Ativo</option>
              <option value="suspenso">Suspenso</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </label>
          <label>
            <div className="text-muted-foreground">UF</div>
            <select value={uf} onChange={(e) => setUf(e.target.value)} className="w-full rounded border border-input bg-background px-2 py-1.5">
              <option value="">Todos</option>
              {ufs.map((u) => <option key={u} value={u}>{u}</option>)}
            </select>
          </label>
          <label>
            <div className="text-muted-foreground">Cidade</div>
            <input value={cidade} onChange={(e) => setCidade(e.target.value)} className="w-full rounded border border-input bg-background px-2 py-1.5" placeholder="contém…" />
          </label>
          <label>
            <div className="text-muted-foreground">Consultor</div>
            <select value={consultor} onChange={(e) => setConsultor(e.target.value)} className="w-full rounded border border-input bg-background px-2 py-1.5">
              <option value="">Todos</option>
              {consultores.slice(0, 500).map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label>
            <div className="text-muted-foreground">Plano</div>
            <select value={plano} onChange={(e) => setPlano(e.target.value)} className="w-full rounded border border-input bg-background px-2 py-1.5">
              <option value="">Todos</option>
              {planos.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
          <label>
            <div className="text-muted-foreground">FIPE mín.</div>
            <input value={fipeMin} onChange={(e) => setFipeMin(e.target.value)} type="number" className="w-full rounded border border-input bg-background px-2 py-1.5" />
          </label>
          <label>
            <div className="text-muted-foreground">FIPE máx.</div>
            <input value={fipeMax} onChange={(e) => setFipeMax(e.target.value)} type="number" className="w-full rounded border border-input bg-background px-2 py-1.5" />
          </label>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="Filtrados" value={fmtInt(filtered.length)} />
          <Stat label="Operacionais" value={fmtInt(oper.length)} />
          <Stat label="Sem rastreador" value={fmtInt(semRast)} />
          <Stat label="Cobertura" value={fmtPct(oper.length ? comRast / oper.length : 0)} />
          <Stat label="Com rastreador" value={fmtInt(comRast)} />
          <Stat label="Cancelados c/ rastreador" value={fmtInt(canRast)} />
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm">Lista priorizada de cidades para instalação</div>
          <div className="overflow-auto max-h-[520px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr className="text-left">
                  {["Cidade/UF", "Oper.", "Sem rast.", "Cobertura", "Motos", "Carros", "Caminhões", "Canc. c/ rast.", "Prest. atv/nec", "Risco", "Política", "Score", "Prioridade"].map((h) => (
                    <th key={h} className="px-3 py-2 whitespace-nowrap font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {prioridade.slice(0, 300).map((c) => (
                  <tr key={c.chave} className="border-t border-border hover:bg-muted/40">
                    <td className="px-3 py-1.5 whitespace-nowrap font-medium">{c.cidade}/{c.uf}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.operacionais)}</td>
                    <td className="px-3 py-1.5 tabular-nums text-amber-700">{fmtInt(c.semRastreador)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtPct(c.cobertura)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.motos)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.carros)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.caminhoes)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(c.canceladosComRastreador)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{c.prestadoresAtivos}/{c.prestadoresNecessarios}</td>
                    <td className="px-3 py-1.5">{c.nivelRisco}</td>
                    <td className="px-3 py-1.5">{c.politica ?? "—"}</td>
                    <td className="px-3 py-1.5 tabular-nums font-semibold">{c.score}</td>
                    <td className="px-3 py-1.5">
                      <span className={`inline-block rounded px-2 py-0.5 text-white ${
                        c.prioridade === "critico" ? "bg-red-600" :
                        c.prioridade === "alto" ? "bg-amber-500" :
                        c.prioridade === "medio" ? "bg-yellow-500" : "bg-green-600"
                      }`}>{c.prioridade}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-card border border-border p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-xl font-semibold tabular-nums">{value}</div>
    </div>
  );
}
