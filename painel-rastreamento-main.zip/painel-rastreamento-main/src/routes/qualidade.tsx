import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { EmptyState } from "@/components/KpiCard";
import { CityTrackingAudit } from "@/components/CityTrackingAudit";
import { useStore } from "@/lib/store";
import { computeDataQuality, computeUnclassifiedGroups } from "@/lib/calc";
import { downloadCSV } from "@/lib/export-csv";
import { fmtInt } from "@/lib/format";


export const Route = createFileRoute("/qualidade")({
  component: Page,
});

function Page() {
  const { associados } = useStore();
  const issues = useMemo(() => computeDataQuality(associados), [associados]);
  const unclassified = useMemo(() => computeUnclassifiedGroups(associados), [associados]);

  const [selected, setSelected] = useState(0);

  if (!associados.length) {
    return (
      <AppLayout>
        <EmptyState title="Sem base carregada" description="Importe a planilha para ver a auditoria." />
      </AppLayout>
    );
  }

  const current = issues[selected];

  const exportAll = () => {
    const rows: Array<Record<string, unknown>> = [];
    for (const iss of issues) {
      for (const r of iss.registros) {
        rows.push({ tipo: iss.tipo, ...r });
      }
    }
    downloadCSV("inconsistencias.csv", rows);
  };

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold">Qualidade dos Dados</h1>
            <p className="text-sm text-muted-foreground">Duplicidades, campos vazios e categorias não classificadas.</p>
          </div>
          <button onClick={exportAll} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90">
            <Download className="h-3.5 w-3.5" /> Exportar inconsistências
          </button>
        </div>

        <CityTrackingAudit />


        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {issues.map((iss, i) => (
            <button
              key={iss.tipo}
              onClick={() => setSelected(i)}
              className={`rounded-md border p-3 text-left ${i === selected ? "border-primary bg-primary/5" : "border-border bg-card"}`}
            >
              <div className="text-xs text-muted-foreground">{iss.descricao}</div>
              <div className={`text-2xl font-semibold tabular-nums ${iss.quantidade > 0 ? "text-destructive" : "text-foreground"}`}>{fmtInt(iss.quantidade)}</div>
            </button>
          ))}
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm">
            {current.descricao} — mostrando {Math.min(current.registros.length, 500)} de {fmtInt(current.quantidade)}
          </div>
          <div className="overflow-auto max-h-[520px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr className="text-left">
                {["#", "Associado", "Placa", "Cidade", "UF", "Valor"].map((h) => (<th key={h} className="px-3 py-2 font-medium">{h}</th>))}
              </tr></thead>
              <tbody>
                {current.registros.map((r, i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="px-3 py-1.5 tabular-nums text-muted-foreground">{r.index + 1}</td>
                    <td className="px-3 py-1.5">{r.associado}</td>
                    <td className="px-3 py-1.5">{r.placa}</td>
                    <td className="px-3 py-1.5">{r.cidade}</td>
                    <td className="px-3 py-1.5">{r.estado}</td>
                    <td className="px-3 py-1.5 truncate max-w-xs">{r.valor}</td>
                  </tr>
                ))}
                {!current.registros.length && (<tr><td colSpan={6} className="px-3 py-6 text-center text-muted-foreground">Sem ocorrências.</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm flex items-center justify-between">
            <span>Categorias não classificadas — agrupadas ({unclassified.length} categorias · {fmtInt(unclassified.reduce((s, g) => s + g.total, 0))} registros)</span>
            <button
              onClick={() => downloadCSV("nao_classificadas_agrupadas.csv", unclassified.map((g) => ({ ...g })))}
              className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs hover:bg-muted"
            >
              <Download className="h-3 w-3" /> Exportar
            </button>
          </div>
          <div className="overflow-auto max-h-[420px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr className="text-left">
                {["Categoria original", "Total", "Operacional", "Situação predominante", "Motivo"].map((h) => (
                  <th key={h} className="px-3 py-2 font-medium">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {unclassified.map((g) => (
                  <tr key={g.categoriaOriginal} className="border-t border-border">
                    <td className="px-3 py-1.5">{g.categoriaOriginal}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(g.total)}</td>
                    <td className="px-3 py-1.5 tabular-nums">{fmtInt(g.operacionais)}</td>
                    <td className="px-3 py-1.5">{g.situacaoPredominante}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{g.motivo}</td>
                  </tr>
                ))}
                {!unclassified.length && (<tr><td colSpan={5} className="px-3 py-6 text-center text-muted-foreground">Sem categorias não classificadas.</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

