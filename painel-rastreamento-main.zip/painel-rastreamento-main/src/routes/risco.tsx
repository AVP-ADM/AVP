import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download, Pencil, Plus, Power, PowerOff, Trash2, Upload, X } from "lucide-react";
import * as XLSX from "xlsx";
import { AppLayout } from "@/components/AppLayout";
import { useStore, upsertRegra, removeRegra, setRegras } from "@/lib/store";
import { downloadCSV } from "@/lib/export-csv";
import { lookupCoords } from "@/lib/city-coords";
import {
  NIVEL_RISCO_COLOR,
  NIVEL_RISCO_LABEL,
  type NivelRisco,
  type Politica,
  type RegraRisco,
  type RegraTipoVeiculo,
} from "@/lib/types";

export const Route = createFileRoute("/risco")({
  component: Page,
});

const uid = () => Math.random().toString(36).slice(2, 10);

const POLITICA_LABEL: Record<Politica, string> = {
  aceita_normalmente: "Aceita normalmente",
  aceita_somente_com_rastreador: "Aceita somente com rastreador",
  aceita_com_vistoria: "Aceita com vistoria/prestador",
  nao_aceita_moto: "Não aceita moto",
  nao_aceita: "Não aceita",
};

const TIPO_LABEL: Record<RegraTipoVeiculo, string> = {
  todos: "Todos",
  carro: "Carro",
  moto: "Moto",
  caminhao: "Caminhão",
  nao_classificado: "Não classificado",
};

function novaRegra(): RegraRisco {
  return {
    id: "",
    nome: "",
    uf: "",
    cidade: "",
    latCentral: null,
    lngCentral: null,
    raioKm: 30,
    tipoVeiculo: "todos",
    nivelRisco: "medio",
    politica: "aceita_normalmente",
    motivo: "",
    fonte: "",
    atualizadoEm: new Date().toISOString(),
    status: "ativa",
  };
}

function Page() {
  const { regras } = useStore();
  const [form, setForm] = useState<RegraRisco>(novaRegra);
  const isEditing = !!form.id;

  const preenchendoCoords = useMemo(() => {
    if (form.latCentral != null && form.lngCentral != null) return null;
    if (!form.cidade || !form.uf) return null;
    const c = lookupCoords(form.cidade, form.uf);
    return c ? { lat: c[0], lng: c[1] } : null;
  }, [form.cidade, form.uf, form.latCentral, form.lngCentral]);

  const submit = () => {
    if (!form.uf || !form.cidade) return;
    let { latCentral, lngCentral } = form;
    if (latCentral == null || lngCentral == null) {
      if (preenchendoCoords) {
        latCentral = preenchendoCoords.lat;
        lngCentral = preenchendoCoords.lng;
      }
    }
    upsertRegra({
      ...form,
      id: form.id || uid(),
      uf: form.uf.toUpperCase(),
      nome: form.nome || `${form.cidade}/${form.uf.toUpperCase()}`,
      latCentral,
      lngCentral,
      raioKm: Math.max(1, Number(form.raioKm) || 30),
      atualizadoEm: new Date().toISOString(),
    });
    setForm(novaRegra());
  };

  const editar = (r: RegraRisco) => {
    setForm({ ...r });
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const cancelarEdicao = () => setForm(novaRegra());

  const toggleStatus = (r: RegraRisco) => {
    upsertRegra({
      ...r,
      status: r.status === "ativa" ? "inativa" : "ativa",
      atualizadoEm: new Date().toISOString(),
    });
  };

  const handleImport = async (file: File) => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const ws = wb.Sheets[wb.SheetNames[0]!]!;
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(ws);
    const list: RegraRisco[] = rows
      .map((r) => {
        const cidade = String(r.cidade || r.Cidade || "");
        const uf = String(r.uf || r.UF || "").toUpperCase();
        const coords = lookupCoords(cidade, uf);
        const lat = r.latitude != null && r.latitude !== "" ? Number(r.latitude) : coords?.[0] ?? null;
        const lng = r.longitude != null && r.longitude !== "" ? Number(r.longitude) : coords?.[1] ?? null;
        return {
          id: uid(),
          nome: String(r.nome || r.area || `${cidade}/${uf}`),
          uf,
          cidade,
          latCentral: Number.isFinite(lat) ? (lat as number) : null,
          lngCentral: Number.isFinite(lng) ? (lng as number) : null,
          raioKm: Math.max(1, Number(r.raioKm || r.raio || 30)),
          tipoVeiculo: (String(r.tipoVeiculo || r.tipo || "todos").toLowerCase() as RegraTipoVeiculo),
          nivelRisco: (String(r.nivelRisco || r.risco || "medio").toLowerCase() as NivelRisco),
          politica: (String(r.politica || "aceita_normalmente").toLowerCase() as Politica),
          motivo: String(r.motivo || ""),
          fonte: String(r.fonte || ""),
          atualizadoEm: new Date().toISOString(),
          status: (String(r.status || "ativa").toLowerCase() === "inativa" ? "inativa" : "ativa"),
        } as RegraRisco;
      })
      .filter((r) => r.uf && r.cidade);
    setRegras([...regras, ...list]);
  };

  const exportModelo = () => {
    downloadCSV("areas_risco_modelo.csv", [
      { nome: "Recife e Região Metropolitana", uf: "PE", cidade: "Recife", latitude: -8.0476, longitude: -34.877, raioKm: 50, tipoVeiculo: "todos", nivelRisco: "alto", politica: "aceita_somente_com_rastreador", motivo: "Maior incidência de roubo e furto", fonte: "SDS/PE", status: "ativa" },
      { nome: "Recife - motos", uf: "PE", cidade: "Recife", latitude: -8.0476, longitude: -34.877, raioKm: 20, tipoVeiculo: "moto", nivelRisco: "critico", politica: "nao_aceita_moto", motivo: "Roubo de motos concentrado", fonte: "Interno", status: "ativa" },
    ]);
  };

  const exportAll = () => {
    downloadCSV("areas_risco.csv", regras.map((r) => ({ ...r })));
  };

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold">Áreas de Risco e Política</h1>
            <p className="text-sm text-muted-foreground max-w-3xl">
              Cadastro manual do risco de roubo e furto por área geográfica. Ele NÃO depende de quantidade de associados, cobertura ou déficit de prestadores — esses continuam medidos separadamente como Prioridade Operacional.
            </p>
          </div>
          <div className="flex gap-2">
            <label className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs cursor-pointer hover:bg-muted">
              <Upload className="h-3.5 w-3.5" /> Importar CSV/XLSX
              <input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => e.target.files && handleImport(e.target.files[0]!)} />
            </label>
            <button onClick={exportModelo} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted">
              <Download className="h-3.5 w-3.5" /> Modelo
            </button>
            <button onClick={exportAll} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted">
              <Download className="h-3.5 w-3.5" /> Exportar áreas
            </button>
          </div>
        </div>

        <div className="rounded-lg bg-card p-4">
          <h2 className="text-sm font-semibold mb-3">{isEditing ? `Editando área: ${form.nome || form.cidade}` : "Nova área de risco"}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <Field label="Nome da área">
              <input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="input" placeholder="Ex.: Recife e RM" />
            </Field>
            <Field label="Cidade central">
              <input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} className="input" />
            </Field>
            <Field label="UF">
              <input maxLength={2} value={form.uf} onChange={(e) => setForm({ ...form, uf: e.target.value })} className="input" />
            </Field>
            <Field label="Raio (km)">
              <input type="number" min={1} value={form.raioKm} onChange={(e) => setForm({ ...form, raioKm: Number(e.target.value) })} className="input" />
            </Field>
            <Field label="Latitude central">
              <input type="number" step="0.0001" value={form.latCentral ?? ""} onChange={(e) => setForm({ ...form, latCentral: e.target.value === "" ? null : Number(e.target.value) })} className="input" placeholder={preenchendoCoords ? `auto: ${preenchendoCoords.lat.toFixed(4)}` : ""} />
            </Field>
            <Field label="Longitude central">
              <input type="number" step="0.0001" value={form.lngCentral ?? ""} onChange={(e) => setForm({ ...form, lngCentral: e.target.value === "" ? null : Number(e.target.value) })} className="input" placeholder={preenchendoCoords ? `auto: ${preenchendoCoords.lng.toFixed(4)}` : ""} />
            </Field>
            <Field label="Tipo de veículo">
              <select value={form.tipoVeiculo} onChange={(e) => setForm({ ...form, tipoVeiculo: e.target.value as RegraTipoVeiculo })} className="input">
                <option value="todos">Todos</option>
                <option value="carro">Carro</option>
                <option value="moto">Moto</option>
                <option value="caminhao">Caminhão</option>
              </select>
            </Field>
            <Field label="Nível de risco">
              <select value={form.nivelRisco} onChange={(e) => setForm({ ...form, nivelRisco: e.target.value as NivelRisco })} className="input">
                <option value="sem_classificacao">Sem classificação</option>
                <option value="baixo">Baixo</option>
                <option value="medio">Médio</option>
                <option value="alto">Alto</option>
                <option value="critico">Crítico</option>
              </select>
            </Field>
            <Field label="Política aplicável">
              <select value={form.politica} onChange={(e) => setForm({ ...form, politica: e.target.value as Politica })} className="input">
                {Object.entries(POLITICA_LABEL).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}
              </select>
            </Field>
            <Field label="Fonte da informação">
              <input value={form.fonte} onChange={(e) => setForm({ ...form, fonte: e.target.value })} className="input" placeholder="Ex.: SDS/PE, boletim interno" />
            </Field>
            <Field label="Status">
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as "ativa" | "inativa" })} className="input">
                <option value="ativa">Ativa</option>
                <option value="inativa">Inativa</option>
              </select>
            </Field>
            <Field label="Motivo">
              <input value={form.motivo} onChange={(e) => setForm({ ...form, motivo: e.target.value })} className="input" />
            </Field>
          </div>
          <div className="mt-3 flex gap-2">
            <button onClick={submit} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90">
              <Plus className="h-3.5 w-3.5" /> {isEditing ? "Atualizar área" : "Salvar área"}
            </button>
            {isEditing && (
              <button onClick={cancelarEdicao} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted">
                <X className="h-3.5 w-3.5" /> Cancelar edição
              </button>
            )}
          </div>
        </div>

        <div className="rounded-lg bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-semibold text-sm">Áreas cadastradas ({regras.length})</div>
          <div className="overflow-auto max-h-[520px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr className="text-left">
                {["Nome", "Cidade/UF", "Raio", "Tipo", "Risco", "Política", "Fonte", "Status", "Atualizado", ""].map((h) => (<th key={h} className="px-3 py-2 font-medium">{h}</th>))}
              </tr></thead>
              <tbody>
                {regras.map((r) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-3 py-1.5">{r.nome || "—"}</td>
                    <td className="px-3 py-1.5">{r.cidade}/{r.uf}</td>
                    <td className="px-3 py-1.5">{r.raioKm} km</td>
                    <td className="px-3 py-1.5">{TIPO_LABEL[r.tipoVeiculo]}</td>
                    <td className="px-3 py-1.5"><Chip nivel={r.nivelRisco} /></td>
                    <td className="px-3 py-1.5">{POLITICA_LABEL[r.politica]}</td>
                    <td className="px-3 py-1.5 max-w-[140px] truncate" title={r.fonte}>{r.fonte || "—"}</td>
                    <td className="px-3 py-1.5">
                      <span className={r.status === "ativa" ? "text-green-600" : "text-muted-foreground"}>{r.status}</span>
                    </td>
                    <td className="px-3 py-1.5">{new Date(r.atualizadoEm).toLocaleDateString("pt-BR")}</td>
                    <td className="px-3 py-1.5">
                      <div className="flex gap-1.5">
                        <button title="Editar" onClick={() => editar(r)} className="text-primary hover:opacity-80"><Pencil className="h-3.5 w-3.5" /></button>
                        <button title={r.status === "ativa" ? "Inativar" : "Ativar"} onClick={() => toggleStatus(r)} className={r.status === "ativa" ? "text-amber-600" : "text-green-600"}>
                          {r.status === "ativa" ? <PowerOff className="h-3.5 w-3.5" /> : <Power className="h-3.5 w-3.5" />}
                        </button>
                        <button title="Excluir" onClick={() => removeRegra(r.id)} className="text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!regras.length && (<tr><td colSpan={10} className="px-3 py-6 text-center text-muted-foreground">Nenhuma área cadastrada. Cadastre a primeira acima.</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <style>{`.input{width:100%;border:1px solid var(--input);background:var(--background);border-radius:6px;padding:6px 8px;font-size:12px}`}</style>
    </AppLayout>
  );
}

function Chip({ nivel }: { nivel: NivelRisco }) {
  return (
    <span
      className="inline-block rounded px-2 py-0.5 text-white text-[11px]"
      style={{ background: NIVEL_RISCO_COLOR[nivel] }}
    >
      {NIVEL_RISCO_LABEL[nivel]}
    </span>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (<label className="space-y-1"><div className="text-muted-foreground">{label}</div>{children}</label>);
}
