import { useEffect, useRef, useState, useCallback } from "react";
import {
  CloudDownload, RefreshCw, Loader2, FlaskConical, XCircle, Info,
  StopCircle, RotateCw, CheckCircle2,
} from "lucide-react";
import {
  fetchAssociadosFromSupabase,
  fetchAssociadosTotal,
  fetchLatestSyncRun,
  startSync,
  processPeriod,
  retryPeriod,
  splitPeriod,
  finalizeSync,
  applySync,
  getSyncStatus,
  cancelSync,
  findActiveSync,
  getStoredSyncId,
  setStoredSyncId,
  type SyncRunSummary,
  type SyncErrorInfo,
  type SyncStatusResponse,
  type SyncPart,
} from "@/lib/aeasy-sync";
import { setAssociados } from "@/lib/store";
import { fmtInt } from "@/lib/format";

const COOLDOWN_APPLY_MS = 60 * 60 * 1000;
const COOLDOWN_DRY_MS = 10 * 60 * 1000;
const POLL_ACTIVE_MS = 5000;
const POLL_IDLE_MS = 15000;

function fmtRemaining(ms: number): string {
  const min = Math.ceil(ms / 60000);
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60), m = min % 60;
  return m ? `${h}h ${m}min` : `${h}h`;
}

type UiError = { message: string; code?: string; stage?: string; details?: unknown; at: string };

const PART_LABEL: Record<SyncPart["status"], string> = {
  pending: "Aguardando",
  generating: "Gerando relatório",
  downloading: "Baixando XLSX",
  processing: "Processando",
  persisting: "Persistindo",
  success: "Concluído",
  failed: "Falhou",
  split: "Substituído por períodos menores",
};

const RUN_LABEL: Record<string, string> = {
  initializing: "Inicializando",
  collecting: "Coletando períodos",
  consolidating: "Consolidando",
  ready: "Pronto para aplicar",
  applying: "Aplicando atualização",
  success: "Sucesso",
  failed: "Falhou",
  cancelled: "Cancelado",
};

const IN_PROGRESS_PART = new Set<SyncPart["status"]>([
  "generating", "downloading", "processing", "persisting",
]);

export function AeasySyncButton({ hasData: _hasData }: { hasData: boolean }) {
  const [lastApply, setLastApply] = useState<SyncRunSummary | null>(null);
  const [lastDry, setLastDry] = useState<SyncRunSummary | null>(null);
  const [total, setTotal] = useState<number | null>(null);
  const [busy, setBusy] = useState<null | "starting-dry" | "starting-apply" | "orchestrating" | "applying" | "cancelling" | "retrying">(null);
  const [progress, setProgress] = useState<SyncStatusResponse | null>(null);
  const [finalReport, setFinalReport] = useState<any>(null);
  const [error, setError] = useState<UiError | null>(null);
  const [showErrorDetails, setShowErrorDetails] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [now, setNow] = useState(Date.now());
  const orchestratingRef = useRef(false);
  const cancelRequestedRef = useRef(false);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  const refreshMeta = useCallback(async () => {
    const [apply, dry, count] = await Promise.all([
      fetchLatestSyncRun("apply"),
      fetchLatestSyncRun("dry_run"),
      fetchAssociadosTotal().catch(() => 0),
    ]);
    setLastApply(apply); setLastDry(dry); setTotal(count);
  }, []);

  // Hydrate: DB is source of truth. localStorage is only a hint.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await refreshMeta();
        if (!alive) return;
        try {
          const rows = await fetchAssociadosFromSupabase();
          if (alive && rows.length) setAssociados(rows, null, "AEasy (Supabase)");
        } catch { /* ignore */ }

        // 1) ask backend for the active run (works across tabs/devices).
        let activeId: string | null = null;
        try {
          const r = await findActiveSync();
          if (r.active) activeId = r.active.id;
        } catch { /* ignore */ }

        // 2) fallback to localStorage hint, validated against backend.
        if (!activeId) {
          const hint = getStoredSyncId();
          if (hint) {
            try {
              const st = await getSyncStatus(hint);
              if (!["success", "failed", "cancelled"].includes(st.run.status)) {
                activeId = hint;
              }
            } catch { /* stale */ }
          }
        }

        if (!alive) return;
        if (activeId) {
          setStoredSyncId(activeId);
          try {
            const st = await getSyncStatus(activeId);
            if (!alive) return;
            setProgress(st);
            // If the run is still "collecting" and has pending parts, resume orchestration.
            if (!["success", "failed", "cancelled", "ready", "applying"].includes(st.run.status)) {
              void resumeOrchestration(activeId);
            }
          } catch { setStoredSyncId(null); }
        } else {
          setStoredSyncId(null);
        }
      } catch (e) {
        if (alive) setError({ message: (e as Error).message, at: new Date().toISOString() });
      }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshMeta]);

  // Polling while there is an active run. Faster while processing, slower while idle.
  useEffect(() => {
    const id = progress?.run.sync_id;
    if (!id) return;
    if (["success", "failed", "cancelled"].includes(progress.run.status)) return;
    const anyProcessing = progress.parts.some((p) => IN_PROGRESS_PART.has(p.status));
    const interval = anyProcessing ? POLL_ACTIVE_MS : POLL_IDLE_MS;
    const t = setInterval(async () => {
      try {
        const st = await getSyncStatus(id);
        setProgress(st);
      } catch { /* ignore transient errors */ }
    }, interval);
    return () => clearInterval(t);
  }, [progress?.run.sync_id, progress?.run.status, progress?.parts]);

  const applyRemaining = lastApply?.started_at
    ? Math.max(0, new Date(lastApply.started_at).getTime() + COOLDOWN_APPLY_MS - now) : 0;
  const dryRemaining = lastDry?.started_at
    ? Math.max(0, new Date(lastDry.started_at).getTime() + COOLDOWN_DRY_MS - now) : 0;

  const label = lastApply?.status === "success" ? "Atualizar dados do AEasy" : "Importar dados do AEasy";
  const activeRun = progress && !["success", "failed", "cancelled"].includes(progress.run.status);
  const applyDisabled = !!busy || !!activeRun || applyRemaining > 0;
  const dryDisabled = !!busy || !!activeRun || dryRemaining > 0;

  // ---------- Orchestration -------------------------------------------------
  async function resumeOrchestration(sync_id: string) {
    if (orchestratingRef.current) return;
    orchestratingRef.current = true;
    cancelRequestedRef.current = false;
    setBusy("orchestrating");
    try {
      const attempts = new Map<string, number>();
      // eslint-disable-next-line no-constant-condition
      while (true) {
        if (cancelRequestedRef.current) break;
        const status = await getSyncStatus(sync_id);
        setProgress(status);
        if (["success", "failed", "cancelled", "ready", "applying"].includes(status.run.status)) break;

        const splitParents = new Set(status.parts.filter((p) => p.status === "split").map((p) => p.period_key));
        const pending = status.parts.find((p) => p.status === "pending" && !splitParents.has(p.period_key));

        if (pending) {
          const attempt = (attempts.get(pending.period_key) ?? 0) + 1;
          attempts.set(pending.period_key, attempt);
          try {
            await processPeriod(sync_id, pending.period_key);
          } catch (e) {
            const err = e as SyncErrorInfo;
            // 409 = another tab is processing this period. Not a failure, just wait.
            if (err.status === 409 || err.code === "PART_IN_PROGRESS") {
              await sleep(3000);
              continue;
            }
            if (err.code === "EDGE_FUNCTION_RESOURCE_LIMIT" || err.code === "EDGE_FUNCTION_TIMEOUT") {
              if (pending.granularity !== "month") {
                try { await splitPeriod(sync_id, pending.period_key); }
                catch { throw err; }
              } else if (attempt < 2) {
                await sleep(2000);
              } else {
                throw err;
              }
            } else if (attempt >= 2) {
              // Leave the period in `failed` state so the user can retry manually.
              await sleep(1500);
            } else {
              await sleep(1500);
            }
          }
          await sleep(1500);
          continue;
        }

        const anyFailed = status.parts.some((p) => p.status === "failed");
        if (anyFailed) {
          // Stop and let the user retry manually.
          break;
        }
        const report = await finalizeSync(sync_id);
        setFinalReport(report);
        if (report?.status === "collecting") { await sleep(1500); continue; }
        break;
      }
      const final = await getSyncStatus(sync_id);
      setProgress(final);
      if (final.run.status === "success" || final.run.status === "ready") {
        setFinalReport({ ...(final.run.analysis || {}), status: final.run.status, ready_to_apply: final.run.ready_to_apply });
      }
      await refreshMeta();
    } catch (e) {
      const err = e as SyncErrorInfo;
      setError({
        message: err.message, code: err.code, stage: err.stage,
        details: err.details ?? err.raw_body, at: new Date().toISOString(),
      });
    } finally {
      orchestratingRef.current = false;
      setBusy(null);
    }
  }

  const run = async (dryRun: boolean) => {
    if (busy || activeRun) return;
    if (!dryRun && !window.confirm("Esta operação consultará novamente toda a base do AEasy e atualizará o banco. Deseja continuar?")) return;

    setBusy(dryRun ? "starting-dry" : "starting-apply");
    setError(null); setFinalReport(null); setProgress(null); setShowReport(dryRun);
    try {
      const start = await startSync(dryRun ? "dry_run" : "apply");
      setStoredSyncId(start.sync_id);
      await resumeOrchestration(start.sync_id);
    } catch (e) {
      const err = e as SyncErrorInfo;
      let msg = err.message;
      if (err.status === 429 && err.remaining_min != null) msg = `Aguarde ${err.remaining_min} min.`;
      else if (err.status === 409) msg = "Já existe uma sincronização em andamento.";
      setError({ message: msg, code: err.code, stage: err.stage, details: err.details ?? err.raw_body, at: new Date().toISOString() });
      setBusy(null);
    }
  };

  const cancel = async () => {
    const id = progress?.run.sync_id ?? getStoredSyncId();
    if (!id) return;
    if (!window.confirm("Cancelar a sincronização em andamento?")) return;
    setBusy("cancelling");
    cancelRequestedRef.current = true;
    try { await cancelSync(id); } catch { /* ignore */ }
    setStoredSyncId(null);
    try { const st = await getSyncStatus(id); setProgress(st); } catch { setProgress(null); }
    setBusy(null);
  };

  const doRetry = async (period_key: string) => {
    const id = progress?.run.sync_id;
    if (!id || busy) return;
    if (!window.confirm(`Tentar novamente o período ${period_key}?\n\nO staging deste período será limpo e ele será reprocessado.`)) return;
    setBusy("retrying");
    try {
      await retryPeriod(id, period_key);
      const st = await getSyncStatus(id);
      setProgress(st);
      // Resume orchestration to continue after the retry.
      void resumeOrchestration(id);
    } catch (e) {
      const err = e as SyncErrorInfo;
      setError({ message: err.message, code: err.code, stage: err.stage, details: err.details ?? err.raw_body, at: new Date().toISOString() });
    } finally {
      if (busy === "retrying") setBusy(null);
    }
  };

  const doApply = async () => {
    const id = progress?.run.sync_id;
    if (!id || busy) return;
    const analysis = (progress?.run.analysis || {}) as any;
    const cmp = analysis?.compare_supabase || {};
    const msg =
      `A base foi validada e está pronta para atualização.\n\n` +
      `Total consolidado: ${fmtInt(analysis?.consolidated_total ?? 0)}\n` +
      `Novos estimados: ${fmtInt(cmp.inserted_estimate ?? 0)}\n` +
      `Atualizados estimados: ${fmtInt(cmp.updated_estimate ?? 0)}\n` +
      `Inalterados estimados: ${fmtInt(cmp.unchanged_estimate ?? 0)}\n` +
      `Ausentes (auditoria, não serão excluídos): ${fmtInt(cmp.missing_estimate ?? 0)}\n` +
      `Duplicidades removidas: ${fmtInt(analysis?.duplicates_removed ?? 0)}\n\n` +
      `Registros inalterados não serão regravados. Deseja aplicar agora?`;
    if (!window.confirm(msg)) return;
    setBusy("applying");
    try {
      const res = await applySync(id);
      setFinalReport(res);
      const st = await getSyncStatus(id);
      setProgress(st);
      setStoredSyncId(null);
      try {
        const rows = await fetchAssociadosFromSupabase();
        setAssociados(rows, null, "AEasy (Supabase)");
        setTotal(rows.length);
      } catch { /* ignore */ }
      await refreshMeta();
    } catch (e) {
      const err = e as SyncErrorInfo;
      setError({ message: err.message, code: err.code, stage: err.stage, details: err.details ?? err.raw_body, at: new Date().toISOString() });
    } finally {
      setBusy(null);
    }
  };

  const parts = progress?.parts ?? [];
  const splitParents = new Set(parts.filter((p) => p.status === "split").map((p) => p.period_key));
  const activeParts = parts.filter((p) => !splitParents.has(p.period_key) && p.status !== "split");
  const totalParts = activeParts.length;
  const donePartsCount = activeParts.filter((p) => p.status === "success").length;
  const failedParts = parts.filter((p) => p.status === "failed");
  const validRowsSoFar = activeParts.reduce((sum, p) => sum + (p.valid_rows || 0), 0);

  // Group children by parent for split visualisation.
  const childrenByParent = new Map<string, SyncPart[]>();
  parts.forEach((p) => {
    if (p.parent_period_key) {
      const arr = childrenByParent.get(p.parent_period_key) ?? [];
      arr.push(p);
      childrenByParent.set(p.parent_period_key, arr);
    }
  });
  const topLevelParts = parts.filter((p) => !p.parent_period_key);

  const canApply =
    progress?.run.run_mode === "apply" &&
    progress?.run.status === "ready" &&
    progress?.run.ready_to_apply === true &&
    !failedParts.length &&
    !busy;

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={() => run(false)} disabled={applyDisabled}
          title={applyRemaining > 0 ? `Aguarde ${fmtRemaining(applyRemaining)}` : undefined}
          className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed">
          {busy === "starting-apply" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> :
            (lastApply?.status === "success" ? <RefreshCw className="h-3.5 w-3.5" /> : <CloudDownload className="h-3.5 w-3.5" />)}
          {busy === "starting-apply" ? "Iniciando…" : label}
        </button>
        <button onClick={() => run(true)} disabled={dryDisabled}
          title={dryRemaining > 0 ? `Aguarde ${fmtRemaining(dryRemaining)}` : "Simula a sincronização sem gravar dados"}
          className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-xs font-medium hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed">
          {busy === "starting-dry" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FlaskConical className="h-3.5 w-3.5" />}
          {busy === "starting-dry" ? "Iniciando…" : "Diagnóstico (dryRun)"}
        </button>
        {canApply && (
          <button onClick={doApply} disabled={!!busy}
            className="inline-flex items-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-xs font-medium text-white hover:opacity-90 disabled:opacity-50">
            {busy === "applying" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
            {busy === "applying" ? "Aplicando atualização…" : "Aplicar agora"}
          </button>
        )}
        {activeRun && (
          <button onClick={cancel} disabled={busy === "cancelling"}
            className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2 py-1.5 text-[11px] hover:bg-muted disabled:opacity-50">
            {busy === "cancelling" ? <Loader2 className="h-3 w-3 animate-spin" /> : <StopCircle className="h-3 w-3" />}
            {busy === "cancelling" ? "Cancelando…" : "Cancelar diagnóstico"}
          </button>
        )}
      </div>

      <div className="text-[11px] text-muted-foreground leading-tight flex flex-wrap gap-x-3 gap-y-0.5">
        <span className="inline-flex items-center gap-1"><Info className="h-3 w-3" /> Integração pública</span>
        {total != null && <span>Base: <b>{fmtInt(total)}</b> registros</span>}
        {lastApply?.started_at && <span>Última atualização: <b>{new Date(lastApply.started_at).toLocaleString("pt-BR")}</b> · {lastApply.status}</span>}
        {applyRemaining > 0 && <span>Próxima atualização em: <b>{fmtRemaining(applyRemaining)}</b></span>}
        {dryRemaining > 0 && <span>Diagnóstico liberado em: <b>{fmtRemaining(dryRemaining)}</b></span>}
      </div>

      {progress && (
        <div className="text-[11px] leading-tight border border-border rounded-md p-2 bg-muted/40 max-w-3xl">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <b>Progresso</b>
            <span>· Modo: <code>{progress.run.run_mode}</code></span>
            <span>· Estado: <b>{RUN_LABEL[progress.run.status] ?? progress.run.status}</b></span>
            {progress.run.official_total != null && <span>· Oficial AEasy: <b>{fmtInt(progress.run.official_total)}</b></span>}
          </div>
          <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[10px]">
            <span>Períodos ativos: <b>{donePartsCount}/{totalParts}</b></span>
            <span>Linhas válidas coletadas: <b>{fmtInt(validRowsSoFar)}</b></span>
            {failedParts.length > 0 && <span className="text-destructive">Com falha: <b>{failedParts.length}</b></span>}
            {progress.run.ready_to_apply === true && <span className="text-emerald-600">✓ Pronto para aplicar</span>}
          </div>

          {topLevelParts.length > 0 && (
            <div className="mt-2 space-y-1">
              {topLevelParts.map((p) => (
                <PartRow
                  key={p.period_key}
                  part={p}
                  children={childrenByParent.get(p.period_key) ?? []}
                  childrenByParent={childrenByParent}
                  onRetry={doRetry}
                  disabled={!!busy}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {finalReport && !busy && (
        <div className="text-[11px] leading-tight border border-border rounded-md p-2 bg-muted/40 max-w-3xl">
          <div className="flex items-center gap-2 mb-1">
            <b>Relatório final</b>
            <button onClick={() => setShowReport((v) => !v)} className="ml-auto underline text-[10px]">
              {showReport ? "ocultar" : "ver detalhes"}
            </button>
          </div>
          {showReport && (
            <pre className="mt-2 max-h-96 overflow-auto text-[10px] bg-background rounded p-2 border border-border whitespace-pre-wrap break-all">
              {JSON.stringify(finalReport, null, 2)}
            </pre>
          )}
        </div>
      )}

      {error && (
        <div className="text-[11px] leading-tight border border-destructive/40 rounded-md p-2 bg-destructive/5 max-w-3xl">
          <div className="flex items-center gap-2 mb-1 text-destructive">
            <XCircle className="h-3.5 w-3.5" />
            <b>Falha na sincronização</b>
            {error.code && <span>· <code>{error.code}</code></span>}
            <button onClick={() => setShowErrorDetails((v) => !v)} className="ml-auto underline text-[10px] text-muted-foreground">
              {showErrorDetails ? "ocultar detalhes" : "ver detalhes"}
            </button>
          </div>
          <div className="text-foreground break-words">{error.message}</div>
          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-muted-foreground">
            {error.stage && <span>Etapa: <b>{error.stage}</b></span>}
            <span>Em: <b>{new Date(error.at).toLocaleString("pt-BR")}</b></span>
          </div>
          {showErrorDetails && (
            <pre className="mt-2 max-h-64 overflow-auto text-[10px] bg-background rounded p-2 border border-border whitespace-pre-wrap break-all">
              {JSON.stringify(error, null, 2)}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}

// ---------- Sub-components -------------------------------------------------
function PartRow({
  part, children, childrenByParent, onRetry, disabled, depth = 0,
}: {
  part: SyncPart;
  children: SyncPart[];
  childrenByParent: Map<string, SyncPart[]>;
  onRetry: (period_key: string) => void;
  disabled: boolean;
  depth?: number;
}) {
  const isSplit = part.status === "split";
  const isFailed = part.status === "failed";
  const inProgress = IN_PROGRESS_PART.has(part.status);
  const cls =
    part.status === "success" ? "border-emerald-500/40 bg-emerald-500/5" :
    isFailed ? "border-destructive/40 bg-destructive/5" :
    isSplit ? "border-border bg-muted/40 opacity-70" :
    inProgress ? "border-primary/40 bg-primary/5" :
    "border-border bg-background";
  return (
    <div className={"rounded border " + cls} style={{ marginLeft: depth * 12 }}>
      <div className="flex items-center justify-between gap-2 px-2 py-1 flex-wrap">
        <div className="flex items-center gap-2 min-w-0">
          <code className="text-[10px]">{part.period_key}</code>
          <span className="text-[10px] text-muted-foreground">({part.granularity})</span>
          <span className="text-[10px]"><b>{PART_LABEL[part.status]}</b></span>
          {part.attempt > 1 && <span className="text-[10px] text-muted-foreground">tentativa {part.attempt}</span>}
        </div>
        <div className="flex items-center gap-2">
          {!isSplit && (part.valid_rows > 0 || part.source_rows > 0) && (
            <span className="text-[10px] text-muted-foreground">
              {fmtInt(part.valid_rows)} válidas / {fmtInt(part.source_rows)}
            </span>
          )}
          {isFailed && (
            <button
              onClick={() => onRetry(part.period_key)}
              disabled={disabled}
              className="inline-flex items-center gap-1 rounded border border-border bg-background px-1.5 py-0.5 text-[10px] hover:bg-muted disabled:opacity-50"
              title={part.error_message ?? undefined}
            >
              <RotateCw className="h-2.5 w-2.5" /> Tentar novamente
            </button>
          )}
        </div>
      </div>
      {isFailed && part.error_code && (
        <div className="px-2 pb-1 text-[10px] text-destructive break-words">
          <b>{part.error_code}</b>{part.error_message ? ` — ${part.error_message}` : ""}
        </div>
      )}
      {isSplit && children.length > 0 && (
        <div className="px-1 pb-1 space-y-1">
          <div className="px-2 text-[10px] text-muted-foreground">↳ substituído por {children.length} subperíodo(s)</div>
          {children.map((c) => (
            <PartRow
              key={c.period_key}
              part={c}
              children={childrenByParent.get(c.period_key) ?? []}
              childrenByParent={childrenByParent}
              onRetry={onRetry}
              disabled={disabled}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
