import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { auditCity } from "@/lib/map-filter";
import { fmtInt } from "@/lib/format";
import type { Situacao, TipoVeiculo } from "@/lib/types";

export function CityTrackingAudit() {
  const { associados } = useStore();

  const ufs = useMemo(
    () => Array.from(new Set(associados.map((a) => a.estado).filter(Boolean))).sort(),
    [associados],
  );

  const [uf, setUf] = useState("PE");
  const [cidade, setCidade] = useState("Recife");
  const [tipo, setTipo] = useState<TipoVeiculo | "todos">("todos");
  const [situacao, setSituacao] = useState<Situacao | "todos">("todos");

  const cidades = useMemo(() => {
    const s = new Set<string>();
    for (const a of associados) if (a.estado === uf && a.cidade) s.add(a.cidade);
    return Array.from(s).sort();
  }, [associados, uf]);

  const report = useMemo(
    () => auditCity(associados, cidade, uf, { tipo, situacao }),
    [associados, cidade, uf, tipo, situacao],
  );

  return (
    <div className="rounded-lg bg-card">
      <div className="px-4 py-3 border-b border-border flex flex-wrap gap-3 items-end">
        <div>
          <div className="font-semibold text-sm">Auditoria de rastreamento por cidade</div>
          <div className="text-xs text-muted-foreground">
            Aberto em Recife/PE. Valores mascarados para preservar dados sensíveis.
          </div>
        </div>
        <label className="text-xs">
          <div className="text-muted-foreground">UF</div>
          <select value={uf} onChange={(e) => { setUf(e.target.value); setCidade(""); }}
            className="rounded border border-input bg-background px-2 py-1">
            {ufs.map((u) => <option key={u} value={u}>{u}</option>)}
          </select>
        </label>
        <label className="text-xs">
          <div className="text-muted-foreground">Cidade</div>
          <select value={cidade} onChange={(e) => setCidade(e.target.value)}
            className="rounded border border-input bg-background px-2 py-1 min-w-[180px]">
            <option value="">Selecione…</option>
            {cidades.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label className="text-xs">
          <div className="text-muted-foreground">Tipo</div>
          <select value={tipo} onChange={(e) => setTipo(e.target.value as any)}
            className="rounded border border-input bg-background px-2 py-1">
            <option value="todos">Todos</option>
            <option value="carro">Carro</option>
            <option value="moto">Moto</option>
            <option value="caminhao">Caminhão</option>
            <option value="nao_classificado">Não classificado</option>
          </select>
        </label>
        <label className="text-xs">
          <div className="text-muted-foreground">Situação</div>
          <select value={situacao} onChange={(e) => setSituacao(e.target.value as any)}
            className="rounded border border-input bg-background px-2 py-1">
            <option value="todos">Todas</option>
            <option value="ativo">Ativo</option>
            <option value="suspenso">Suspenso</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </label>
      </div>

      <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
        <Stat label="Total de registros" value={fmtInt(report.total)} />
        <Stat label="Ativos" value={fmtInt(report.ativos)} />
        <Stat label="Suspensos" value={fmtInt(report.suspensos)} />
        <Stat label="Cancelados" value={fmtInt(report.cancelados)} />
        <Stat label="Com rastreador válido" value={fmtInt(report.comRastreadorValido)} />
        <Stat label="Sem rastreador" value={fmtInt(report.semRastreador)} />
        <Stat label="Rastreador inválido" value={fmtInt(report.rastreadorInvalido)} />
        <Stat label="Rastreador duplicado" value={fmtInt(report.rastreadorDuplicado)} />
        <Stat label="Rastreadores distintos" value={fmtInt(report.rastreadoresDistintos)} />
        <Stat label="Vazios" value={fmtInt(report.vazios)} />
        <Stat label="Zeros" value={fmtInt(report.zeros)} />
        <Stat label="Genéricos" value={fmtInt(report.genericos)} />
        <Stat label="Numéricos" value={fmtInt(report.numericos)} />
        <Stat label="Notação científica" value={fmtInt(report.notacaoCientifica)} />
      </div>

      <div className="px-4 pb-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
        <Stat label="Motos — total" value={fmtInt(report.motos.total)} />
        <Stat label="Motos ativas" value={fmtInt(report.motos.ativas)} />
        <Stat label="Motos suspensas" value={fmtInt(report.motos.suspensas)} />
        <Stat label="Motos operacionais" value={fmtInt(report.motos.operacionais)} />
        <Stat label="Motos c/ rastreador" value={fmtInt(report.motos.comRastreador)} />
        <Stat label="Motos s/ rastreador" value={fmtInt(report.motos.semRastreador)} />
        <Stat label="Motos rast. inválido" value={fmtInt(report.motos.invalidos)} />
        <Stat label="Motos duplicados" value={fmtInt(report.motos.duplicados)} />
      </div>

      <div className="px-4 pb-4">
        <div className="text-xs font-medium mb-1">Exemplos mascarados</div>
        <div className="rounded border border-border overflow-auto">
          <table className="w-full text-xs">
            <thead className="bg-muted"><tr className="text-left">
              {["Tipo", "Situação", "Placa", "Rastreador", "Motivo"].map((h) => (
                <th key={h} className="px-2 py-1 font-medium">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {report.examples.map((e, i) => (
                <tr key={i} className="border-t border-border">
                  <td className="px-2 py-1">{e.tipo}</td>
                  <td className="px-2 py-1">{e.situacao}</td>
                  <td className="px-2 py-1 font-mono">{e.placaMask}</td>
                  <td className="px-2 py-1 font-mono">{e.rastMask}</td>
                  <td className="px-2 py-1 text-muted-foreground">{e.motivo}</td>
                </tr>
              ))}
              {!report.examples.length && (
                <tr><td colSpan={5} className="px-2 py-4 text-center text-muted-foreground">Sem registros para os filtros informados.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border bg-background p-2">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold tabular-nums">{value}</div>
    </div>
  );
}
