import { useMemo, useState, useEffect } from "react";
import { X, Download, Trash2, Power, PowerOff } from "lucide-react";
import { fmtInt } from "@/lib/format";
import {
  providersServingCity,
  type MapFilter,
  type ProviderReach,
} from "@/lib/map-filter";
import {
  assocsInCity,
  assocsWithinRadius,
  citiesWithinRadius,
  computeDrawerSummary,
  regraDaCidade,
  exportDrawerXlsx,
  type DrawerSummary,
} from "@/lib/map-drawer";
import { lookupCoords } from "@/lib/city-coords";
import { haversineKm } from "@/lib/calc";
import { NIVEL_RISCO_LABEL, type Associado, type Prestador, type RegraRisco } from "@/lib/types";

export type DrawerSel =
  | { mode: "cidade"; cidade: string }
  | { mode: "prestador"; prestadorId: string }
  | { mode: "regra"; regraId: string };

export type DrawerAction =
  | { kind: "regra:delete"; id: string }
  | { kind: "regra:toggle"; id: string; ativar: boolean }
  | { kind: "prestador:delete"; id: string; nome: string }
  | { kind: "prestador:toggle"; id: string; nome: string; ativar: boolean };

interface Props {
  selection: DrawerSel | null;
  onClose: () => void;
  onAction?: (a: DrawerAction) => void;
  associados: Associado[];
  filteredAssociados: Associado[];
  prestadores: Prestador[];
  regras: RegraRisco[];
  filter: MapFilter;
}

function slug(s: string): string {
  return String(s ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function maskPlate(p: string): string {
  const s = String(p ?? "");
  return s.length <= 3 ? s + "*" : s.slice(0, 3) + "*".repeat(Math.max(2, s.length - 3));
}

export function MapDrawer({
  selection, onClose, onAction,
  associados, filteredAssociados, prestadores, regras, filter,
}: Props) {
  // Local state — nunca vaza para fora
  const [useGlobal, setUseGlobal] = useState(true);
  const [comparar, setComparar] = useState(false);

  const selKey = selection
    ? `${selection.mode}:${selection.mode === "cidade" ? selection.cidade : selection.mode === "prestador" ? selection.prestadorId : selection.regraId}`
    : "";
  useEffect(() => { setUseGlobal(true); setComparar(false); }, [selKey]);

  if (!selection) return null;

  return (
    <div className="fixed inset-0 z-[1000] pointer-events-none" aria-hidden={false}>
      <div className="pointer-events-auto absolute right-0 top-0 h-full w-full sm:w-[440px] bg-background border-l border-border shadow-2xl flex flex-col">
        {selection.mode === "cidade" && (
          <CidadeBody sel={selection} onClose={onClose}
            associados={associados} filteredAssociados={filteredAssociados}
            prestadores={prestadores} regras={regras} filter={filter}
            useGlobal={useGlobal} setUseGlobal={setUseGlobal}
            comparar={comparar} setComparar={setComparar}
          />
        )}
        {selection.mode === "prestador" && (
          <PrestadorBody sel={selection} onClose={onClose} onAction={onAction}
            associados={associados} filteredAssociados={filteredAssociados}
            prestadores={prestadores} regras={regras} filter={filter}
            useGlobal={useGlobal} setUseGlobal={setUseGlobal}
          />
        )}
        {selection.mode === "regra" && (
          <RegraBody sel={selection} onClose={onClose} onAction={onAction}
            associados={associados} filteredAssociados={filteredAssociados}
            prestadores={prestadores} regras={regras} filter={filter}
            useGlobal={useGlobal} setUseGlobal={setUseGlobal}
          />
        )}
      </div>
    </div>
  );
}

// ----------------- CIDADE -----------------
function CidadeBody(props: {
  sel: Extract<DrawerSel, { mode: "cidade" }>;
  onClose: () => void;
  associados: Associado[]; filteredAssociados: Associado[];
  prestadores: Prestador[]; regras: RegraRisco[]; filter: MapFilter;
  useGlobal: boolean; setUseGlobal: (v: boolean) => void;
  comparar: boolean; setComparar: (v: boolean) => void;
}) {
  const { sel, onClose, associados, filteredAssociados, prestadores, regras, filter,
    useGlobal, setUseGlobal, comparar, setComparar } = props;
  const [cidade, uf] = sel.cidade.split("|");

  const geraisRegiao = useMemo(() => assocsInCity(associados, cidade!, uf!),
    [associados, cidade, uf]);
  const recorteRegiao = useMemo(() => assocsInCity(filteredAssociados, cidade!, uf!),
    [filteredAssociados, cidade, uf]);
  const drawerAssoc = useGlobal ? recorteRegiao : geraisRegiao;

  const sumario = useMemo(() => computeDrawerSummary(drawerAssoc), [drawerAssoc]);
  const sumarioGeral = useMemo(() => computeDrawerSummary(geraisRegiao), [geraisRegiao]);

  const coords = useMemo(() => lookupCoords(cidade!, uf!), [cidade, uf]);
  const regra = useMemo(
    () => regraDaCidade(coords?.[0] ?? null, coords?.[1] ?? null, regras, filter.tipos),
    [coords, regras, filter.tipos],
  );
  const prestReach: ProviderReach[] = useMemo(() => {
    if (!coords) return [];
    return providersServingCity(coords[0], coords[1], prestadores, filter);
  }, [coords, prestadores, filter]);

  const modeLabel = useGlobal ? "Filtros do mapa aplicados" : "Dados gerais da região";

  const exportar = () => {
    const base = useGlobal ? "filtrado" : "geral";
    exportDrawerXlsx({
      filename: `${slug(cidade!)}-${slug(uf!)}-${base}.xlsx`,
      headerContext: {
        modo: modeLabel, cidade: cidade!, uf: uf!,
        registros_no_recorte: recorteRegiao.length,
        registros_totais_regiao: geraisRegiao.length,
      },
      assocs: drawerAssoc, regras, prestadoresQueAtendem: prestReach,
    });
  };

  return (
    <>
      <Header title={`${cidade}/${uf}`} subtitle={modeLabel} count={sumario.total} onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm">
        <ModeToggle useGlobal={useGlobal} setUseGlobal={setUseGlobal}
          comparar={comparar} setComparar={setComparar}
          recorte={recorteRegiao.length} geral={geraisRegiao.length} />

        <Section title="Resumo">
          {comparar && useGlobal ? (
            <ComparativaTable a={sumario} b={sumarioGeral} labels={["Recorte", "Total da região"]} />
          ) : (
            <ResumoGrid s={sumario} />
          )}
        </Section>

        <Section title="Veículos">
          <MiniGrid items={[
            ["Carros", sumario.carros], ["Motos", sumario.motos],
            ["Caminhões", sumario.caminhoes], ["Não classificados", sumario.naoClassificados],
          ]}/>
          {sumario.categorias.length > 0 && (
            <div className="mt-2 text-xs text-muted-foreground">
              Categorias: {sumario.categorias.slice(0, 8).map((c) => `${c.categoria} (${c.total})`).join(" · ")}
              {sumario.categorias.length > 8 ? ` +${sumario.categorias.length - 8}` : ""}
            </div>
          )}
        </Section>

        <Section title="Cobertura de rastreamento">
          <div>Cobertura: <b>{sumario.coberturaPct}%</b></div>
          <div>Com rastreador válido: <b>{fmtInt(sumario.comRastreador)}</b></div>
          <div>Sem rastreador válido: <b>{fmtInt(sumario.semRastreador)}</b></div>
          <div>Rastreador inválido: <b>{fmtInt(sumario.rastreadorInvalido)}</b></div>
          {sumario.motivosInvalidos.length > 0 && (
            <div className="mt-1 text-xs text-muted-foreground">
              Motivos: {sumario.motivosInvalidos.map((m) => `${m.motivo} (${m.total})`).join(" · ")}
            </div>
          )}
        </Section>

        <Section title="Risco manual">
          {regra ? (
            <div className="space-y-0.5">
              <div><b>{regra.nome || `${regra.cidade}/${regra.uf}`}</b></div>
              <div>Nível: <b>{NIVEL_RISCO_LABEL[regra.nivelRisco]}</b></div>
              <div>Política: <code className="text-xs">{regra.politica}</code></div>
              <div>Raio: {regra.raioKm} km · Tipo: {regra.tipoVeiculo}</div>
              {regra.motivo && <div className="text-xs text-muted-foreground">Motivo: {regra.motivo}</div>}
              {regra.fonte && <div className="text-xs text-muted-foreground">Fonte: {regra.fonte}</div>}
              {regra.atualizadoEm && <div className="text-xs text-muted-foreground">Atualizado: {regra.atualizadoEm}</div>}
            </div>
          ) : (
            <div className="text-muted-foreground text-xs">Nenhuma classificação manual cadastrada.</div>
          )}
        </Section>

        <Section title={`Prestadores que atendem a região (${prestReach.length})`}>
          {prestReach.length === 0 ? (
            <div className="text-muted-foreground text-xs">Nenhum prestador alcança esta região.</div>
          ) : (
            <div className="space-y-2">
              {prestReach.slice(0, 20).map((r) => (
                <div key={r.prestador.id} className="text-xs border border-border rounded p-2">
                  <div className="font-medium">{r.prestador.nome} · {r.prestador.cidade}/{r.prestador.uf}</div>
                  <div>Distância: {r.distanciaKm} km · Raio: {r.prestador.raioKm} km · Status: {r.prestador.status}</div>
                  <div>Tipos: {r.prestador.tiposAtendidos?.length ? r.prestador.tiposAtendidos.join(", ") : "não informado"}
                    · Capacidade: {r.prestador.capacidadeMensal ?? "não informada"}</div>
                  <div className="text-muted-foreground">Localização {r.prestador.localizacaoAproximada ? "aproximada" : "exata"}
                    {filter.tipos.length && !r.compatibleWithTypes ? " · incompatível com filtro de tipo" : ""}</div>
                </div>
              ))}
              {prestReach.length > 20 && <div className="text-xs text-muted-foreground">+{prestReach.length - 20} outros…</div>}
            </div>
          )}
        </Section>

        <TabelaRegistros assocs={drawerAssoc} />
      </div>

      <Footer onExport={exportar} label="Exportar dados desta região" />
    </>
  );
}

// ----------------- PRESTADOR -----------------
function PrestadorBody(props: {
  sel: Extract<DrawerSel, { mode: "prestador" }>;
  onClose: () => void;
  onAction?: (a: DrawerAction) => void;
  associados: Associado[]; filteredAssociados: Associado[];
  prestadores: Prestador[]; regras: RegraRisco[]; filter: MapFilter;
  useGlobal: boolean; setUseGlobal: (v: boolean) => void;
}) {
  const { sel, onClose, onAction, associados, filteredAssociados, prestadores, regras, filter,
    useGlobal, setUseGlobal } = props;
  const p = prestadores.find((x) => x.id === sel.prestadorId);
  if (!p || p.latitude == null || p.longitude == null) {
    return (
      <>
        <Header title="Prestador" subtitle="Não encontrado" count={0} onClose={onClose} />
        <div className="p-4 text-sm text-muted-foreground">Prestador sem coordenadas.</div>
      </>
    );
  }

  const geraisRaio = useMemo(
    () => assocsWithinRadius(associados, p.latitude!, p.longitude!, p.raioKm),
    [associados, p.latitude, p.longitude, p.raioKm],
  );
  const recorteRaio = useMemo(
    () => assocsWithinRadius(filteredAssociados, p.latitude!, p.longitude!, p.raioKm),
    [filteredAssociados, p.latitude, p.longitude, p.raioKm],
  );
  const drawerAssoc = useGlobal ? recorteRaio : geraisRaio;
  const sumario = useMemo(() => computeDrawerSummary(drawerAssoc), [drawerAssoc]);
  const cidadesCobertas = useMemo(
    () => citiesWithinRadius(associados, p.latitude!, p.longitude!, p.raioKm),
    [associados, p.latitude, p.longitude, p.raioKm],
  );
  const areasRiscoCobertas = useMemo(() => regras.filter((r) => {
    if (r.status !== "ativa" || r.latCentral == null || r.lngCentral == null) return false;
    return haversineKm(p.latitude!, p.longitude!, r.latCentral, r.lngCentral) <= (p.raioKm + r.raioKm);
  }), [regras, p.latitude, p.longitude, p.raioKm]);

  const modeLabel = useGlobal ? "Filtros do mapa aplicados" : "Dados gerais da região";

  const exportar = () => {
    exportDrawerXlsx({
      filename: `prestador-${slug(p.nome)}-${useGlobal ? "filtrado" : "geral"}.xlsx`,
      headerContext: {
        modo: modeLabel, prestador: p.nome, cidade: p.cidade, uf: p.uf,
        raio_km: p.raioKm, status: p.status,
        cidades_cobertas: cidadesCobertas.length,
        registros_no_recorte: recorteRaio.length,
        registros_totais: geraisRaio.length,
      },
      assocs: drawerAssoc, regras, prestadoresQueAtendem: [],
    });
  };

  return (
    <>
      <Header title={p.nome} subtitle={modeLabel} count={sumario.total} onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm">
        <label className="flex items-center gap-2 text-xs border border-border rounded p-2 bg-muted/40">
          <input type="checkbox" checked={useGlobal} onChange={(e) => setUseGlobal(e.target.checked)} />
          <span>Considerar filtros globais</span>
        </label>
        {!useGlobal && <p className="text-[11px] text-amber-700">Visualização geral apenas neste drawer. Os filtros do mapa continuam ativos.</p>}

        <Section title="Prestador">
          <div>Cidade/UF: <b>{p.cidade}/{p.uf}</b></div>
          <div>Status: <b>{p.status}</b></div>
          <div>Raio: <b>{p.raioKm} km</b></div>
          <div>Capacidade: {p.capacidadeMensal ?? "não informada"}</div>
          <div>Tipos: {p.tiposAtendidos?.length ? p.tiposAtendidos.join(", ") : "não informado"}</div>
          {p.fonte && <div className="text-xs text-muted-foreground">Fonte: {p.fonte}</div>}
          <div className="text-xs text-muted-foreground">Localização {p.localizacaoAproximada ? "aproximada" : "exata"}</div>
        </Section>

        {onAction && (
          <Section title="Cadastro">
            <div className="flex flex-wrap gap-2">
              {p.status === "ativo" ? (
                <button
                  onClick={() => onAction({ kind: "prestador:toggle", id: p.id, nome: p.nome, ativar: false })}
                  className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-xs hover:bg-muted"
                >
                  <PowerOff className="h-3.5 w-3.5" /> Inativar
                </button>
              ) : (
                <button
                  onClick={() => onAction({ kind: "prestador:toggle", id: p.id, nome: p.nome, ativar: true })}
                  className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-xs hover:bg-muted"
                >
                  <Power className="h-3.5 w-3.5" /> Ativar
                </button>
              )}
              <button
                onClick={() => onAction({ kind: "prestador:delete", id: p.id, nome: p.nome })}
                className="inline-flex items-center gap-1 rounded border border-destructive/60 text-destructive px-2 py-1 text-xs hover:bg-destructive/10"
              >
                <Trash2 className="h-3.5 w-3.5" /> Excluir prestador
              </button>
            </div>
            <p className="mt-2 text-[10px] text-muted-foreground">
              Ativar/Inativar apenas oculta ou mostra o marcador. Excluir remove permanentemente o cadastro (exige código administrativo).
            </p>
          </Section>
        )}

        <Section title="Alcance">
          <MiniGrid items={[
            ["Cidades cobertas", cidadesCobertas.length],
            ["Registros no raio", sumario.total],
            ["Com rastreador", sumario.comRastreador],
            ["Sem rastreador", sumario.semRastreador],
          ]}/>
        </Section>

        <Section title="Veículos no raio">
          <MiniGrid items={[
            ["Carros", sumario.carros], ["Motos", sumario.motos],
            ["Caminhões", sumario.caminhoes], ["Não classificados", sumario.naoClassificados],
          ]}/>
        </Section>

        <Section title={`Áreas de risco cobertas (${areasRiscoCobertas.length})`}>
          {areasRiscoCobertas.length === 0 ? (
            <div className="text-muted-foreground text-xs">Nenhuma área manual cadastrada dentro do alcance.</div>
          ) : areasRiscoCobertas.map((r) => (
            <div key={r.id} className="text-xs">
              <b>{r.nome || `${r.cidade}/${r.uf}`}</b> · {NIVEL_RISCO_LABEL[r.nivelRisco]} · {r.raioKm} km
            </div>
          ))}
        </Section>

        <TabelaRegistros assocs={drawerAssoc} />
      </div>
      <Footer onExport={exportar} label="Exportar dados do prestador" />
    </>
  );
}

// ----------------- ÁREA DE RISCO -----------------
function RegraBody(props: {
  sel: Extract<DrawerSel, { mode: "regra" }>;
  onClose: () => void;
  onAction?: (a: DrawerAction) => void;
  associados: Associado[]; filteredAssociados: Associado[];
  prestadores: Prestador[]; regras: RegraRisco[]; filter: MapFilter;
  useGlobal: boolean; setUseGlobal: (v: boolean) => void;
}) {
  const { sel, onClose, onAction, associados, filteredAssociados, prestadores, regras, filter,
    useGlobal, setUseGlobal } = props;
  const r = regras.find((x) => x.id === sel.regraId);
  if (!r || r.latCentral == null || r.lngCentral == null) {
    return (
      <>
        <Header title="Área de risco" subtitle="Não encontrada" count={0} onClose={onClose} />
        <div className="p-4 text-sm text-muted-foreground">Regra sem coordenadas.</div>
      </>
    );
  }

  const tipoRestr = r.tipoVeiculo === "todos" ? undefined : r.tipoVeiculo;
  const geraisArea = useMemo(
    () => assocsWithinRadius(associados, r.latCentral!, r.lngCentral!, r.raioKm, tipoRestr),
    [associados, r.latCentral, r.lngCentral, r.raioKm, tipoRestr],
  );
  const recorteArea = useMemo(
    () => assocsWithinRadius(filteredAssociados, r.latCentral!, r.lngCentral!, r.raioKm, tipoRestr),
    [filteredAssociados, r.latCentral, r.lngCentral, r.raioKm, tipoRestr],
  );
  const drawerAssoc = useGlobal ? recorteArea : geraisArea;
  const sumario = useMemo(() => computeDrawerSummary(drawerAssoc), [drawerAssoc]);
  const cidadesAtingidas = useMemo(
    () => citiesWithinRadius(drawerAssoc, r.latCentral!, r.lngCentral!, r.raioKm),
    [drawerAssoc, r.latCentral, r.lngCentral, r.raioKm],
  );
  const prestReach = useMemo(
    () => providersServingCity(r.latCentral!, r.lngCentral!, prestadores, filter),
    [r.latCentral, r.lngCentral, prestadores, filter],
  );

  const modeLabel = useGlobal ? "Filtros do mapa aplicados" : "Dados gerais da região";

  const exportar = () => {
    exportDrawerXlsx({
      filename: `area-${slug(r.nome || r.cidade)}-${useGlobal ? "filtrado" : "geral"}.xlsx`,
      headerContext: {
        modo: modeLabel, regra: r.nome, cidade: r.cidade, uf: r.uf,
        nivel: NIVEL_RISCO_LABEL[r.nivelRisco], politica: r.politica,
        raio_km: r.raioKm, tipo: r.tipoVeiculo,
      },
      assocs: drawerAssoc, regras, prestadoresQueAtendem: prestReach,
    });
  };

  return (
    <>
      <Header title={r.nome || `${r.cidade}/${r.uf}`} subtitle={modeLabel} count={sumario.total} onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm">
        <label className="flex items-center gap-2 text-xs border border-border rounded p-2 bg-muted/40">
          <input type="checkbox" checked={useGlobal} onChange={(e) => setUseGlobal(e.target.checked)} />
          <span>Considerar filtros globais</span>
        </label>
        {!useGlobal && <p className="text-[11px] text-amber-700">Visualização geral apenas neste drawer. Os filtros do mapa continuam ativos.</p>}

        <Section title="Regra">
          <div>Cidade base: <b>{r.cidade}/{r.uf}</b></div>
          <div>Nível: <b>{NIVEL_RISCO_LABEL[r.nivelRisco]}</b></div>
          <div>Política: <code className="text-xs">{r.politica}</code></div>
          <div>Raio: {r.raioKm} km · Tipo: {r.tipoVeiculo}</div>
          {r.motivo && <div className="text-xs text-muted-foreground">Motivo: {r.motivo}</div>}
          {r.fonte && <div className="text-xs text-muted-foreground">Fonte: {r.fonte}</div>}
          {r.atualizadoEm && <div className="text-xs text-muted-foreground">Atualizado: {r.atualizadoEm}</div>}
        </Section>

        {onAction && (
          <Section title="Cadastro da regra">
            <div className="flex flex-wrap gap-2">
              {r.status === "ativa" ? (
                <button
                  onClick={() => onAction({ kind: "regra:toggle", id: r.id, ativar: false })}
                  className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-xs hover:bg-muted"
                >
                  <PowerOff className="h-3.5 w-3.5" /> Inativar
                </button>
              ) : (
                <button
                  onClick={() => onAction({ kind: "regra:toggle", id: r.id, ativar: true })}
                  className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-xs hover:bg-muted"
                >
                  <Power className="h-3.5 w-3.5" /> Ativar
                </button>
              )}
              <button
                onClick={() => onAction({ kind: "regra:delete", id: r.id })}
                className="inline-flex items-center gap-1 rounded border border-destructive/60 text-destructive px-2 py-1 text-xs hover:bg-destructive/10"
              >
                <Trash2 className="h-3.5 w-3.5" /> Excluir área de risco
              </button>
            </div>
            <p className="mt-2 text-[10px] text-muted-foreground">
              Ativar/Inativar apenas oculta a regra do mapa. Excluir remove o cadastro permanentemente.
            </p>
          </Section>
        )}

        <Section title="Impacto">
          <MiniGrid items={[
            ["Cidades atingidas", cidadesAtingidas.length],
            ["Registros na área", sumario.total],
            ["Com rastreador", sumario.comRastreador],
            ["Sem rastreador", sumario.semRastreador],
          ]}/>
          <div className="mt-1">
            <MiniGrid items={[
              ["Carros", sumario.carros], ["Motos", sumario.motos],
              ["Caminhões", sumario.caminhoes], ["Não classificados", sumario.naoClassificados],
            ]}/>
          </div>
        </Section>

        <Section title={`Prestadores que atendem a área (${prestReach.length})`}>
          {prestReach.length === 0 ? (
            <div className="text-muted-foreground text-xs">Nenhum prestador alcança o centro desta área.</div>
          ) : prestReach.slice(0, 20).map((pr) => (
            <div key={pr.prestador.id} className="text-xs">
              <b>{pr.prestador.nome}</b> · {pr.prestador.cidade}/{pr.prestador.uf} · {pr.distanciaKm} km / raio {pr.prestador.raioKm} km
            </div>
          ))}
        </Section>

        <TabelaRegistros assocs={drawerAssoc} />
      </div>
      <Footer onExport={exportar} label="Exportar dados da área" />
    </>
  );
}

// ----------------- Building blocks -----------------
function Header({ title, subtitle, count, onClose }: { title: string; subtitle: string; count: number; onClose: () => void }) {
  return (
    <div className="border-b border-border p-4 flex items-start justify-between gap-2">
      <div>
        <div className="text-lg font-semibold">{title}</div>
        <div className="text-xs text-muted-foreground">{subtitle} · <b className="text-foreground">{fmtInt(count)}</b> registros</div>
      </div>
      <button onClick={onClose} aria-label="Fechar" className="rounded p-1 hover:bg-muted">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
function Footer({ onExport, label }: { onExport: () => void; label: string }) {
  return (
    <div className="border-t border-border p-3">
      <button onClick={onExport}
        className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90">
        <Download className="h-3.5 w-3.5" /> {label}
      </button>
    </div>
  );
}
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="text-xs font-semibold mb-2 text-muted-foreground uppercase tracking-wide">{title}</div>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}
function MiniGrid({ items }: { items: Array<[string, number]> }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {items.map(([l, v]) => (
        <div key={l} className="rounded border border-border p-2">
          <div className="text-[10px] uppercase text-muted-foreground">{l}</div>
          <div className="text-base font-semibold tabular-nums">{fmtInt(v)}</div>
        </div>
      ))}
    </div>
  );
}
function ResumoGrid({ s }: { s: DrawerSummary }) {
  return (
    <MiniGrid items={[
      ["Total", s.total], ["Ativos", s.ativos], ["Suspensos", s.suspensos],
      ["Cancelados", s.cancelados], ["Operacionais", s.operacionais],
      ["Com rastreador válido", s.comRastreador], ["Sem rastreador válido", s.semRastreador],
      ["Rastreador inválido", s.rastreadorInvalido], ["Rastreador duplicado", s.rastreadorDuplicado],
      ["Cancelados c/ rastreador", s.canceladosComRastreador],
    ]}/>
  );
}
function ComparativaTable({ a, b, labels }: { a: DrawerSummary; b: DrawerSummary; labels: [string, string] }) {
  const rows: Array<[string, number, number]> = [
    ["Registros", a.total, b.total],
    ["Ativos", a.ativos, b.ativos],
    ["Suspensos", a.suspensos, b.suspensos],
    ["Cancelados", a.cancelados, b.cancelados],
    ["Com rastreador", a.comRastreador, b.comRastreador],
    ["Sem rastreador", a.semRastreador, b.semRastreador],
    ["Carros", a.carros, b.carros],
    ["Motos", a.motos, b.motos],
    ["Caminhões", a.caminhoes, b.caminhoes],
  ];
  return (
    <table className="w-full text-xs">
      <thead><tr className="text-left text-muted-foreground">
        <th className="py-1">Métrica</th><th className="py-1 text-right">{labels[0]}</th><th className="py-1 text-right">{labels[1]}</th>
      </tr></thead>
      <tbody>
        {rows.map(([l, va, vb]) => (
          <tr key={l} className="border-t border-border">
            <td className="py-1">{l}</td>
            <td className="py-1 text-right tabular-nums">{fmtInt(va)}</td>
            <td className="py-1 text-right tabular-nums">{fmtInt(vb)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
function ModeToggle({ useGlobal, setUseGlobal, comparar, setComparar, recorte, geral }: {
  useGlobal: boolean; setUseGlobal: (v: boolean) => void;
  comparar: boolean; setComparar: (v: boolean) => void;
  recorte: number; geral: number;
}) {
  return (
    <div className="rounded-lg border border-border p-3 bg-muted/40 space-y-1">
      <label className="flex items-center gap-2 text-xs">
        <input type="checkbox" checked={useGlobal} onChange={(e) => setUseGlobal(e.target.checked)} />
        <span>Considerar filtros globais</span>
      </label>
      {!useGlobal && (
        <p className="text-[11px] text-amber-700">
          Visualização geral apenas neste drawer. Os filtros do mapa continuam ativos.
        </p>
      )}
      {useGlobal && (
        <label className="flex items-center gap-2 text-xs mt-1">
          <input type="checkbox" checked={comparar} onChange={(e) => setComparar(e.target.checked)} />
          <span>Comparar com total geral</span>
        </label>
      )}
      <div className="text-[11px] text-muted-foreground pt-1 border-t border-border/60">
        Resultado do recorte: <b>{fmtInt(recorte)}</b> · Total geral da região: <b>{fmtInt(geral)}</b>
      </div>
    </div>
  );
}
function TabelaRegistros({ assocs }: { assocs: Associado[] }) {
  const [page, setPage] = useState(0);
  const pageSize = 50;
  const total = assocs.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const slice = assocs.slice(page * pageSize, page * pageSize + pageSize);
  useEffect(() => { setPage(0); }, [total]);
  return (
    <div className="rounded-lg border border-border overflow-hidden">
      <div className="px-3 py-2 border-b border-border text-xs font-semibold flex items-center justify-between">
        <span>Registros ({fmtInt(total)})</span>
        {pages > 1 && (
          <span className="text-muted-foreground">
            Página {page + 1}/{pages}
            <button onClick={() => setPage(Math.max(0, page - 1))} className="ml-2 underline">‹</button>
            <button onClick={() => setPage(Math.min(pages - 1, page + 1))} className="ml-1 underline">›</button>
          </span>
        )}
      </div>
      <div className="overflow-auto max-h-64">
        <table className="w-full text-[11px]">
          <thead className="bg-muted sticky top-0"><tr className="text-left">
            {["Associado", "Placa", "Sit.", "Tipo", "Cat.", "Rast.", "Consultor", "FIPE"].map((h) => (
              <th key={h} className="px-2 py-1 font-medium">{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {slice.map((a, i) => (
              <tr key={i} className="border-t border-border">
                <td className="px-2 py-1 truncate max-w-[120px]">{a.associado}</td>
                <td className="px-2 py-1">{maskPlate(a.placa)}</td>
                <td className="px-2 py-1">{a.situacao}</td>
                <td className="px-2 py-1">{a.tipo}</td>
                <td className="px-2 py-1 truncate max-w-[100px]">{a.categoriaOriginal}</td>
                <td className="px-2 py-1">{a.temRastreador ? "sim" : "não"}</td>
                <td className="px-2 py-1 truncate max-w-[100px]">{a.consultor}</td>
                <td className="px-2 py-1 tabular-nums">{a.valorFipe ?? ""}</td>
              </tr>
            ))}
            {slice.length === 0 && (
              <tr><td colSpan={8} className="px-2 py-4 text-center text-muted-foreground">Sem registros neste modo.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
