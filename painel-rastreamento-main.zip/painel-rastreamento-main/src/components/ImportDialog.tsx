import { useEffect, useState } from "react";
import { X } from "lucide-react";
import {
  autoDetectColumns,
  buildAssociados,
  readWorkbook,
  type ParseResult,
} from "@/lib/import-sheet";
import { setAssociados } from "@/lib/store";
import type { ColumnMapping } from "@/lib/types";

const FIELDS: Array<{ key: keyof ColumnMapping; label: string; required?: boolean }> = [
  { key: "associado", label: "Associado" },
  { key: "placa", label: "Placa", required: true },
  { key: "numeroRastreador", label: "Número Rastreador", required: true },
  { key: "consultor", label: "Consultor" },
  { key: "cidade", label: "Cidade", required: true },
  { key: "estado", label: "Estado/UF", required: true },
  { key: "plano", label: "Plano" },
  { key: "situacao", label: "Situação", required: true },
  { key: "valorFipe", label: "Valor FIPE" },
  { key: "categoria", label: "Categoria", required: true },
];

export function ImportDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [parsed, setParsed] = useState<ParseResult | null>(null);
  const [mapping, setMapping] = useState<ColumnMapping>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setFile(null);
      setParsed(null);
      setMapping({});
      setError(null);
    }
  }, [open]);

  useEffect(() => {
    if (!file) return;
    setLoading(true);
    setError(null);
    readWorkbook(file)
      .then((r) => {
        setParsed(r);
        setMapping(autoDetectColumns(r.headers));
      })
      .catch((e) => setError(String(e?.message || e)))
      .finally(() => setLoading(false));
  }, [file]);

  if (!open) return null;

  const confirm = () => {
    if (!parsed) return;
    for (const f of FIELDS) {
      if (f.required && !mapping[f.key]) {
        setError(`Mapeie a coluna: ${f.label}`);
        return;
      }
    }
    setLoading(true);
    setTimeout(() => {
      try {
        const assocs = buildAssociados(parsed.rows, mapping);
        setAssociados(assocs, mapping, file?.name || parsed.sheetName);
        onClose();
      } catch (e) {
        setError(String((e as Error).message || e));
      } finally {
        setLoading(false);
      }
    }, 30);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-3xl max-h-[90vh] overflow-auto rounded-lg bg-background shadow-xl">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <h2 className="text-lg font-semibold">Importar planilha</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Arquivo (.xlsx, .xls, .csv)</label>
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-2 file:text-primary-foreground file:font-medium"
            />
            <p className="mt-1 text-xs text-muted-foreground">
              A leitura é 100% local, nada é enviado a servidor.
            </p>
          </div>

          {loading && <div className="text-sm text-muted-foreground">Processando…</div>}
          {error && <div className="rounded-md bg-destructive/10 text-destructive p-3 text-sm">{error}</div>}

          {parsed && (
            <>
              <div className="text-sm">
                <span className="font-medium">Aba:</span> {parsed.sheetName}{" "}
                <span className="text-muted-foreground">
                  · {parsed.rows.length.toLocaleString("pt-BR")} linhas · {parsed.headers.length} colunas
                </span>
              </div>

              <div>
                <h3 className="text-sm font-semibold mb-2">Mapeamento de colunas</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {FIELDS.map((f) => (
                    <label key={f.key} className="text-xs space-y-1">
                      <span className="block text-muted-foreground">
                        {f.label}
                        {f.required && <span className="text-destructive"> *</span>}
                      </span>
                      <select
                        className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm"
                        value={mapping[f.key] || ""}
                        onChange={(e) =>
                          setMapping((m) => ({ ...m, [f.key]: e.target.value || undefined }))
                        }
                      >
                        <option value="">— não mapear —</option>
                        {parsed.headers.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </select>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold mb-2">Amostra (5 linhas)</h3>
                <div className="overflow-auto max-h-64 border border-border rounded-md">
                  <table className="w-full text-xs">
                    <thead className="bg-muted sticky top-0">
                      <tr>
                        {parsed.headers.slice(0, 8).map((h) => (
                          <th key={h} className="text-left px-2 py-1.5 font-medium">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {parsed.rows.slice(0, 5).map((row, i) => (
                        <tr key={i} className="border-t border-border">
                          {parsed.headers.slice(0, 8).map((h) => (
                            <td key={h} className="px-2 py-1 truncate max-w-[160px]">
                              {String(row[h] ?? "")}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
        <div className="border-t border-border px-6 py-3 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="rounded-md border border-border px-4 py-2 text-sm hover:bg-muted"
          >
            Cancelar
          </button>
          <button
            onClick={confirm}
            disabled={!parsed || loading}
            className="rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground disabled:opacity-50"
          >
            Importar {parsed ? `(${parsed.rows.length.toLocaleString("pt-BR")} linhas)` : ""}
          </button>
        </div>
      </div>
    </div>
  );
}
