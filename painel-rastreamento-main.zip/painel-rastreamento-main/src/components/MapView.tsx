import { useEffect, useMemo, useRef, useState } from "react";
import { X, Download, Filter as FilterIcon, ChevronDown, ChevronUp, EyeOff, Eye, Loader2 } from "lucide-react";
import { useStore, removeRegra, upsertRegra, applyRemotePrestador, removePrestadorLocal, refreshPrestadoresFromSupabase } from "@/lib/store";
import {
  DEFAULT_MAP_FILTER,
  aggregateCities,
  applyAdvancedFilter,
  chipsFrom,
  computeDuplicateTrackers,
  filterPrestadores,
  providersServingCity,
  removeChip,
  type MapFilter,
  type RastreamentoStatus,
} from "@/lib/map-filter";
import {
  NON_INTERACTIVE_CIRCLE,
  PANE_CONFIG,
  PROVIDER_RADIUS_STYLE,
  RISK_CIRCLE_STYLE,
} from "@/lib/map-layers";
import {
  activatePrestadorRemote,
  deactivatePrestadorRemote,
  deletePrestadorRemote,
  PrestadoresApiError,
} from "@/lib/prestadores-api";
import { exportFilteredXlsx } from "@/lib/export-map";
import { fmtInt } from "@/lib/format";
import {
  type NivelRisco,
  type Situacao,
  type TipoVeiculo,
} from "@/lib/types";
import { MapDrawer, type DrawerAction, type DrawerSel } from "./MapDrawer";

const NEUTRAL_FILL = "#64748b";
const NEUTRAL_STROKE = "#334155";

const TIPOS: Array<{ v: TipoVeiculo; l: string }> = [
  { v: "carro", l: "Carro" }, { v: "moto", l: "Moto" },
  { v: "caminhao", l: "Caminhão" }, { v: "nao_classificado", l: "Não classificado" },
];
const SITUACOES: Array<{ v: Situacao; l: string }> = [
  { v: "ativo", l: "Ativo" }, { v: "suspenso", l: "Suspenso" },
  { v: "cancelado", l: "Cancelado" },
];
const RASTREAMENTO: Array<{ v: RastreamentoStatus; l: string }> = [
  { v: "com_valido", l: "Com rastreador válido" },
  { v: "sem_valido", l: "Sem rastreador válido" },
  { v: "invalido", l: "Rastreador inválido" },
  { v: "duplicado", l: "Rastreador duplicado" },
  { v: "cancelado_com_rast", l: "Cancelado c/ rastreador" },
];
const RISCOS: Array<{ v: NivelRisco; l: string }> = [
  { v: "sem_classificacao", l: "Não classificado" },
  { v: "baixo", l: "Baixo" }, { v: "medio", l: "Médio" },
  { v: "alto", l: "Alto" }, { v: "critico", l: "Crítico" },
];

function toggleIn<T>(arr: T[], v: T): T[] {
  return arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v];
}

// Pending confirmations (delete/toggle) originadas do drawer.
type Pending =
  | { kind: "regra:delete"; id: string; nome: string }
  | { kind: "prestador:delete"; id: string; nome: string }
  | { kind: "prestador:activate"; id: string; nome: string }
  | { kind: "prestador:deactivate"; id: string; nome: string };

export function MapView() {
  const { associados, prestadores, regras } = useStore();
  const [filter, setFilter] = useState<MapFilter>(DEFAULT_MAP_FILTER);
  const [showRegistros, setShowRegistros] = useState(true);
  const [showPrestadores, setShowPrestadores] = useState(true);
  const [showRaios, setShowRaios] = useState(true);
  const [showAreasRisco, setShowAreasRisco] = useState(true);
  const [showRegraMarkers, setShowRegraMarkers] = useState(true);
  const [filtersPanelOpen, setFiltersPanelOpen] = useState(false);
  const [selection, setSelection] = useState<DrawerSel | null>(null);

  const [pending, setPending] = useState<Pending | null>(null);
  const [adminCode, setAdminCode] = useState("");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const mapRef = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const leafletRef = useRef<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const layersRef = useRef<any>({});
  const [ready, setReady] = useState(false);

  const duplicates = useMemo(() => computeDuplicateTrackers(associados), [associados]);
  const ctx = useMemo(
    () => ({ regras, prestadores, duplicateTrackers: duplicates }),
    [regras, prestadores, duplicates],
  );
  const filteredAssociados = useMemo(
    () => applyAdvancedFilter(associados, filter, ctx),
    [associados, filter, ctx],
  );
  const filteredCities = useMemo(
    () => aggregateCities(filteredAssociados, duplicates),
    [filteredAssociados, duplicates],
  );
  const filteredPrestadores = useMemo(
    () => filterPrestadores(prestadores, filter),
    [prestadores, filter],
  );

  const categoriasDisponiveis = useMemo(() => {
    const set = new Set<string>();
    for (const a of associados) {
      if (filter.tipos.length && !filter.tipos.includes(a.tipo)) continue;
      if (a.categoriaOriginal) set.add(a.categoriaOriginal);
    }
    return Array.from(set).sort();
  }, [associados, filter.tipos]);

  const ufsDisponiveis = useMemo(() => {
    const s = new Set(associados.map((a) => a.estado).filter(Boolean));
    return Array.from(s).sort();
  }, [associados]);

  const cidadesDisponiveis = useMemo(() => {
    const s = new Set<string>();
    for (const a of associados) {
      if (filter.ufs.length && !filter.ufs.includes(a.estado)) continue;
      if (a.cidade && a.estado) s.add(`${a.cidade}|${a.estado}`);
    }
    return Array.from(s).sort();
  }, [associados, filter.ufs]);

  const nomesPrestadores = useMemo(
    () => Array.from(new Set(prestadores.map((p) => p.nome))).sort(),
    [prestadores],
  );

  const kpis = useMemo(() => {
    const prestReach = new Set<string>();
    let cidadesSemPrestador = 0;
    for (const c of filteredCities) {
      if (c.lat == null || c.lng == null) continue;
      const reach = providersServingCity(c.lat, c.lng, filteredPrestadores, filter);
      if (reach.length === 0) cidadesSemPrestador++;
      for (const r of reach) prestReach.add(r.prestador.id);
    }
    return {
      registros: filteredAssociados.length,
      cidades: filteredCities.length,
      prestadoresAtendem: prestReach.size,
      cidadesSemPrestador,
    };
  }, [filteredCities, filteredPrestadores, filter, filteredAssociados.length]);

  // Init map + panes
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !mapRef.current || leafletRef.current) return;
      const map = L.map(mapRef.current, { preferCanvas: true }).setView([-9.5, -40], 6);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 18, attribution: "&copy; OpenStreetMap",
      }).addTo(map);

      for (const cfg of Object.values(PANE_CONFIG)) {
        const el = map.createPane(cfg.name);
        el.style.zIndex = String(cfg.z);
        // Panes de círculos NÃO capturam eventos — o clique atravessa e atinge
        // as bolhas / marcadores acima.
        if (!cfg.interactive) {
          el.style.pointerEvents = "none";
        }
      }

      layersRef.current = {
        risco: L.layerGroup().addTo(map),
        raios: L.layerGroup().addTo(map),
        registros: L.layerGroup().addTo(map),
        prestadores: L.layerGroup().addTo(map),
        regraMarkers: L.layerGroup().addTo(map),
        selecao: L.layerGroup().addTo(map),
      };
      leafletRef.current = { L, map };
      setReady(true);
    })();
    return () => {
      cancelled = true;
      if (leafletRef.current?.map) {
        leafletRef.current.map.remove();
        leafletRef.current = null;
      }
    };
  }, []);

  // Render layers
  useEffect(() => {
    if (!ready || !leafletRef.current) return;
    const { L } = leafletRef.current;
    const groups = layersRef.current;
    groups.registros.clearLayers();
    groups.prestadores.clearLayers();
    groups.raios.clearLayers();
    groups.risco.clearLayers();
    groups.regraMarkers.clearLayers();
    groups.selecao.clearLayers();

    // 1. Áreas de risco — círculos apenas visuais (não interativos)
    if (showAreasRisco) {
      for (const r of regras) {
        if (r.status !== "ativa") continue;
        if (r.latCentral == null || r.lngCentral == null) continue;
        const cor = ({
          sem_classificacao: "#9ca3af", baixo: "#16a34a", medio: "#eab308",
          alto: "#f97316", critico: "#dc2626",
        } as Record<NivelRisco, string>)[r.nivelRisco];
        L.circle([r.latCentral, r.lngCentral], {
          radius: r.raioKm * 1000, color: cor, fillColor: cor,
          ...RISK_CIRCLE_STYLE,
          ...NON_INTERACTIVE_CIRCLE,
          pane: PANE_CONFIG.risco.name,
        }).addTo(groups.risco);
      }
    }

    // 2. Raios de prestadores — apenas visuais
    if (showRaios) {
      const seen = new Map<string, number>();
      for (const p of filteredPrestadores) {
        if (p.latitude == null || p.longitude == null) continue;
        const k = `${p.latitude.toFixed(3)}_${p.longitude.toFixed(3)}`;
        const n = seen.get(k) ?? 0;
        seen.set(k, n + 1);
        const off = jitter(n);
        const color = p.status === "ativo" ? "#16a34a" : p.status === "pendente" ? "#f59e0b" : "#6b7280";
        L.circle([p.latitude + off[0], p.longitude + off[1]], {
          radius: p.raioKm * 1000, color, fillColor: color,
          ...PROVIDER_RADIUS_STYLE,
          ...NON_INTERACTIVE_CIRCLE,
          pane: PANE_CONFIG.raios.name,
        }).addTo(groups.raios);
      }
    }

    // 3. Bolhas das cidades — interativas
    if (showRegistros) {
      const max = Math.max(1, ...filteredCities.map((c) => c.total));
      for (const c of filteredCities) {
        if (c.lat == null || c.lng == null || c.total <= 0) continue;
        const radius = 4 + Math.sqrt(c.total / max) * 26;
        const marker = L.circleMarker([c.lat, c.lng], {
          radius, color: NEUTRAL_STROKE, fillColor: NEUTRAL_FILL,
          fillOpacity: 0.55, weight: 1, pane: PANE_CONFIG.cidades.name,
          bubblingMouseEvents: false,
        });
        const cityKey = `${c.cidade}|${c.uf}`;
        marker.on("click", () => setSelection({ mode: "cidade", cidade: cityKey }));
        marker.addTo(groups.registros);
      }
    }

    // 4. Marcadores dos prestadores — interativos, acima das bolhas
    if (showPrestadores) {
      const seen = new Map<string, number>();
      for (const p of filteredPrestadores) {
        if (p.latitude == null || p.longitude == null) continue;
        const k = `${p.latitude.toFixed(3)}_${p.longitude.toFixed(3)}`;
        const n = seen.get(k) ?? 0;
        seen.set(k, n + 1);
        const off = jitter(n);
        const lat = p.latitude + off[0], lng = p.longitude + off[1];
        const color = p.status === "ativo" ? "#16a34a" : p.status === "pendente" ? "#f59e0b" : "#6b7280";
        const marker = L.circleMarker([lat, lng], {
          radius: 7, color, fillColor: color, fillOpacity: 0.85, weight: 2,
          pane: PANE_CONFIG.prestadores.name,
          bubblingMouseEvents: false,
        });
        marker.on("click", () => setSelection({ mode: "prestador", prestadorId: p.id }));
        marker.addTo(groups.prestadores);
      }
    }

    // 5. Marcadores centrais das áreas de risco — clicáveis, apenas no ponto central
    if (showAreasRisco && showRegraMarkers) {
      for (const r of regras) {
        if (r.status !== "ativa") continue;
        if (r.latCentral == null || r.lngCentral == null) continue;
        const cor = ({
          sem_classificacao: "#9ca3af", baixo: "#16a34a", medio: "#eab308",
          alto: "#f97316", critico: "#dc2626",
        } as Record<NivelRisco, string>)[r.nivelRisco];
        const icon = L.divIcon({
          className: "avp-risk-marker",
          html: `<div style="width:22px;height:22px;border-radius:50%;background:${cor};border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:700">!</div>`,
          iconSize: [22, 22], iconAnchor: [11, 11],
        });
        const m = L.marker([r.latCentral, r.lngCentral], {
          icon, pane: PANE_CONFIG.riscoMarkers.name, bubblingMouseEvents: false,
          title: r.nome || `${r.cidade}/${r.uf}`,
          keyboard: false,
        });
        m.on("click", () => setSelection({ mode: "regra", regraId: r.id }));
        m.addTo(groups.regraMarkers);
      }
    }

    // 6. Realce da seleção — puramente visual
    if (selection) {
      const highlight = { color: "#0ea5e9", weight: 3, fillOpacity: 0.15,
        pane: PANE_CONFIG.selecionado.name, ...NON_INTERACTIVE_CIRCLE };
      if (selection.mode === "cidade" && selection.cidade) {
        const [cidade, uf] = selection.cidade.split("|");
        const c = filteredCities.find((x) => x.cidade === cidade && x.uf === uf);
        if (c && c.lat != null && c.lng != null) {
          L.circleMarker([c.lat, c.lng], { ...highlight, radius: 16, fillColor: "#0ea5e9" }).addTo(groups.selecao);
        }
      } else if (selection.mode === "prestador" && selection.prestadorId) {
        const p = prestadores.find((x) => x.id === selection.prestadorId);
        if (p && p.latitude != null && p.longitude != null) {
          L.circleMarker([p.latitude, p.longitude], { ...highlight, radius: 12, fillColor: "#0ea5e9" }).addTo(groups.selecao);
        }
      } else if (selection.mode === "regra" && selection.regraId) {
        const r = regras.find((x) => x.id === selection.regraId);
        if (r && r.latCentral != null && r.lngCentral != null) {
          L.circle([r.latCentral, r.lngCentral], { ...highlight, radius: r.raioKm * 1000, fillOpacity: 0.05 }).addTo(groups.selecao);
        }
      }
    }
  }, [ready, filteredCities, filteredPrestadores, regras, prestadores, filter,
      showRegistros, showPrestadores, showRaios, showAreasRisco, showRegraMarkers, selection]);

  const chips = chipsFrom(filter);

  // Ações vindas do drawer
  const handleDrawerAction = (a: DrawerAction) => {
    if (a.kind === "regra:delete") {
      const r = regras.find((x) => x.id === a.id);
      setPending({ kind: "regra:delete", id: a.id, nome: r?.nome || r?.cidade || "área de risco" });
    } else if (a.kind === "regra:toggle") {
      const r = regras.find((x) => x.id === a.id);
      if (!r) return;
      upsertRegra({ ...r, status: a.ativar ? "ativa" : "inativa", atualizadoEm: new Date().toISOString() });
    } else if (a.kind === "prestador:delete") {
      setPending({ kind: "prestador:delete", id: a.id, nome: a.nome });
    } else if (a.kind === "prestador:toggle") {
      setPending({ kind: a.ativar ? "prestador:activate" : "prestador:deactivate", id: a.id, nome: a.nome });
    }
  };

  const executePending = async () => {
    if (!pending) return;
    setDialogError(null);
    setBusy(true);
    try {
      if (pending.kind === "regra:delete") {
        removeRegra(pending.id);
        setSelection(null);
      } else if (pending.kind === "prestador:delete") {
        await deletePrestadorRemote(adminCode, pending.id);
        removePrestadorLocal(pending.id);
        setSelection(null);
      } else if (pending.kind === "prestador:activate") {
        const upd = await activatePrestadorRemote(adminCode, pending.id);
        applyRemotePrestador(upd);
      } else if (pending.kind === "prestador:deactivate") {
        const upd = await deactivatePrestadorRemote(adminCode, pending.id);
        applyRemotePrestador(upd);
      }
      setPending(null);
      setAdminCode("");
      if (pending.kind.startsWith("prestador:")) void refreshPrestadoresFromSupabase();
    } catch (e) {
      if (e instanceof PrestadoresApiError) setDialogError(e.message);
      else setDialogError((e as Error).message ?? "Falha inesperada");
    } finally {
      setBusy(false);
    }
  };

  const needsAdminCode = pending?.kind === "prestador:delete" || pending?.kind === "prestador:activate" || pending?.kind === "prestador:deactivate";

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">Mapa de Decisão</h1>
          <p className="text-sm text-muted-foreground max-w-3xl">
            Clique em uma bolha, prestador ou marcador central de área de risco para abrir os detalhes. Círculos são apenas visuais e não capturam cliques.
          </p>
        </div>
        <div className="flex gap-2 items-center">
          <button
            onClick={() => setFiltersPanelOpen((v) => !v)}
            className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs hover:bg-muted"
          >
            <FilterIcon className="h-3.5 w-3.5" /> Filtros do mapa
          </button>
          <button
            onClick={() =>
              exportFilteredXlsx({ filter, filteredAssociados, cities: filteredCities, prestadores: filteredPrestadores, regras })
            }
            className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs text-primary-foreground hover:opacity-90"
          >
            <Download className="h-3.5 w-3.5" /> Exportar resultado filtrado
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
        <Kpi label="Registros no recorte" value={fmtInt(kpis.registros)} />
        <Kpi label="Cidades" value={fmtInt(kpis.cidades)} />
        <Kpi label="Prestadores que atendem" value={fmtInt(kpis.prestadoresAtendem)} />
        <Kpi label="Cidades sem prestador no raio" value={fmtInt(kpis.cidadesSemPrestador)} />
      </div>

      {/* Ações rápidas para ocultar sobreposições — apenas visual, não altera cadastros */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-muted-foreground">Sobreposições:</span>
        <QuickToggle label="prestadores" active={showPrestadores} onToggle={() => setShowPrestadores(v => !v)} />
        <QuickToggle label="raios" active={showRaios} onToggle={() => setShowRaios(v => !v)} />
        <QuickToggle label="áreas de risco" active={showAreasRisco} onToggle={() => setShowAreasRisco(v => !v)} />
        <QuickToggle label="marcadores centrais das áreas" active={showAreasRisco && showRegraMarkers}
          onToggle={() => setShowRegraMarkers(v => !v)} disabled={!showAreasRisco} />
        <span className="ml-2 text-[10px] text-muted-foreground">Ocultar aqui não exclui cadastros.</span>
      </div>

      {chips.length > 0 && (
        <div className="flex flex-wrap gap-1.5 items-center text-xs">
          {chips.map((c) => (
            <button
              key={c.onRemove + c.label}
              onClick={() => setFilter(removeChip(filter, String(c.onRemove)))}
              className="inline-flex items-center gap-1 rounded-full bg-primary/10 text-primary px-2 py-0.5 hover:bg-primary/20"
              title={`Remover ${c.group}: ${c.label}`}
            >
              <span className="font-medium">{c.group}:</span> {c.label} <X className="h-3 w-3" />
            </button>
          ))}
          <button
            onClick={() => setFilter(DEFAULT_MAP_FILTER)}
            className="ml-2 text-muted-foreground underline hover:text-foreground"
          >
            Limpar todos
          </button>
        </div>
      )}

      <div className="flex gap-3">
        {filtersPanelOpen && (
          <aside className="w-72 shrink-0 rounded-lg border border-border bg-card p-3 text-xs space-y-3 max-h-[76vh] overflow-y-auto">
            <div className="font-semibold text-sm flex items-center justify-between">
              Filtros do mapa
              <button onClick={() => setFiltersPanelOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            <Group title="Visualização e sobreposições">
              <CheckLabel checked={showRegistros} onChange={setShowRegistros} label="Bolhas de registros" />
              <CheckLabel checked={showPrestadores} onChange={setShowPrestadores} label="Marcadores de prestadores" />
              <CheckLabel checked={showRaios} onChange={setShowRaios} label="Raios de prestadores" />
              <CheckLabel checked={showAreasRisco} onChange={setShowAreasRisco} label="Áreas de risco (círculos)" />
              <CheckLabel checked={showRegraMarkers} onChange={setShowRegraMarkers} label="Marcadores centrais das áreas de risco" />
              <p className="text-[10px] text-muted-foreground pt-1">
                Ocultar não remove cadastros. Para excluir uma área ou prestador, abra o drawer correspondente.
              </p>
            </Group>

            <Group title="Tipo de veículo (vazio = todos)">
              {TIPOS.map((t) => (
                <CheckLabel key={t.v} label={t.l}
                  checked={filter.tipos.includes(t.v)}
                  onChange={() => setFilter({ ...filter, tipos: toggleIn(filter.tipos, t.v), categorias: [] })}
                />
              ))}
            </Group>

            <Group title="Situação do associado">
              {SITUACOES.map((s) => (
                <CheckLabel key={s.v} label={s.l}
                  checked={filter.situacoes.includes(s.v)}
                  onChange={() => setFilter({ ...filter, situacoes: toggleIn(filter.situacoes, s.v) })}
                />
              ))}
            </Group>

            <Group title="Rastreamento">
              {RASTREAMENTO.map((r) => (
                <CheckLabel key={r.v} label={r.l}
                  checked={filter.rastreamento.includes(r.v)}
                  onChange={() => setFilter({ ...filter, rastreamento: toggleIn(filter.rastreamento, r.v) })}
                />
              ))}
            </Group>

            <Group title="Risco manual">
              {RISCOS.map((r) => (
                <CheckLabel key={r.v} label={r.l}
                  checked={filter.riscos.includes(r.v)}
                  onChange={() => setFilter({ ...filter, riscos: toggleIn(filter.riscos, r.v) })}
                />
              ))}
            </Group>

            <Group title="Localização">
              <TriState label="Área de risco manual"
                value={filter.dentroRiscoManual}
                onChange={(v) => setFilter({ ...filter, dentroRiscoManual: v })}
                onLabel="Dentro" offLabel="Fora"
              />
              <TriState label="Raio de prestador"
                value={filter.dentroRaioPrestador}
                onChange={(v) => setFilter({ ...filter, dentroRaioPrestador: v })}
                onLabel="Dentro" offLabel="Fora"
              />
              <MultiChooser label="UF" options={ufsDisponiveis}
                selected={filter.ufs}
                onChange={(v) => setFilter({ ...filter, ufs: v, cidades: [] })}
              />
              <MultiChooser label="Cidade" options={cidadesDisponiveis}
                selected={filter.cidades}
                onChange={(v) => setFilter({ ...filter, cidades: v })}
                renderOption={(o) => o.replace("|", "/")}
              />
            </Group>

            {categoriasDisponiveis.length > 0 && (
              <Group title="Categoria específica">
                <MultiChooser label="Categoria" options={categoriasDisponiveis}
                  selected={filter.categorias}
                  onChange={(v) => setFilter({ ...filter, categorias: v })}
                />
              </Group>
            )}

            <Group title="Prestadores (filtro)">
              <MultiChooser label="Nome" options={nomesPrestadores}
                selected={filter.prestadorNomes}
                onChange={(v) => setFilter({ ...filter, prestadorNomes: v })}
              />
              <div className="space-y-1">
                <div className="text-muted-foreground">Status</div>
                {(["ativo", "pendente", "inativo"] as const).map((s) => (
                  <CheckLabel key={s} label={s}
                    checked={filter.prestadorStatus.includes(s)}
                    onChange={() => setFilter({ ...filter, prestadorStatus: toggleIn(filter.prestadorStatus, s) })}
                  />
                ))}
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">Atende</div>
                {(["carro", "moto", "caminhao"] as const).map((t) => (
                  <CheckLabel key={t} label={t}
                    checked={filter.prestadorAtende.includes(t)}
                    onChange={() => setFilter({ ...filter, prestadorAtende: toggleIn(filter.prestadorAtende, t) })}
                  />
                ))}
                <div className="text-[10px] text-muted-foreground">Vazio = "Não informado"; nunca presumimos atendimento.</div>
              </div>
              <div>
                <div className="text-muted-foreground">Capacidade</div>
                <select value={filter.prestadorCapacidade}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  onChange={(e) => setFilter({ ...filter, prestadorCapacidade: e.target.value as any })}
                  className="w-full rounded border border-input bg-background px-1 py-1">
                  <option value="todas">Todas</option>
                  <option value="com">Informada</option>
                  <option value="sem">Não informada</option>
                </select>
              </div>
            </Group>
          </aside>
        )}

        <div ref={mapRef} className="rounded-lg overflow-hidden border border-border flex-1"
          style={{ height: "76vh", minHeight: 520 }} />
      </div>

      <MapDrawer
        selection={selection}
        onClose={() => setSelection(null)}
        onAction={handleDrawerAction}
        associados={associados}
        filteredAssociados={filteredAssociados}
        prestadores={prestadores}
        regras={regras}
        filter={filter}
      />

      {/* Modal de confirmação — exclusão e ativação/inativação */}
      {pending && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center bg-black/40 p-4" onClick={() => !busy && (setPending(null), setAdminCode(""), setDialogError(null))}>
          <div className="w-full max-w-sm rounded-lg bg-background border border-border p-4 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold mb-1">
              {pending.kind === "regra:delete" && "Excluir área de risco"}
              {pending.kind === "prestador:delete" && "Excluir prestador"}
              {pending.kind === "prestador:activate" && "Ativar prestador"}
              {pending.kind === "prestador:deactivate" && "Inativar prestador"}
            </div>
            <div className="text-xs text-muted-foreground mb-3">
              {pending.kind === "regra:delete" && `Deseja excluir permanentemente esta área de risco? Esta ação removerá a classificação e a política cadastradas para "${pending.nome}".`}
              {pending.kind === "prestador:delete" && `Deseja excluir permanentemente "${pending.nome}"? O marcador e o raio de atendimento serão removidos do mapa.`}
              {pending.kind === "prestador:activate" && `Ativar "${pending.nome}"? O marcador voltará ao mapa.`}
              {pending.kind === "prestador:deactivate" && `Inativar "${pending.nome}"? O marcador e o raio deixarão de aparecer no mapa.`}
            </div>
            {needsAdminCode && (
              <>
                <label className="block text-xs mb-1 text-muted-foreground">Código administrativo</label>
                <input
                  type="password"
                  autoFocus
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  className="w-full rounded border border-input bg-background px-2 py-1.5 text-sm"
                  placeholder="Digite o código"
                  onKeyDown={(e) => { if (e.key === "Enter" && !busy && adminCode) void executePending(); }}
                />
              </>
            )}
            {dialogError && <div className="mt-2 text-xs text-destructive">{dialogError}</div>}
            <div className="mt-3 flex justify-end gap-2">
              <button
                disabled={busy}
                onClick={() => { setPending(null); setAdminCode(""); setDialogError(null); }}
                className="rounded-md border border-border px-3 py-1.5 text-xs hover:bg-muted disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                disabled={busy || (needsAdminCode && !adminCode)}
                onClick={() => void executePending()}
                className={`inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-xs text-white hover:opacity-90 disabled:opacity-50 ${
                  pending.kind.endsWith("delete") ? "bg-destructive" : "bg-primary"
                }`}
              >
                {busy && <Loader2 className="h-3 w-3 animate-spin" />}
                {pending.kind.endsWith("delete") ? "Excluir" : "Confirmar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-card border border-border p-2">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold tabular-nums">{value}</div>
    </div>
  );
}
function QuickToggle({ label, active, onToggle, disabled }: { label: string; active: boolean; onToggle: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onToggle}
      disabled={disabled}
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed ${
        active ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-700" : "bg-muted/40 border-border text-muted-foreground"
      }`}
      title={active ? `Ocultar ${label}` : `Mostrar ${label}`}
    >
      {active ? <><EyeOff className="h-3 w-3" /> Ocultar {label}</> : <><Eye className="h-3 w-3" /> Mostrar {label}</>}
    </button>
  );
}
function Group({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border-t border-border pt-2">
      <button onClick={() => setOpen(!open)} className="w-full text-left font-medium flex items-center justify-between">
        {title} {open ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
      </button>
      {open && <div className="mt-1 space-y-1">{children}</div>}
    </div>
  );
}
function CheckLabel({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  );
}
function TriState({ label, value, onChange, onLabel, offLabel }: {
  label: string; value: boolean | null; onChange: (v: boolean | null) => void; onLabel: string; offLabel: string;
}) {
  return (
    <div>
      <div className="text-muted-foreground">{label}</div>
      <div className="flex gap-1">
        {([["Ignorar", null], [onLabel, true], [offLabel, false]] as const).map(([l, v]) => (
          <button key={l} onClick={() => onChange(v)}
            className={`rounded border px-2 py-0.5 text-[11px] ${value === v ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"}`}>
            {l}
          </button>
        ))}
      </div>
    </div>
  );
}
function MultiChooser({ label, options, selected, onChange, renderOption }: {
  label: string; options: string[]; selected: string[]; onChange: (v: string[]) => void;
  renderOption?: (o: string) => string;
}) {
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState(false);
  const filtered = q ? options.filter((o) => o.toLowerCase().includes(q.toLowerCase())) : options;
  const shown = expanded ? filtered : filtered.slice(0, 8);
  return (
    <div>
      <div className="text-muted-foreground flex items-center justify-between">
        <span>{label}</span>
        {selected.length > 0 && (
          <button onClick={() => onChange([])} className="text-[10px] underline">limpar</button>
        )}
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="buscar…"
        className="w-full rounded border border-input bg-background px-1 py-0.5 mb-1" />
      <div className="space-y-0.5 max-h-40 overflow-y-auto">
        {shown.map((o) => (
          <label key={o} className="flex items-center gap-2 cursor-pointer text-[11px]">
            <input type="checkbox" checked={selected.includes(o)}
              onChange={() => onChange(selected.includes(o) ? selected.filter((x) => x !== o) : [...selected, o])} />
            <span className="truncate">{renderOption ? renderOption(o) : o}</span>
          </label>
        ))}
        {filtered.length > 8 && (
          <button onClick={() => setExpanded(!expanded)} className="text-[10px] underline">
            {expanded ? "recolher" : `ver mais (${filtered.length - 8})`}
          </button>
        )}
      </div>
    </div>
  );
}

function jitter(n: number): [number, number] {
  if (n === 0) return [0, 0];
  const step = 0.02;
  const angle = (n * 137.508 * Math.PI) / 180;
  return [Math.cos(angle) * step, Math.sin(angle) * step];
}
