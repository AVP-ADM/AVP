import type { ReactNode } from "react";

export function KpiCard({
  label,
  value,
  hint,
  tone = "default",
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: "default" | "success" | "warning" | "danger" | "info";
  icon?: ReactNode;
}) {
  const toneClass =
    tone === "success"
      ? "border-l-4 border-l-[var(--tone-success)]"
      : tone === "warning"
      ? "border-l-4 border-l-[var(--tone-warning)]"
      : tone === "danger"
      ? "border-l-4 border-l-[var(--tone-danger)]"
      : tone === "info"
      ? "border-l-4 border-l-[var(--tone-info)]"
      : "border-l-4 border-l-transparent";
  return (
    <div className={`rounded-lg bg-card p-4 shadow-sm ${toneClass}`}>
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
        {icon && <div className="text-muted-foreground">{icon}</div>}
      </div>
      <div className="mt-1 text-2xl font-semibold tabular-nums">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
    </div>
  );
}
