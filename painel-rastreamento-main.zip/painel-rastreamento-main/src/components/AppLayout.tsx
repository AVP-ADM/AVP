import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useState } from "react";
import {
  LayoutDashboard,
  Map,
  Radar,
  Users,
  ShieldAlert,
  ClipboardCheck,
  Upload,
  Trash2,
  Presentation,
} from "lucide-react";
import { useStore, clearAssociados, setFilter } from "@/lib/store";
import { ImportDialog } from "./ImportDialog";
import { fmtInt } from "@/lib/format";
import { categoriasDoTipo } from "@/lib/classify";
import { AeasySyncButton } from "./AeasySyncButton";
import { ENABLE_AEASY_SYNC } from "@/lib/feature-flags";
import type { TipoVeiculo } from "@/lib/types";

const NAV = [
  { to: "/", label: "Visão Executiva", icon: LayoutDashboard },
  { to: "/mapa", label: "Mapa de Decisão", icon: Map },
  { to: "/rastreamento", label: "Rastreamento", icon: Radar },
  { to: "/prestadores", label: "Prestadores", icon: Users },
  { to: "/risco", label: "Risco e Política", icon: ShieldAlert },
  { to: "/qualidade", label: "Qualidade dos Dados", icon: ClipboardCheck },
] as const;

export function AppLayout({ children }: { children: ReactNode }) {
  const { associados, importadoEm, fonte, filter } = useStore();
  const [importOpen, setImportOpen] = useState(false);
  const [presentation, setPresentation] = useState(false);
  const { location } = useRouterState();

  const categoriasDisponiveis = categoriasDoTipo(filter.tipoVeiculo);

  return (
    <div className="flex min-h-screen bg-[var(--bg-canvas)]">
      {!presentation && (
        <aside className="w-64 shrink-0 border-r border-border bg-[var(--bg-sidebar)] text-[var(--fg-sidebar)] flex flex-col">
          <div className="px-6 py-5 border-b border-white/10">
            <div className="text-xs uppercase tracking-widest text-white/50">Autovale</div>
            <div className="text-lg font-semibold">AVP · Rastreamento</div>
          </div>
          <nav className="flex-1 py-4 px-3 space-y-1">
            {NAV.map((n) => {
              const active = location.pathname === n.to;
              const Icon = n.icon;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-white/15 text-white font-medium"
                      : "text-white/70 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {n.label}
                </Link>
              );
            })}
          </nav>
          <div className="px-4 py-3 border-t border-white/10 text-xs text-white/60 space-y-1">
            <div>Registros: <span className="font-medium text-white">{fmtInt(associados.length)}</span></div>
            {fonte && <div className="truncate" title={fonte}>Fonte: {fonte}</div>}
            {importadoEm && <div>{new Date(importadoEm).toLocaleString("pt-BR")}</div>}
          </div>
        </aside>
      )}

      <main className="flex-1 min-w-0">
        <header className={`flex items-center justify-between gap-3 border-b border-border bg-background px-6 py-3 ${presentation ? "hidden" : ""}`}>
          <div className="text-sm text-muted-foreground">
            {associados.length
              ? `${fmtInt(associados.length)} registros carregados`
              : "Importe uma planilha para começar"}
          </div>
          <div className="flex items-center gap-2">
            {ENABLE_AEASY_SYNC && <AeasySyncButton hasData={associados.length > 0} />}
            <button
              onClick={() => setImportOpen(true)}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs text-muted-foreground hover:bg-muted"
              title="Importar base de associados"
            >
              <Upload className="h-3.5 w-3.5" /> Importar base de associados
            </button>
            {associados.length > 0 && (
              <button
                onClick={() => confirm("Limpar base carregada?") && clearAssociados()}
                className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs text-muted-foreground hover:bg-muted"
              >
                <Trash2 className="h-3.5 w-3.5" /> Limpar
              </button>
            )}
            <button
              onClick={() => setPresentation(true)}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs text-muted-foreground hover:bg-muted"
            >
              <Presentation className="h-3.5 w-3.5" /> Modo apresentação
            </button>
          </div>
        </header>
        {!presentation && associados.length > 0 && location.pathname !== "/mapa" && (
          <div className="flex items-center gap-3 border-b border-border bg-muted/40 px-6 py-2 text-xs">
            <span className="font-medium text-muted-foreground">Filtro global:</span>
            <label className="flex items-center gap-2">
              <span className="text-muted-foreground">Tipo</span>
              <select
                value={filter.tipoVeiculo}
                onChange={(e) => setFilter({ tipoVeiculo: e.target.value as TipoVeiculo | "todos", categoria: "" })}
                className="rounded border border-input bg-background px-2 py-1"
              >
                <option value="todos">Todos</option>
                <option value="carro">Carro</option>
                <option value="moto">Moto</option>
                <option value="caminhao">Caminhão</option>
                <option value="nao_classificado">Não classificado</option>
              </select>
            </label>
            <label className="flex items-center gap-2">
              <span className="text-muted-foreground">Categoria específica</span>
              <select
                value={filter.categoria}
                onChange={(e) => setFilter({ categoria: e.target.value })}
                className="rounded border border-input bg-background px-2 py-1 min-w-[220px]"
              >
                <option value="">Todas</option>
                {categoriasDisponiveis.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </label>
            {(filter.tipoVeiculo !== "todos" || filter.categoria) && (
              <button
                onClick={() => setFilter({ tipoVeiculo: "todos", categoria: "" })}
                className="ml-auto rounded border border-border px-2 py-1 hover:bg-muted"
              >
                Limpar filtro
              </button>
            )}
          </div>
        )}
        {presentation && (
          <button
            onClick={() => setPresentation(false)}
            className="fixed top-3 right-3 z-50 rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground shadow"
          >
            Sair da apresentação
          </button>
        )}
        <div className={presentation ? "p-4" : "p-6"}>{children}</div>
      </main>
      <ImportDialog open={importOpen} onClose={() => setImportOpen(false)} />
    </div>
  );
}
