# AVP · Painel de Rastreamento Autovale

Aplicação web para transformar a base de associados da Autovale (AVP) em uma
ferramenta de decisão para rastreamento, prestadores, concentração geográfica,
recuperação de equipamentos e política de aceitação por região/tipo de veículo.

## Como rodar

```bash
bun install
bun run dev
```

Acesse `http://localhost:8080` e clique em **Importar planilha** no topo. A
leitura acontece 100% no navegador (SheetJS) — nenhum dado é enviado a
servidor.

## Estrutura

- `src/routes/index.tsx` — Visão Executiva (KPIs e gráficos)
- `src/routes/mapa.tsx` + `src/components/MapView.tsx` — Mapa de Decisão (Leaflet)
- `src/routes/rastreamento.tsx` — Cobertura, filtros e priorização
- `src/routes/prestadores.tsx` — Cadastro e cálculo de déficit
- `src/routes/risco.tsx` — Regras de risco e política de aceitação
- `src/routes/qualidade.tsx` — Auditoria da base
- `src/lib/classify.ts` — Classificação de tipo de veículo, situação, rastreador
- `src/lib/calc.ts` — Métricas agregadas e score de prioridade
- `src/lib/city-coords.ts` — Coordenadas de cidades brasileiras (com fallback UF)
- `src/lib/import-sheet.ts` — Detecção automática de colunas e parsing
- `src/lib/store.ts` — Estado global (React `useSyncExternalStore` + localStorage)

## Modelos de arquivo

- `public/prestadores_exemplo.csv`
- `public/regras_risco_exemplo.csv`

## Colunas esperadas

O sistema detecta automaticamente, aceitando variações (com/sem acento,
maiúsculo/minúsculo):

Associado · Placa · Numero Rastreador · Consultor · Cidade · Estado · Plano
· Situacao · Valor Fipe · Categoria

O mapeamento pode ser ajustado manualmente na tela de importação.

## Regras aplicadas

- **Operacional** = Ativo + Suspenso
- **Cobertura** = ComRastreador / Operacionais
- **Recuperação** = Cancelados com rastreador informado
- **Rastreador válido** rejeita `000000000000000`, vazio, "n/a" e similares
- **Score de prioridade** por cidade (0–100):
  - 35 pts se está no top 20 de sem rastreador
  - até 25 pts proporcional a sem rastreador
  - até 15 pts proporcional a cancelados com rastreador
  - até 15 pts por nível de risco
  - até 10 pts por déficit de prestador
  - +5 pts se política é "não aceita"/"não aceita moto"
- **Necessidade de prestadores**: 1 para cada 150 (alta prioridade) ou 250
  (normal) veículos operacionais sem rastreador. Boost de +20% quando >50%
  são motos. Parâmetros ajustáveis em **Prestadores → Parâmetros**.

## Publicar

O projeto usa TanStack Start e roda em qualquer host que sirva o build
estático. `bun run build` gera os artefatos.
